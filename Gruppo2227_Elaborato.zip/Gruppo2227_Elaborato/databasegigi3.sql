-- MariaDB dump 10.19  Distrib 10.4.24-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: databasegigi
-- ------------------------------------------------------
-- Server version	10.4.24-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accesso`
--

DROP TABLE IF EXISTS `accesso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accesso` (
  `IdDevice` int(11) NOT NULL,
  `IdCliente` int(11) NOT NULL,
  `DataAccesso` date NOT NULL,
  `OraAccesso` varchar(40) NOT NULL,
  `DataFine` date DEFAULT NULL,
  `OraFineAccesso` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`DataAccesso`,`IdDevice`,`OraAccesso`) USING BTREE,
  KEY `IdCliente` (`IdCliente`),
  KEY `IdDevice` (`IdDevice`),
  CONSTRAINT `accesso_ibfk_1` FOREIGN KEY (`IdCliente`) REFERENCES `cliente` (`IdCliente`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `accesso_ibfk_3` FOREIGN KEY (`IdDevice`) REFERENCES `device` (`IdDevice`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accesso`
--

LOCK TABLES `accesso` WRITE;
/*!40000 ALTER TABLE `accesso` DISABLE KEYS */;
INSERT INTO `accesso` VALUES (31,2,'2022-08-01','20:27:10','2022-08-22','20:28:25'),(1,1,'2022-08-07','00:02:05','2022-08-07','00:05:46'),(1,1,'2022-08-07','00:06:09','2022-08-07','00:06:15'),(1,1,'2022-08-07','00:06:22','2022-08-07','00:06:37'),(1,1,'2022-08-07','22:19:04','2022-08-07','22:19:07'),(1,1,'2022-08-07','22:25:34','2022-08-07','22:26:04'),(1,1,'2022-08-07','22:44:01','2022-08-07','22:44:16'),(1,1,'2022-08-07','22:44:23','2022-08-07','22:44:28'),(5,1,'2022-08-07','22:19:28','2022-08-07','22:19:31'),(20,1,'2022-08-07','00:07:50','2022-08-07','00:08:01'),(1,2,'2022-08-22','20:30:36','2022-08-22','20:30:56'),(1,2,'2022-08-22','20:31:03','2022-08-22','20:33:43'),(1,1,'2022-08-22','20:46:27','2022-08-22','20:46:36'),(1,1,'2022-08-22','21:00:42','2022-08-22','21:05:47'),(1,1,'2022-08-22','21:08:42','2022-08-22','21:09:14'),(1,1,'2022-08-22','21:12:02','2022-08-22','21:12:16'),(2,1,'2022-08-22','20:33:43','2022-08-22','20:46:15'),(2,1,'2022-08-22','21:12:16','2022-08-22','21:13:50'),(3,2,'2022-08-22','21:12:16','2022-08-22','21:13:50'),(6,1,'2022-08-22','20:04:17','2022-08-22','20:05:59'),(8,2,'2022-08-22','20:04:17','2022-08-22','20:05:59'),(31,3,'2022-08-22','20:04:17','2022-08-22','20:05:59'),(1,4,'2022-08-23','16:59:22','2022-08-23','17:03:59'),(20,4,'2022-08-23','16:50:53','2022-08-23','16:53:47'),(20,1,'2022-08-23','17:04:21','2022-08-23','17:12:39'),(20,1,'2022-08-23','17:22:31','2022-08-23','17:22:39'),(20,1,'2022-08-23','17:22:39','2022-08-23','17:23:14'),(21,7,'2022-08-23','17:04:53','2022-08-23','17:22:39'),(21,3,'2022-08-23','17:22:39','2022-08-23','17:23:14');
/*!40000 ALTER TABLE `accesso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `IdAccount` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(40) NOT NULL,
  `RuoloAccount` varchar(40) NOT NULL,
  PRIMARY KEY (`IdAccount`),
  UNIQUE KEY `Username` (`Username`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES (1,'MatteoCarpi','Passwrod123','Dipendente'),(2,'MarcoRossi','Passwrod123','Dipendente'),(3,'GiuliaGiuliani','Passwrod123','Dipendente'),(4,'MartaTorre','Passwrod123','Dipendente'),(5,'PierLuigiani','Passwrod123','Dipendente'),(6,'admin','admin','admin'),(21,'asdweq','abcdef','Dipendente');
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `associazione`
--

DROP TABLE IF EXISTS `associazione`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `associazione` (
  `IdGioco` int(11) NOT NULL,
  `IdDevice` int(11) NOT NULL,
  PRIMARY KEY (`IdDevice`,`IdGioco`) USING BTREE,
  KEY `IdGioco` (`IdGioco`),
  KEY `IdDevice` (`IdDevice`),
  CONSTRAINT `associazione_ibfk_1` FOREIGN KEY (`IdGioco`) REFERENCES `gioco` (`idGioco`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `associazione_ibfk_2` FOREIGN KEY (`IdDevice`) REFERENCES `device` (`IdDevice`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `associazione`
--

LOCK TABLES `associazione` WRITE;
/*!40000 ALTER TABLE `associazione` DISABLE KEYS */;
INSERT INTO `associazione` VALUES (1,1),(2,1),(3,1),(4,1),(1,2),(2,2),(3,2),(5,2),(1,3),(2,3),(3,3),(4,3),(5,3),(1,4),(2,4),(3,4),(4,4),(1,5),(3,5),(4,5),(1,6),(2,6),(4,6),(1,8),(2,8),(3,8),(5,8),(1,9),(4,9),(5,9),(1,10),(4,10),(5,10),(1,11),(3,11),(4,11),(1,12),(3,12),(4,12),(5,12),(1,13),(3,13),(4,13),(5,13),(1,15),(3,15),(5,15),(1,16),(2,16),(5,16),(5,20),(6,20),(5,21),(6,21),(2,31);
/*!40000 ALTER TABLE `associazione` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categoria`
--

DROP TABLE IF EXISTS `categoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categoria` (
  `IdCategoria` int(11) NOT NULL AUTO_INCREMENT,
  `NomeCategoria` varchar(40) NOT NULL,
  PRIMARY KEY (`IdCategoria`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoria`
--

LOCK TABLES `categoria` WRITE;
/*!40000 ALTER TABLE `categoria` DISABLE KEYS */;
INSERT INTO `categoria` VALUES (1,'Sport'),(2,'Sparatutto'),(3,'Rpg'),(4,'Jrpg'),(5,'Actionrpg'),(6,'Role game'),(7,'Horror'),(8,'Open world'),(9,'Rogue like'),(10,'Battle royale'),(11,'MOBA'),(12,'Picchia duro');
/*!40000 ALTER TABLE `categoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classificazione`
--

DROP TABLE IF EXISTS `classificazione`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classificazione` (
  `IdGara` int(11) NOT NULL,
  `IdCliente` int(11) NOT NULL,
  `Posizione` int(11) DEFAULT NULL,
  `PuntiPremioVinti` int(11) DEFAULT NULL,
  PRIMARY KEY (`IdGara`,`IdCliente`),
  KEY `IdCliente` (`IdCliente`),
  KEY `idGara` (`IdGara`),
  CONSTRAINT `classificazione_ibfk_1` FOREIGN KEY (`IdCliente`) REFERENCES `cliente` (`IdCliente`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `classificazione_ibfk_2` FOREIGN KEY (`IdGara`) REFERENCES `gara` (`IdGara`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classificazione`
--

LOCK TABLES `classificazione` WRITE;
/*!40000 ALTER TABLE `classificazione` DISABLE KEYS */;
INSERT INTO `classificazione` VALUES (7,1,3,16),(7,2,2,25),(7,3,1,50),(11,1,2,25),(11,2,1,50),(13,1,1,50),(13,3,2,25);
/*!40000 ALTER TABLE `classificazione` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cliente` (
  `IdCliente` int(11) NOT NULL AUTO_INCREMENT,
  `NomeCliente` varchar(40) NOT NULL,
  `CognomeCliente` varchar(40) NOT NULL,
  `GenereCliente` varchar(40) NOT NULL,
  `DataDiNascitaCliente` date NOT NULL,
  `TelefonoCliente` varchar(11) NOT NULL,
  `EmailCliente` varchar(40) NOT NULL,
  `PinCliente` varchar(40) NOT NULL,
  `Città` varchar(40) NOT NULL,
  `Via` varchar(40) NOT NULL,
  `CodicePostale` varchar(40) NOT NULL,
  `Tempo` time NOT NULL,
  `PuntiPremio` int(11) NOT NULL,
  PRIMARY KEY (`IdCliente`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES (1,'Laura','Leone','Femmina','2004-08-21','12111','LauLeo@gmail.com','3503','Ravenna','via mazzini 23','48124','19:33:39',218),(2,'Henry','Creel','Maschio','2012-08-01','3199846270','VecnaPower@gmail.com','4016','SottoSopra','sottofuime 1','48121','02:59:40',95),(3,'Serena','Presti','Femmina','2005-04-13','3617837355','Presti@gmail.com','9471','Mezzano','Via argini 23','48012','00:00:00',76),(4,'Maria Carmela','Sciacca','Femmina','1995-05-25','3779186355','MelaSciacca@gmail.com','4692','Ferrara','Via del Melo 74','480732','03:52:29',3),(7,'Laura','Leone','Male','2010-08-13','74747474','LauLeo123@gmail.com','454556','45343423','456456456','2313453','08:00:00',0);
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contratto`
--

DROP TABLE IF EXISTS `contratto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contratto` (
  `IdContratto` int(11) NOT NULL AUTO_INCREMENT,
  `Tipo` varchar(40) NOT NULL,
  `Stipendio` decimal(10,2) NOT NULL,
  `DataInizio` date NOT NULL,
  `DataFine` date DEFAULT NULL,
  PRIMARY KEY (`IdContratto`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contratto`
--

LOCK TABLES `contratto` WRITE;
/*!40000 ALTER TABLE `contratto` DISABLE KEYS */;
INSERT INTO `contratto` VALUES (1,'Determinato',10000.00,'2021-09-12',NULL),(2,'Indeterminato',17600.00,'2021-09-12',NULL),(3,'Indeterminato',17600.00,'2021-09-15',NULL),(4,'Indeterminato',17600.00,'2021-11-01',NULL),(5,'Indeterminato',17600.00,'2022-03-19',NULL),(6,'Determinato',10000.00,'2022-08-09','2022-08-09'),(7,'Indeterminato',20000.00,'2022-08-09','2022-08-09');
/*!40000 ALTER TABLE `contratto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dettaglio_acquisto`
--

DROP TABLE IF EXISTS `dettaglio_acquisto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dettaglio_acquisto` (
  `IdProdotto` int(11) NOT NULL,
  `IdOrdine` int(11) NOT NULL,
  `QuantitàAcquisto` int(11) NOT NULL,
  `PrezzoUnitario` decimal(10,2) NOT NULL,
  `PrezzoTotale` decimal(10,2) NOT NULL,
  `PuntiPremioRegaloPerProdotto` int(11) NOT NULL,
  `Sconto` int(11) DEFAULT NULL,
  PRIMARY KEY (`IdProdotto`,`IdOrdine`),
  KEY `IdOrdine` (`IdOrdine`),
  KEY `IdProdotto` (`IdProdotto`) USING BTREE,
  CONSTRAINT `dettaglio_acquisto_ibfk_1` FOREIGN KEY (`IdOrdine`) REFERENCES `ordine` (`IdOrdine`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `dettaglio_acquisto_ibfk_2` FOREIGN KEY (`IdProdotto`) REFERENCES `prodotto` (`IdProdotto`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dettaglio_acquisto`
--

LOCK TABLES `dettaglio_acquisto` WRITE;
/*!40000 ALTER TABLE `dettaglio_acquisto` DISABLE KEYS */;
INSERT INTO `dettaglio_acquisto` VALUES (1,7,2,3.50,6.30,4,10),(1,8,1,3.50,3.50,2,NULL),(2,9,3,4.00,12.00,6,NULL),(2,13,1,4.00,4.00,2,NULL),(3,10,1,3.50,3.50,2,NULL),(4,11,2,5.50,10.45,6,5),(5,9,3,1.00,3.00,3,NULL),(5,13,1,1.00,1.00,1,NULL),(6,8,1,1.00,1.00,1,NULL),(6,11,2,1.00,1.80,2,10),(6,14,3,1.00,3.00,3,NULL),(7,10,1,1.50,0.75,1,50),(8,12,5,2.00,9.50,10,5),(8,14,3,2.00,6.00,6,NULL);
/*!40000 ALTER TABLE `dettaglio_acquisto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dettaglio_ricarica`
--

DROP TABLE IF EXISTS `dettaglio_ricarica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dettaglio_ricarica` (
  `IdRicarica` int(11) NOT NULL,
  `IdListino` int(11) NOT NULL,
  `QuantitàRicarica` int(11) NOT NULL,
  `PrezzoUnitarioRicarica` decimal(10,2) NOT NULL,
  `PrezzoTotaleRicarica` decimal(10,2) NOT NULL,
  PRIMARY KEY (`IdRicarica`,`IdListino`),
  KEY `IdListino` (`IdListino`),
  KEY `IdRicarica` (`IdRicarica`),
  CONSTRAINT `dettaglio_ricarica_ibfk_1` FOREIGN KEY (`IdRicarica`) REFERENCES `ricarica` (`IdRicarica`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `dettaglio_ricarica_ibfk_2` FOREIGN KEY (`IdListino`) REFERENCES `listinoprezzo` (`IdListino`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dettaglio_ricarica`
--

LOCK TABLES `dettaglio_ricarica` WRITE;
/*!40000 ALTER TABLE `dettaglio_ricarica` DISABLE KEYS */;
INSERT INTO `dettaglio_ricarica` VALUES (1,1,2,5.00,10.00),(1,3,1,15.00,15.00),(2,1,1,5.00,5.00),(2,2,1,10.00,10.00),(3,3,1,20.00,20.00);
/*!40000 ALTER TABLE `dettaglio_ricarica` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device`
--

DROP TABLE IF EXISTS `device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device` (
  `IdDevice` int(11) NOT NULL AUTO_INCREMENT,
  `NomeDevice` varchar(40) NOT NULL,
  `StatoDevice` varchar(40) NOT NULL DEFAULT 'No Game',
  `OccupatoDevice` varchar(40) NOT NULL DEFAULT 'Empty',
  `MemoriaDevice` int(11) NOT NULL DEFAULT 0,
  `IdSala` int(11) NOT NULL,
  `IdModello` int(11) NOT NULL,
  PRIMARY KEY (`IdDevice`) USING BTREE,
  KEY `IdSala` (`IdSala`),
  KEY `IdModello` (`IdModello`),
  KEY `IdDevice` (`IdDevice`),
  CONSTRAINT `device_ibfk_1` FOREIGN KEY (`IdSala`) REFERENCES `sala` (`IdSala`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `device_ibfk_2` FOREIGN KEY (`IdModello`) REFERENCES `modello` (`IdModello`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device`
--

LOCK TABLES `device` WRITE;
/*!40000 ALTER TABLE `device` DISABLE KEYS */;
INSERT INTO `device` VALUES (1,'PS5','Working','Empty',195,1,3),(2,'PS5','Working','Empty',135,1,3),(3,'PS5 blu','Working','Empty',200,1,3),(4,'PS5','Working','Empty',195,1,3),(5,'PS5','Working','Empty',145,1,3),(6,'PS4 ','Working','Empty',165,2,2),(7,'PS5 red','No Game','Empty',0,1,3),(8,'PS4','Working','Empty',85,2,2),(9,'Xbox 360','Working','Empty',120,3,4),(10,'Xbox 360','Working','Empty',120,3,4),(11,'Xbox 360','Working','Empty',145,3,4),(12,'Xbox Series X 2021','Working','Empty',150,4,6),(13,'Xbox Series X','Working','Empty',150,4,6),(15,'Xnox One Old','Working','Empty',85,5,5),(16,'Xnox One','Working','Empty',105,5,5),(20,'Switch ','Working','Empty',20,6,1),(21,'Switch','Working','Empty',20,6,1),(31,'Ps4','Working','Empty',50,2,2);
/*!40000 ALTER TABLE `device` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dipendente`
--

DROP TABLE IF EXISTS `dipendente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dipendente` (
  `IdDipendente` int(11) NOT NULL AUTO_INCREMENT,
  `NomeDipendente` varchar(20) NOT NULL,
  `CognomeDipendente` varchar(20) NOT NULL,
  `GenereDipendente` varchar(20) NOT NULL,
  `DataDiNascitaDipendente` date NOT NULL,
  `TelefonoDipendente` varchar(20) NOT NULL,
  `EmailDipendente` varchar(40) NOT NULL,
  `Città` varchar(20) NOT NULL,
  `Via` varchar(40) NOT NULL,
  `CodicePostale` varchar(20) NOT NULL,
  `Ruolo` varchar(20) NOT NULL,
  `IdContratto` int(11) NOT NULL,
  `idAccount` int(11) NOT NULL,
  PRIMARY KEY (`IdDipendente`),
  KEY `IdContratto` (`IdContratto`) USING BTREE,
  KEY `IdAccount` (`idAccount`),
  CONSTRAINT `dipendente_ibfk_2` FOREIGN KEY (`idAccount`) REFERENCES `account` (`IdAccount`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `dipendente_ibfk_3` FOREIGN KEY (`IdContratto`) REFERENCES `contratto` (`IdContratto`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dipendente`
--

LOCK TABLES `dipendente` WRITE;
/*!40000 ALTER TABLE `dipendente` DISABLE KEYS */;
INSERT INTO `dipendente` VALUES (1,'Matteo','Carpi','Maschio','1999-11-12','3527681678','carpiM@gmail.com','Mezzano','Via argini 4','48123','Staff',1,1),(2,'Marco','Rossi','Maschio','2001-04-03','3451730269','marcoro@gmail.com','Ravenna','Via Sabbionara 15','48124','Staff',2,2),(3,'Giulia','Giuliani','Femmina','2004-05-01','3191368174','giugiu@gmail.com','Ravenna','Via Trieste 76','48121','Barista',3,3),(4,'Marta','Torre','Femmina','1992-01-09','3952381428','marta@gmail.com','Ravenna','Giuseppe mazzini 30','48124','Tecnico',4,4),(5,'GianPierFrancesco','PierLuigiani','Maschio','2002-02-02','3952381428','pierGod@gmail.com','San Pancrazio','Via Molinaccio 1','48026','Staff',5,5);
/*!40000 ALTER TABLE `dipendente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gara`
--

DROP TABLE IF EXISTS `gara`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gara` (
  `IdGara` int(11) NOT NULL AUTO_INCREMENT,
  `NomeGara` varchar(40) NOT NULL,
  `DataGara` date NOT NULL,
  `Capienza` int(11) NOT NULL,
  `QuotaIscrizione` decimal(10,2) NOT NULL,
  `IscrittiAttuali` int(11) NOT NULL,
  `StatoGara` varchar(40) NOT NULL DEFAULT 'On',
  `IdModello` int(11) NOT NULL,
  `IdGioco` int(11) NOT NULL,
  PRIMARY KEY (`IdGara`),
  KEY `IdGioco` (`IdGioco`),
  KEY `IdModello` (`IdModello`),
  CONSTRAINT `gara_ibfk_2` FOREIGN KEY (`IdGioco`) REFERENCES `gioco` (`idGioco`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `gara_ibfk_3` FOREIGN KEY (`IdModello`) REFERENCES `modello` (`IdModello`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gara`
--

LOCK TABLES `gara` WRITE;
/*!40000 ALTER TABLE `gara` DISABLE KEYS */;
INSERT INTO `gara` VALUES (7,'Torneo fifa 21','2022-08-01',5,5.00,3,'End',2,2),(11,'Torneo WarZone','2022-08-31',5,6.00,2,'End',3,3),(12,'Torneo Pokemon','2022-08-23',10,6.00,0,'End',1,5),(13,'Torneo Fortnite Switch','2022-08-24',2,6.00,2,'End',1,6);
/*!40000 ALTER TABLE `gara` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gioco`
--

DROP TABLE IF EXISTS `gioco`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gioco` (
  `idGioco` int(11) NOT NULL AUTO_INCREMENT,
  `NomeGioco` varchar(40) NOT NULL,
  `MemoriaOccupata` int(11) NOT NULL,
  `IdCategoria` int(11) DEFAULT NULL,
  PRIMARY KEY (`idGioco`),
  KEY `IdCategoria` (`IdCategoria`),
  CONSTRAINT `gioco_ibfk_1` FOREIGN KEY (`IdCategoria`) REFERENCES `categoria` (`IdCategoria`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gioco`
--

LOCK TABLES `gioco` WRITE;
/*!40000 ALTER TABLE `gioco` DISABLE KEYS */;
INSERT INTO `gioco` VALUES (1,'Fifa 22',50,1),(2,'Fifa 21',50,1),(3,'Call of Duty: Warzone',30,10),(4,'Grand Theft Auto V',65,8),(5,'Pokémon Sword and Shield',5,7),(6,'Fortnite',15,10);
/*!40000 ALTER TABLE `gioco` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `listinoprezzo`
--

DROP TABLE IF EXISTS `listinoprezzo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `listinoprezzo` (
  `IdListino` int(11) NOT NULL AUTO_INCREMENT,
  `TempoListino` int(11) NOT NULL,
  `PrezzoListino` decimal(10,2) NOT NULL,
  PRIMARY KEY (`IdListino`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `listinoprezzo`
--

LOCK TABLES `listinoprezzo` WRITE;
/*!40000 ALTER TABLE `listinoprezzo` DISABLE KEYS */;
INSERT INTO `listinoprezzo` VALUES (1,1,5.00),(2,3,10.00),(3,8,20.00),(4,20,50.00);
/*!40000 ALTER TABLE `listinoprezzo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manutenzione`
--

DROP TABLE IF EXISTS `manutenzione`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manutenzione` (
  `IdManutenzione` int(11) NOT NULL AUTO_INCREMENT,
  `IdDevice` int(11) NOT NULL,
  `IdDipendente` int(11) NOT NULL,
  `DescrizioneManutenzione` varchar(40) NOT NULL,
  `CostoManutenzione` decimal(10,2) NOT NULL,
  `DataManutenzione` date NOT NULL,
  PRIMARY KEY (`IdManutenzione`) USING BTREE,
  KEY `IdDipendente` (`IdDipendente`),
  KEY `IdDevice` (`IdDevice`),
  CONSTRAINT `manutenzione_ibfk_3` FOREIGN KEY (`IdDipendente`) REFERENCES `dipendente` (`IdDipendente`),
  CONSTRAINT `manutenzione_ibfk_4` FOREIGN KEY (`IdDevice`) REFERENCES `device` (`IdDevice`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manutenzione`
--

LOCK TABLES `manutenzione` WRITE;
/*!40000 ALTER TABLE `manutenzione` DISABLE KEYS */;
INSERT INTO `manutenzione` VALUES (7,7,4,'no game',0.00,'2022-08-19'),(8,21,4,'Added Game',0.00,'2022-08-19'),(9,5,4,'Guasto Cavo',15.00,'2022-08-19'),(11,1,4,'Ssd guasto',75.00,'2022-08-20'),(12,1,4,'Add game',0.00,'2022-08-20');
/*!40000 ALTER TABLE `manutenzione` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modello`
--

DROP TABLE IF EXISTS `modello`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modello` (
  `IdModello` int(11) NOT NULL AUTO_INCREMENT,
  `NomeModello` varchar(40) NOT NULL,
  `MemoriaDisponibile` int(11) NOT NULL,
  PRIMARY KEY (`IdModello`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modello`
--

LOCK TABLES `modello` WRITE;
/*!40000 ALTER TABLE `modello` DISABLE KEYS */;
INSERT INTO `modello` VALUES (1,'Nintendo Switch 32gb',32),(2,'PlayStation 4',500),(3,'PlayStation 5',825),(4,'Xbox 360',500),(5,'Xbox One',500),(6,'Xbox Series X',1000);
/*!40000 ALTER TABLE `modello` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordine`
--

DROP TABLE IF EXISTS `ordine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ordine` (
  `IdOrdine` int(11) NOT NULL,
  `DataAcquisto` date NOT NULL,
  `PrezzoTotale` decimal(10,2) NOT NULL,
  `PuntiPremioTotale` int(11) DEFAULT NULL,
  `IdDipendente` int(11) NOT NULL,
  `IdCliente` int(11) DEFAULT NULL,
  PRIMARY KEY (`IdOrdine`),
  KEY `IdDipendente` (`IdDipendente`),
  KEY `IdCliente` (`IdCliente`),
  CONSTRAINT `ordine_ibfk_1` FOREIGN KEY (`IdCliente`) REFERENCES `cliente` (`IdCliente`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ordine_ibfk_2` FOREIGN KEY (`IdDipendente`) REFERENCES `dipendente` (`IdDipendente`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordine`
--

LOCK TABLES `ordine` WRITE;
/*!40000 ALTER TABLE `ordine` DISABLE KEYS */;
INSERT INTO `ordine` VALUES (7,'2022-08-21',6.30,NULL,3,NULL),(8,'2022-08-21',4.50,3,3,2),(9,'2022-08-21',15.00,NULL,3,NULL),(10,'2022-08-21',4.25,3,3,4),(11,'2022-08-21',12.25,8,3,1),(12,'2022-08-22',9.50,10,3,2),(13,'2022-08-22',5.00,3,3,1),(14,'2022-08-22',9.00,NULL,3,NULL);
/*!40000 ALTER TABLE `ordine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `premio`
--

DROP TABLE IF EXISTS `premio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `premio` (
  `IdPremio` int(11) NOT NULL AUTO_INCREMENT,
  `NomePremio` varchar(40) NOT NULL,
  `PuntiPremioNecessari` int(11) NOT NULL,
  `QuantitàPremioResidua` int(11) NOT NULL,
  PRIMARY KEY (`IdPremio`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `premio`
--

LOCK TABLES `premio` WRITE;
/*!40000 ALTER TABLE `premio` DISABLE KEYS */;
INSERT INTO `premio` VALUES (1,'Orsetto',5,5),(2,'Xiaomi Redmi 9',200,2),(3,'Nintendo switch',150,3),(4,'Huawei Gt2 smartwatch',80,0),(5,'Steam gift card 10€',10,10),(6,'Ps5',350,1);
/*!40000 ALTER TABLE `premio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prodotto`
--

DROP TABLE IF EXISTS `prodotto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prodotto` (
  `IdProdotto` int(11) NOT NULL AUTO_INCREMENT,
  `NomeProdotto` varchar(40) NOT NULL,
  `PrezzoProdotto` decimal(10,2) NOT NULL,
  `PuntiPremioRegalo` int(11) NOT NULL,
  PRIMARY KEY (`IdProdotto`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prodotto`
--

LOCK TABLES `prodotto` WRITE;
/*!40000 ALTER TABLE `prodotto` DISABLE KEYS */;
INSERT INTO `prodotto` VALUES (1,'Panino con prosciutto cotto',3.50,2),(2,'Panino con prosciutto crudo',4.00,2),(3,'Panino con cheese',3.50,2),(4,'Panino con prosciutto + formag',5.50,3),(5,'acqua 33cl',1.00,1),(6,'Coca-Cola 33cl',1.00,1),(7,'Pepsi 33cl',1.50,1),(8,'Patatine',2.00,2);
/*!40000 ALTER TABLE `prodotto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pubblicizzazione`
--

DROP TABLE IF EXISTS `pubblicizzazione`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pubblicizzazione` (
  `idGara` int(11) NOT NULL,
  `idSponsor` int(11) NOT NULL,
  `QuotaSponsorizzazione` decimal(10,2) NOT NULL,
  PRIMARY KEY (`idGara`,`idSponsor`),
  KEY `idSponsor` (`idSponsor`),
  KEY `idGara` (`idGara`),
  CONSTRAINT `pubblicizzazione_ibfk_1` FOREIGN KEY (`idGara`) REFERENCES `gara` (`IdGara`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pubblicizzazione_ibfk_2` FOREIGN KEY (`idSponsor`) REFERENCES `sponsor` (`IdSponsor`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pubblicizzazione`
--

LOCK TABLES `pubblicizzazione` WRITE;
/*!40000 ALTER TABLE `pubblicizzazione` DISABLE KEYS */;
INSERT INTO `pubblicizzazione` VALUES (7,3,6052.50),(11,4,56456.00);
/*!40000 ALTER TABLE `pubblicizzazione` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ricarica`
--

DROP TABLE IF EXISTS `ricarica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ricarica` (
  `IdRicarica` int(11) NOT NULL,
  `DataRicarica` date NOT NULL,
  `PrezzoTotaleRicarica` decimal(10,2) NOT NULL,
  `NumeroOreTotali` int(11) NOT NULL,
  `IdDipendente` int(11) NOT NULL,
  `IdCliente` int(11) NOT NULL,
  PRIMARY KEY (`IdRicarica`),
  KEY `IdDipendente` (`IdDipendente`),
  KEY `IdCliente` (`IdCliente`),
  CONSTRAINT `ricarica_ibfk_1` FOREIGN KEY (`IdCliente`) REFERENCES `cliente` (`IdCliente`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ricarica_ibfk_2` FOREIGN KEY (`IdDipendente`) REFERENCES `dipendente` (`IdDipendente`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ricarica`
--

LOCK TABLES `ricarica` WRITE;
/*!40000 ALTER TABLE `ricarica` DISABLE KEYS */;
INSERT INTO `ricarica` VALUES (1,'2022-07-12',25.00,5,1,1),(2,'2022-08-23',15.00,4,1,4),(3,'2022-08-23',20.00,8,1,7);
/*!40000 ALTER TABLE `ricarica` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `riscossione`
--

DROP TABLE IF EXISTS `riscossione`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `riscossione` (
  `IdRiscossione` int(11) NOT NULL AUTO_INCREMENT,
  `IdCliente` int(11) NOT NULL,
  `IdPremio` int(11) NOT NULL,
  `QuantitàRiscossione` int(11) NOT NULL,
  `CostoPremio` int(11) NOT NULL,
  PRIMARY KEY (`IdRiscossione`) USING BTREE,
  KEY `IdCliente` (`IdCliente`),
  KEY `IdPremio` (`IdPremio`),
  CONSTRAINT `riscossione_ibfk_1` FOREIGN KEY (`IdPremio`) REFERENCES `premio` (`IdPremio`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `riscossione_ibfk_2` FOREIGN KEY (`IdCliente`) REFERENCES `cliente` (`IdCliente`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `riscossione`
--

LOCK TABLES `riscossione` WRITE;
/*!40000 ALTER TABLE `riscossione` DISABLE KEYS */;
INSERT INTO `riscossione` VALUES (1,1,1,1,20),(2,1,4,1,80),(3,2,4,1,80);
/*!40000 ALTER TABLE `riscossione` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sala`
--

DROP TABLE IF EXISTS `sala`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sala` (
  `IdSala` int(11) NOT NULL AUTO_INCREMENT,
  `CapienzaMassimaSala` int(11) NOT NULL,
  `CapienzaAttuale` int(11) NOT NULL,
  PRIMARY KEY (`IdSala`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sala`
--

LOCK TABLES `sala` WRITE;
/*!40000 ALTER TABLE `sala` DISABLE KEYS */;
INSERT INTO `sala` VALUES (1,10,6),(2,5,2),(3,10,3),(4,5,2),(5,5,2),(6,10,2),(12,5,0);
/*!40000 ALTER TABLE `sala` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sponsor`
--

DROP TABLE IF EXISTS `sponsor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sponsor` (
  `IdSponsor` int(11) NOT NULL AUTO_INCREMENT,
  `NomeSponsor` varchar(40) NOT NULL,
  `ContattoSponsor` varchar(40) NOT NULL,
  `EmailSponsor` varchar(40) NOT NULL,
  PRIMARY KEY (`IdSponsor`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sponsor`
--

LOCK TABLES `sponsor` WRITE;
/*!40000 ALTER TABLE `sponsor` DISABLE KEYS */;
INSERT INTO `sponsor` VALUES (1,'GearNow','3264494219','gear@gmail.com'),(3,'GameLove','3795162644','GameLoveOfficial@gmail.com'),(4,'Prosciutti&Prosciutti','3131918361','2Prosciutti@gmail.com'),(5,'LanBoy','3582555722','LanBoy@gmail.com'),(6,'GamingControl','3166927512','gc@gmail.com');
/*!40000 ALTER TABLE `sponsor` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-23 19:33:51
