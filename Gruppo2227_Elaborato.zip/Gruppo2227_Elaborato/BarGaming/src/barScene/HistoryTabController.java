package barScene;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

import connection.ConnectionProvider;
import connection.Utils;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import models.Client;
import models.Order;
import models.OrderDetail;
import models.Product;
import tables.ClientTable;
import tables.OrderTable;

class JoinOrderClientModel {
    private Order order;
    private Client client;

    public JoinOrderClientModel(Order order, Client client) {
        this.order = order;
        this.client = client;

    }

    public Order getOrder() {
        return order;
    }

    public Client getClient() {
        return client;
    }

}

class JoinDetailProductModel {
    private OrderDetail orderDetail;
    private Product product;

    public JoinDetailProductModel(OrderDetail orderDetail, Product product) {
        this.orderDetail = orderDetail;
        this.product = product;

    }

    public OrderDetail getOrderDetail() {
        return orderDetail;
    }

    public Product getProduct() {
        return product;
    }

}

public class HistoryTabController implements Initializable {
    final static String username = "root";
    final static String password = "";
    final static String dbName = "databasegigi";

    final ConnectionProvider connectionProvider = new ConnectionProvider(username, password, dbName);
    final ClientTable clientTable = new ClientTable(connectionProvider.getMySQLConnection());
    final OrderTable orderTable = new OrderTable(connectionProvider.getMySQLConnection());
    final Connection con = connectionProvider.getMySQLConnection();
    @FXML
    private TableColumn<Client, Integer> clientIdColumn;

    @FXML
    private TableView<JoinOrderClientModel> joinTableView;

    @FXML
    private Button findOrderOfClientButton;

    @FXML
    private TableColumn<JoinOrderClientModel, Integer> joinOrderIdColumn;

    @FXML
    private TableColumn<JoinOrderClientModel, String> joinClientLastNameColumn;

    @FXML
    private ComboBox<Integer> searchClientOrderCombo;

    @FXML
    private TableColumn<JoinOrderClientModel, String> joinDateColumn;

    @FXML
    private TableColumn<JoinDetailProductModel, Double> detailTotalPriceColumn;

    @FXML
    private ComboBox<Integer> searchOrderIdCombo;

    @FXML
    private TableColumn<Client, String> clientLastNameColumn;

    @FXML
    private TableColumn<JoinDetailProductModel, Integer> detailProductidColumn;

    @FXML
    private TableColumn<Client, String> clientPhoneColumn;

    @FXML
    private TableColumn<JoinDetailProductModel, String> detailDiscountColumn;

    @FXML
    private TextField findLastName;

    @FXML
    private Button showAllOrderButton;

    @FXML
    private TextField findName;

    @FXML
    private TableColumn<JoinOrderClientModel, Integer> joinClientIdColumn;

    @FXML
    private TableColumn<JoinDetailProductModel, String> detailNameColumn;

    @FXML
    private TableColumn<Client, String> clientNameColumn;

    @FXML
    private TableColumn<JoinOrderClientModel, Double> joinTotalPriceColumn;

    @FXML
    private TableColumn<Client, String> clientTimeColumn;

    @FXML
    private TableColumn<JoinDetailProductModel, Double> detailUnitPriceColumn;

    @FXML
    private TableColumn<JoinDetailProductModel, Integer> detailQuantityColumn;

    @FXML
    private TableColumn<Client, Integer> clientPointsColumn;

    @FXML
    private Button searchDetailOrderButton;

    @FXML
    private TableColumn<JoinOrderClientModel, Integer> joinPointsColumn;

    @FXML
    private Button findClientButton;

    @FXML
    private TableView<JoinDetailProductModel> orderDetailTableView;

    @FXML
    private TableColumn<JoinDetailProductModel, Integer> detailPointsColumn;

    @FXML
    private TableColumn<Client, String> clientEmailColumn;

    @FXML
    private TableColumn<JoinOrderClientModel, String> joinClientnameColumn;

    @FXML
    private TableView<Client> clientTableView;

    private ObservableList<JoinOrderClientModel> readJoinOrderClientFromResultSet(final ResultSet resultSet) {
        ObservableList<JoinOrderClientModel> listJoin = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {

                JoinOrderClientModel newObject = new JoinOrderClientModel(new Order(resultSet.getInt("IdOrdine"),
                        Optional.ofNullable(resultSet.getInt("IdCliente")), resultSet.getInt("IdDipendente"),
                        Utils.sqlDateToDate(resultSet.getDate("DataAcquisto")), resultSet.getDouble("PrezzoTotale"),
                        Optional.ofNullable(resultSet.getInt("PuntiPremioTotale"))),
                        new Client(resultSet.getInt("idCliente"), resultSet.getString("NomeCliente"),
                                resultSet.getString("CognomeCliente"), resultSet.getString("GenereCliente"),
                                Utils.sqlDateToDate(resultSet.getDate("DataDiNascitaCliente")),
                                resultSet.getString("TelefonoCliente"), resultSet.getString("EmailCliente"),
                                resultSet.getString("PinCliente"), resultSet.getString("Città"),
                                resultSet.getString("Via"), resultSet.getString("CodicePostale"),
                                resultSet.getString("Tempo"), resultSet.getInt("PuntiPremio")));
                listJoin.add(newObject);
            }

        } catch (

        SQLException e) {
            e.printStackTrace();
        }
        return listJoin;
    }

    private ObservableList<JoinOrderClientModel> findAllJoinOrderClient() {
        try (final Statement statement = this.con.createStatement()) {
            final ResultSet rs = statement
                    .executeQuery("SELECT *  FROM ordine o LEFT JOIN cliente c ON o.IdCliente = c.IdCliente ");
            return readJoinOrderClientFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    private ObservableList<JoinOrderClientModel> findAllJoinOrderByClient() {
        try (final Statement statement = this.con.createStatement()) {
            final ResultSet rs = statement.executeQuery(
                    "SELECT *  FROM ordine o, cliente c WHERE o.IdCliente = c.IdCliente AND c.IdCliente = "
                            + searchClientOrderCombo.getValue());
            return readJoinOrderClientFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    private ObservableList<JoinDetailProductModel> readJoinDetailProductFromResultSet(final ResultSet resultSet) {
        ObservableList<JoinDetailProductModel> listJoin = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {
                JoinDetailProductModel newObject = new JoinDetailProductModel(
                        new OrderDetail(resultSet.getInt("IdProdotto"), resultSet.getInt("IdOrdine"),
                                resultSet.getInt("QuantitàAcquisto"), resultSet.getDouble("PrezzoUnitario"),
                                resultSet.getDouble("PrezzoTotale"), resultSet.getInt("PuntiPremioRegaloPerProdotto"),
                                Optional.ofNullable(resultSet.getInt("Sconto"))),
                        new Product(resultSet.getInt("IdProdotto"), resultSet.getString("NomeProdotto"),
                                resultSet.getDouble("PrezzoProdotto"), resultSet.getInt("PuntiPremioRegalo")));
                listJoin.add(newObject);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listJoin;
    }

    private ObservableList<JoinDetailProductModel> findAllJoinDetailProduct() {
        try (final Statement statement = this.con.createStatement()) {
            final ResultSet rs = statement.executeQuery(
                    "SELECT *  FROM dettaglio_acquisto d, prodotto p WHERE d.IdProdotto = p.IdProdotto AND d.IdOrdine = "
                            + searchOrderIdCombo.getValue());
            return readJoinDetailProductFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public void refresh() {
        searchClientOrderCombo.setItems(clientTable.findAll().stream().map(e -> e.getIdClient())
                .collect(Collectors.toCollection(FXCollections::observableArrayList)));
        searchOrderIdCombo.setItems(orderTable.findAll().stream().map(e -> e.getIdOrder())
                .collect(Collectors.toCollection(FXCollections::observableArrayList)));

        ObservableList<JoinOrderClientModel> list2 = this.findAllJoinOrderClient();
        joinTableView.setItems(list2);
        ObservableList<Client> list3 = clientTable.findAll();
        clientTableView.setItems(list3);
    }

    private void initializeJoinOrderClientTable() {
        joinOrderIdColumn
                .setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getOrder().getIdOrder()).asObject());
        joinDateColumn.setCellValueFactory(e -> {
            SimpleStringProperty property = new SimpleStringProperty();
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            property.setValue(dateFormat.format(e.getValue().getOrder().getOrderDay()));
            return property;
        });
        joinTotalPriceColumn.setCellValueFactory(
                e -> new SimpleDoubleProperty(e.getValue().getOrder().getOrderTotalPrice()).asObject());
        joinPointsColumn.setCellValueFactory(
                e -> new SimpleIntegerProperty(e.getValue().getOrder().getOrderGiftPoints().get()).asObject());
        joinClientIdColumn
                .setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getClient().getIdClient()).asObject());
        joinClientnameColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getClient().getName()));
        joinClientLastNameColumn
                .setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getClient().getLastName()));
    }

    private void initializeJoinDetailOrderTable() {
        detailProductidColumn.setCellValueFactory(
                e -> new SimpleIntegerProperty(e.getValue().getProduct().getIdProduct()).asObject());
        detailNameColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getProduct().getProductName()));
        detailQuantityColumn.setCellValueFactory(
                e -> new SimpleIntegerProperty(e.getValue().getOrderDetail().getQuantity()).asObject());
        detailUnitPriceColumn.setCellValueFactory(
                e -> new SimpleDoubleProperty(e.getValue().getOrderDetail().getUnityPrice()).asObject());
        detailTotalPriceColumn.setCellValueFactory(
                e -> new SimpleDoubleProperty(e.getValue().getOrderDetail().getTotalPrice()).asObject());
        detailDiscountColumn.setCellValueFactory(
                e -> new SimpleStringProperty(e.getValue().getOrderDetail().getDiscount().get().toString()));
        detailPointsColumn.setCellValueFactory(
                e -> new SimpleIntegerProperty(e.getValue().getOrderDetail().getGiftPointsPerProduct()).asObject());
    }

    private void initializeClientTable() {
        clientIdColumn.setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getIdClient()).asObject());
        clientLastNameColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getLastName()));
        clientNameColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getName()));
        clientTimeColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getTime()));
        clientEmailColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getEmail()));
        clientPhoneColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getPhoneNumber()));
        clientPointsColumn.setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getGiftPoints()).asObject());
    }

    @FXML
    void findOrderOfClient(ActionEvent event) {
        this.findOrderOfClientButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (searchClientOrderCombo.getValue() != null) {
                        joinTableView.setItems(findAllJoinOrderByClient());
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Select a client id!");
                        nullLabels.showAndWait();
                    }
                }
                cleanLabels();
            }
        });
    }

    @FXML
    void findClient(ActionEvent event) {
        this.findClientButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!findLastName.getText().isEmpty() && !findName.getText().isEmpty()) {
                        clientTableView.setItems(
                                clientTable.findByNameAndLastName(findName.getText(), findLastName.getText()));
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Empty label");
                        nullLabels.showAndWait();
                    }
                }
                cleanLabels();
            }
        });
    }

    @FXML
    void searchDetailOrder(ActionEvent event) {
        this.searchDetailOrderButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (searchOrderIdCombo.getValue() != null) {
                        System.out.println("casc");
                        orderDetailTableView.setItems(findAllJoinDetailProduct());
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Select a order id!");
                        nullLabels.showAndWait();
                    }
                }
                cleanLabels();
            }
        });
    }

    @FXML
    void showAllOrder(ActionEvent event) {
        this.showAllOrderButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    joinTableView.setItems(findAllJoinOrderClient());
                    refresh();
                }
            }
        });
    }

    private void cleanLabels() {
        searchClientOrderCombo.setValue(null);
        searchOrderIdCombo.setValue(null);
        findName.setText("");
        findLastName.setText("");
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        // TODO Auto-generated method stub
        initializeJoinOrderClientTable();
        initializeJoinDetailOrderTable();
        initializeClientTable();
        refresh();
    }

}
