package barScene;

import java.net.URL;
import java.sql.Connection;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.stream.Collectors;
import connection.ConnectionProvider;
import connection.Utils;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import models.Client;
import models.Order;
import models.OrderDetail;
import models.Product;
import tables.ClientTable;
import tables.OrderDetailTable;
import tables.OrderTable;
import tables.ProductTable;
import javafx.fxml.Initializable;

public class BarTabController implements Initializable {
    private static int SCONTOMAX = 50;
    private String textToShow = "";
    private List<OrderDetail> listProd = new ArrayList<OrderDetail>();
    private List<Integer> listIdProd = new ArrayList<Integer>();
    final static String username = "root";
    final static String password = "";
    final static String dbName = "databasegigi";

    final ConnectionProvider connectionProvider = new ConnectionProvider(username, password, dbName);
    final ClientTable clientTable = new ClientTable(connectionProvider.getMySQLConnection());
    final ProductTable productTable = new ProductTable(connectionProvider.getMySQLConnection());
    final OrderDetailTable orderDetailTable = new OrderDetailTable(connectionProvider.getMySQLConnection());
    final OrderTable orderTable = new OrderTable(connectionProvider.getMySQLConnection());
    final Connection con = connectionProvider.getMySQLConnection();

    public void initData(int id) {
        idEmpLabel.setText(String.valueOf(id));
    }

    @FXML
    private TableColumn<Client, Integer> clientIdColumn;

    @FXML
    private ComboBox<Integer> productidCombo;

    @FXML
    private TextField findLastName;

    @FXML
    private TextField quantity;

    @FXML
    private Button addToListButton;

    @FXML
    private TextArea totalPrice;

    @FXML
    private TextField findName;

    @FXML
    private TextField discount;

    @FXML
    private Label idEmpLabel;

    @FXML
    private Button addNewOrder;

    @FXML
    private TableColumn<Client, String> clientNameColumn;

    @FXML
    private ComboBox<Integer> clientIdCombo;

    @FXML
    private TableColumn<Product, Integer> productIdColumn;

    @FXML
    private TableColumn<Product, Double> productPriceColumn;

    @FXML
    private TableView<Product> productTableView;

    @FXML
    private TableColumn<Product, Integer> productPointsColumn;

    @FXML
    private TextArea totalPoints;

    @FXML
    private Button findClient;

    @FXML
    private TableColumn<Product, String> productNameColumn;

    @FXML
    private Button removeAllListButton;

    @FXML
    private TableColumn<Client, String> clientLastNameColumn;

    @FXML
    private TableColumn<Client, String> clientTimeColumn;

    @FXML
    private TableColumn<Client, Integer> clientPointsColumn;

    @FXML
    private TextArea textArea;

    @FXML
    private TableView<Client> clientTableView;

    @FXML
    void addnewOrder(ActionEvent event) {
        this.addNewOrder.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                int numOrd = orderTable.findAll().stream().max(Comparator.comparing(models.Order::getIdOrder)).get()
                        .getIdOrder() + 1;
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!listProd.isEmpty()) {
                        if (clientIdCombo.getValue() != null) {
                            orderTable.save(new Order(numOrd, Optional.of(clientIdCombo.getValue()),
                                    Integer.valueOf(idEmpLabel.getText()), java.sql.Date.valueOf(LocalDate.now()),
                                    Double.valueOf(totalPrice.getText()),
                                    Optional.of(Integer.valueOf(totalPoints.getText()))));
                            clientTable.updatePointsShop(clientIdCombo.getValue(),
                                    Integer.valueOf(totalPoints.getText()));

                        } else {

                            orderTable.save(new Order(numOrd, Optional.ofNullable(null),
                                    Integer.valueOf(idEmpLabel.getText()), java.sql.Date.valueOf(LocalDate.now()),
                                    Double.valueOf(totalPrice.getText()), Optional.ofNullable(null)));

                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Empty list");
                        nullLabels.showAndWait();
                    }
                    for (OrderDetail p : listProd) {
                        orderDetailTable.save(p);
                    }
                    cleanLabels();
                    listProd.clear();
                    listIdProd.clear();
                    textToShow = "";
                    refresh();
                }
            }
        });
    }

    @FXML
    void addToList(ActionEvent event) {
        this.addToListButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) { // TODO Auto-generated
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (productidCombo.getValue() != null && !quantity.getText().isEmpty()) {
                        if (Utils.isNumeric(quantity.getText())) {
                            if (Integer.valueOf(quantity.getText()) > 0) {
                                if (!discount.getText().isEmpty() ? Integer.valueOf(discount.getText()) <= SCONTOMAX
                                        : true) {
                                    if (!listIdProd.contains(productidCombo.getValue())) {
                                        Product newPro = productTable.findByPrimaryKey(productidCombo.getValue()).get();
                                        int numOrd = orderTable.findAll().stream()
                                                .max(Comparator.comparing(models.Order::getIdOrder)).get().getIdOrder()
                                                + 1;

                                        int prodQuantity = Integer.valueOf(quantity.getText());
                                        OrderDetail newOrd = new OrderDetail(newPro.getIdProduct(), numOrd,
                                                prodQuantity, newPro.getProductPrice(),
                                                newPro.getProductPrice() * prodQuantity * (!discount.getText().isEmpty()
                                                        ? (Double.valueOf(100.0 - Integer.valueOf(discount.getText()))
                                                                / 100.0)
                                                        : 1),
                                                newPro.getProductGiftPo() * prodQuantity,
                                                Optional.ofNullable(!discount.getText().isEmpty()
                                                        ? Integer.valueOf(discount.getText())
                                                        : null));
                                        listIdProd.add(productidCombo.getValue());
                                        listProd.add(newOrd);
                                        textToShow = textToShow.concat(newOrd.toString() + "\n");
                                        textArea.setText(textToShow);
                                        Double totalPri = listProd.stream().mapToDouble(e -> e.getTotalPrice()).sum();
                                        int totalPo = listProd.stream().mapToInt(e -> e.getGiftPointsPerProduct())
                                                .sum();
                                        totalPrice.setText(totalPri.toString());
                                        totalPoints.setText(String.valueOf(totalPo));
                                    } else {
                                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                                        nullLabels.setContentText("Already have product in the shopping list!");
                                        nullLabels.showAndWait();
                                    }
                                } else {
                                    Alert nullLabels = new Alert(AlertType.INFORMATION);
                                    nullLabels.setContentText("Max Discount is 50!\nPlease insert a value under 50");
                                    nullLabels.showAndWait();
                                }
                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("Quantity must be greater than one!");
                                nullLabels.showAndWait();
                            }
                        }

                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                }
            }
        });
    }

    @FXML
    void findClient(ActionEvent event) {
        this.findClient.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!findLastName.getText().isEmpty() && !findName.getText().isEmpty()) {
                        clientTableView.setItems(
                                clientTable.findByNameAndLastName(findName.getText(), findLastName.getText()));
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Empty label");
                        nullLabels.showAndWait();
                    }
                }
                cleanLabels();
            }
        });
    }

    @FXML
    void clearList(ActionEvent event) {
        this.removeAllListButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    cleanLabels();
                    listProd.clear();
                    listIdProd.clear();
                    textToShow = "";
                    refresh();
                }
            }
        });
    }

    private void cleanLabels() {
        textArea.setText("");
        productidCombo.setValue(null);
        clientIdCombo.setValue(null);
        discount.setText("");
        totalPrice.setText("");
        totalPoints.setText("");
        quantity.setText("");
        findName.setText("");
        findLastName.setText("");
    }

    public void refresh() {
        productidCombo.setItems(productTable.findAll().stream().map(e -> e.getIdProduct())
                .collect(Collectors.toCollection(FXCollections::observableArrayList)));
        clientIdCombo.setItems(clientTable.findAll().stream().map(e -> e.getIdClient())
                .collect(Collectors.toCollection(FXCollections::observableArrayList)));
        ObservableList<Product> list1 = productTable.findAll();
        productTableView.setItems(list1);
        ObservableList<Client> list2 = clientTable.findAll();
        clientTableView.setItems(list2);
    }

    private void initializePrizeTable() {
        productIdColumn.setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getIdProduct()).asObject());
        productNameColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getProductName()));
        productPriceColumn
                .setCellValueFactory(e -> new SimpleDoubleProperty(e.getValue().getProductPrice()).asObject());
        productPointsColumn
                .setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getProductGiftPo()).asObject());
    }

    private void initializeClientTable() {
        clientIdColumn.setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getIdClient()).asObject());
        clientLastNameColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getLastName()));
        clientNameColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getName()));
        clientTimeColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getTime()));
        clientPointsColumn.setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getGiftPoints()).asObject());
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        // TODO Auto-generated method stub
        initializePrizeTable();
        initializeClientTable();
        refresh();

    }

}
