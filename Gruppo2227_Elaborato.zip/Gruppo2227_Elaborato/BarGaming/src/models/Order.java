package models;

import java.util.Date;
import java.util.Objects;
import java.util.Optional;

public class Order {
    private final int idOrder;
    private final Optional<Integer> idClient;
    private final int idEmployee;
    private Date orderDay;
    private double orderTotalPrice;
    private Optional<Integer> orderGiftPoints;

    public Order(int idOrder, Optional<Integer> idClient, int idEmployee, Date orderDay, double orderTotalPrice,
            Optional<Integer> orderGiftPoints) {
        this.idOrder = idOrder;
        this.idClient = idClient;
        this.idEmployee = Objects.requireNonNull(idEmployee);
        this.orderDay = Objects.requireNonNull(orderDay);
        this.orderTotalPrice = Objects.requireNonNull(orderTotalPrice);
        this.orderGiftPoints = orderGiftPoints;
    }

    public int getIdOrder() {
        return idOrder;
    }

    public Optional<Integer> getIdClient() {
        return idClient;
    }

    public int getIdEmployee() {
        return idEmployee;
    }

    public Date getOrderDay() {
        return orderDay;
    }

    public double getOrderTotalPrice() {
        return orderTotalPrice;
    }

    public Optional<Integer> getOrderGiftPoints() {
        return orderGiftPoints;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((idClient == null) ? 0 : idClient.hashCode());
        result = prime * result + idEmployee;
        result = prime * result + idOrder;
        result = prime * result + ((orderDay == null) ? 0 : orderDay.hashCode());
        result = prime * result + ((orderGiftPoints == null) ? 0 : orderGiftPoints.hashCode());
        long temp;
        temp = Double.doubleToLongBits(orderTotalPrice);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Order other = (Order) obj;
        if (idClient == null) {
            if (other.idClient != null)
                return false;
        } else if (!idClient.equals(other.idClient))
            return false;
        if (idEmployee != other.idEmployee)
            return false;
        if (idOrder != other.idOrder)
            return false;
        if (orderDay == null) {
            if (other.orderDay != null)
                return false;
        } else if (!orderDay.equals(other.orderDay))
            return false;
        if (orderGiftPoints == null) {
            if (other.orderGiftPoints != null)
                return false;
        } else if (!orderGiftPoints.equals(other.orderGiftPoints))
            return false;
        if (Double.doubleToLongBits(orderTotalPrice) != Double.doubleToLongBits(other.orderTotalPrice))
            return false;
        return true;
    }

}
