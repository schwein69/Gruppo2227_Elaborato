package models;

import java.util.Date;
import java.util.Objects;

public class Match {
    private final int idMatch;
    private final int idModel;
    private final int idGame;
    private String matchName;
    private Date matchDate;
    private int capacity;
    private int actualPerson;
    private String state;
    private double price;

    public Match(int idMatch, int idModel, int idGame, String matchName, Date matchDate, int capacity, int actualPerson,
            String state, double price) {
        this.idMatch = idMatch;
        this.idModel = Objects.requireNonNull(idModel);
        this.idGame = Objects.requireNonNull(idGame);
        this.matchName = Objects.requireNonNull(matchName);
        this.matchDate = Objects.requireNonNull(matchDate);
        this.capacity = Objects.requireNonNull(capacity);
        this.price = Objects.requireNonNull(price);
        this.actualPerson = Objects.requireNonNull(actualPerson);
        this.state = Objects.requireNonNull(state);

    }

    public String getMatchName() {
        return matchName;
    }

    public void setMatchName(String matchName) {
        this.matchName = matchName;
    }

    public Date getMatchDate() {
        return matchDate;
    }

    public void setMatchDate(Date matchDate) {
        this.matchDate = matchDate;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public int getActualPerson() {
        return actualPerson;
    }

    public void setActualPerson(int actualPerson) {
        this.actualPerson = actualPerson;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getIdMatch() {
        return idMatch;
    }

    public int getIdModel() {
        return idModel;
    }

    public int getIdGame() {
        return idGame;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + actualPerson;
        result = prime * result + capacity;
        result = prime * result + idGame;
        result = prime * result + idMatch;
        result = prime * result + idModel;
        result = prime * result + ((matchDate == null) ? 0 : matchDate.hashCode());
        result = prime * result + ((matchName == null) ? 0 : matchName.hashCode());
        long temp;
        temp = Double.doubleToLongBits(price);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        result = prime * result + ((state == null) ? 0 : state.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Match other = (Match) obj;
        if (actualPerson != other.actualPerson)
            return false;
        if (capacity != other.capacity)
            return false;
        if (idGame != other.idGame)
            return false;
        if (idMatch != other.idMatch)
            return false;
        if (idModel != other.idModel)
            return false;
        if (matchDate == null) {
            if (other.matchDate != null)
                return false;
        } else if (!matchDate.equals(other.matchDate))
            return false;
        if (matchName == null) {
            if (other.matchName != null)
                return false;
        } else if (!matchName.equals(other.matchName))
            return false;
        if (Double.doubleToLongBits(price) != Double.doubleToLongBits(other.price))
            return false;
        if (state == null) {
            if (other.state != null)
                return false;
        } else if (!state.equals(other.state))
            return false;
        return true;
    }

}
