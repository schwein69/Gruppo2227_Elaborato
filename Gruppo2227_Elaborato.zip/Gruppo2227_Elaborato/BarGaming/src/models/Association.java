package models;

public class Association {
    private final int idDevice;
    private final int idGame;

    public Association(int idDevice, int idGame) {
        this.idDevice = idDevice;
        this.idGame = idGame;
    }

    public int getIdDevice() {
        return idDevice;
    }

    public int getIdGame() {
        return idGame;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + idDevice;
        result = prime * result + idGame;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Association other = (Association) obj;
        if (idDevice != other.idDevice)
            return false;
        if (idGame != other.idGame)
            return false;
        return true;
    }

}
