package models;

import java.util.Objects;

public class Advisement {
    private final int idMatch;
    private final int idSponsor;
    private double sponsorization;

    public Advisement(int idMatch, int idSponsor, double sponsorization) {
        this.idMatch = idMatch;
        this.idSponsor = idSponsor;
        this.sponsorization = Objects.requireNonNull(sponsorization);
    }

    public int getIdMatch() {
        return idMatch;
    }

    public int getIdSponsor() {
        return idSponsor;
    }

    public double getSponsorization() {
        return sponsorization;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + idMatch;
        result = prime * result + idSponsor;
        long temp;
        temp = Double.doubleToLongBits(sponsorization);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Advisement other = (Advisement) obj;
        if (idMatch != other.idMatch)
            return false;
        if (idSponsor != other.idSponsor)
            return false;
        if (Double.doubleToLongBits(sponsorization) != Double.doubleToLongBits(other.sponsorization))
            return false;
        return true;
    }

}
