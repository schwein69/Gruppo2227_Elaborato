package models;

import java.util.Date;
import java.util.Objects;

public class Recharge {
    private final int idRecharge;
    private final int idClient;
    private final int idEmployee;
    private Date rechargeDay;
    private double rechargeTotalPrice;
    private int totalHours;

    public Recharge(int idRecharge, int idClient, int idEmployee, Date rechargeDay, double rechargeTotalPrice,
            int totalHours) {
        this.idRecharge = idRecharge;
        this.idClient = Objects.requireNonNull(idClient);
        this.idEmployee = Objects.requireNonNull(idEmployee);
        this.rechargeDay = Objects.requireNonNull(rechargeDay);
        this.rechargeTotalPrice = Objects.requireNonNull(rechargeTotalPrice);
        this.totalHours = Objects.requireNonNull(totalHours);
    }

    public int getIdRecharge() {
        return idRecharge;
    }

    public int getIdClient() {
        return idClient;
    }

    public int getIdEmployee() {
        return idEmployee;
    }

    public Date getRechargeDay() {
        return rechargeDay;
    }

    public double getRechargeTotalPrice() {
        return rechargeTotalPrice;
    }

    public int getTotalHours() {
        return totalHours;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + idClient;
        result = prime * result + idEmployee;
        result = prime * result + idRecharge;
        result = prime * result + ((rechargeDay == null) ? 0 : rechargeDay.hashCode());
        long temp;
        temp = Double.doubleToLongBits(rechargeTotalPrice);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(totalHours);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Recharge other = (Recharge) obj;
        if (idClient != other.idClient)
            return false;
        if (idEmployee != other.idEmployee)
            return false;
        if (idRecharge != other.idRecharge)
            return false;
        if (rechargeDay == null) {
            if (other.rechargeDay != null)
                return false;
        } else if (!rechargeDay.equals(other.rechargeDay))
            return false;
        if (Double.doubleToLongBits(rechargeTotalPrice) != Double.doubleToLongBits(other.rechargeTotalPrice))
            return false;
        if (Double.doubleToLongBits(totalHours) != Double.doubleToLongBits(other.totalHours))
            return false;
        return true;
    }

}
