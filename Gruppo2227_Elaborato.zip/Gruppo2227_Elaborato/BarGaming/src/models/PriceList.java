package models;

import java.util.Objects;

public class PriceList {
    private final int idList;
    private int time;
    private double price;

    public PriceList(int idList, int time, double price) {
        this.idList = idList;
        this.time = Objects.requireNonNull(time);
        this.price = Objects.requireNonNull(price);
    }

    public int getIdList() {
        return idList;
    }

    public int getTime() {
        return time;
    }

    public double getPrice() {
        return price;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + idList;
        long temp;
        temp = Double.doubleToLongBits(price);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(time);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        PriceList other = (PriceList) obj;
        if (idList != other.idList)
            return false;
        if (Double.doubleToLongBits(price) != Double.doubleToLongBits(other.price))
            return false;
        if (Double.doubleToLongBits(time) != Double.doubleToLongBits(other.time))
            return false;
        return true;
    }

}
