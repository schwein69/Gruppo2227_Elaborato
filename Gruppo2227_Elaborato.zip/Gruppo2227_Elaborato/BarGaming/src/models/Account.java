package models;

import java.util.Objects;

public class Account {
    private final int idAccount;
    private final String userName;
    private final String passWord;
    private final String role;
    
    public Account(final int idAccount, final String userName, final String passWord, final String role) {
        this.idAccount = idAccount;
        this.userName = Objects.requireNonNull(userName);
        this.passWord = Objects.requireNonNull(passWord);
        this.role = Objects.requireNonNull(role);
    }

    public int getIdAccount() {
        return idAccount;
    }

    public String getUserName() {
        return userName;
    }

    public String getPassWord() {
        return passWord;
    }

    public String getRole() {
        return role;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + idAccount;
        result = prime * result + ((passWord == null) ? 0 : passWord.hashCode());
        result = prime * result + ((role == null) ? 0 : role.hashCode());
        result = prime * result + ((userName == null) ? 0 : userName.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Account other = (Account) obj;
        if (idAccount != other.idAccount)
            return false;
        if (passWord == null) {
            if (other.passWord != null)
                return false;
        } else if (!passWord.equals(other.passWord))
            return false;
        if (role == null) {
            if (other.role != null)
                return false;
        } else if (!role.equals(other.role))
            return false;
        if (userName == null) {
            if (other.userName != null)
                return false;
        } else if (!userName.equals(other.userName))
            return false;
        return true;
    }
    
}
