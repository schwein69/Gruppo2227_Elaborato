package models;

import java.util.Objects;

public class Product {
    private final int idProduct;
    private String productName;
    private double productPrice;
    private int productGiftPo;

    public Product(int idProduct, String productName, double productPrice, int productGiftPo) {
        this.idProduct = idProduct;
        this.productName = Objects.requireNonNull(productName);
        this.productPrice = Objects.requireNonNull(productPrice);
        this.productGiftPo = Objects.requireNonNull(productGiftPo);
    }

    public int getIdProduct() {
        return idProduct;
    }

    public String getProductName() {
        return productName;
    }

    public double getProductPrice() {
        return productPrice;
    }

    public int getProductGiftPo() {
        return productGiftPo;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + idProduct;
        result = prime * result + productGiftPo;
        result = prime * result + ((productName == null) ? 0 : productName.hashCode());
        long temp;
        temp = Double.doubleToLongBits(productPrice);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Product other = (Product) obj;
        if (idProduct != other.idProduct)
            return false;
        if (productGiftPo != other.productGiftPo)
            return false;
        if (productName == null) {
            if (other.productName != null)
                return false;
        } else if (!productName.equals(other.productName))
            return false;
        if (Double.doubleToLongBits(productPrice) != Double.doubleToLongBits(other.productPrice))
            return false;
        return true;
    }

}
