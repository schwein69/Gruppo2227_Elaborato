package models;

import java.util.Objects;

public class Sponsor {
    private final int idSponsor;
    private String name;
    private String phoneNumber;
    private String email;

    public Sponsor(int idSponsor, String name, String phoneNumber, String email) {
        this.idSponsor = idSponsor;
        this.name = Objects.requireNonNull(name);
        this.phoneNumber = Objects.requireNonNull(phoneNumber);
        this.email = Objects.requireNonNull(email);
    }

    public int getIdSponsor() {
        return idSponsor;
    }

    public String getName() {
        return name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((email == null) ? 0 : email.hashCode());
        result = prime * result + idSponsor;
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        result = prime * result + ((phoneNumber == null) ? 0 : phoneNumber.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Sponsor other = (Sponsor) obj;
        if (email == null) {
            if (other.email != null)
                return false;
        } else if (!email.equals(other.email))
            return false;
        if (idSponsor != other.idSponsor)
            return false;
        if (name == null) {
            if (other.name != null)
                return false;
        } else if (!name.equals(other.name))
            return false;
        if (phoneNumber == null) {
            if (other.phoneNumber != null)
                return false;
        } else if (!phoneNumber.equals(other.phoneNumber))
            return false;
        return true;
    }

}
