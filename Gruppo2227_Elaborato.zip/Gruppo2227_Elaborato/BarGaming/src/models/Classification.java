package models;


public class Classification {
    private final int idMatch;
    private final int idClient;
    private int position;
    private int giftPointsWon;

    public Classification(int idMatch, int idClient, int position, int giftPointsWon) {
        this.idMatch = idMatch;
        this.idClient = idClient;
        this.position = position;
        this.giftPointsWon = giftPointsWon;
    }

    public int getIdMatch() {
        return idMatch;
    }

    public int getIdClient() {
        return idClient;
    }

    public int getPosition() {
        return position;
    }

    public int getGiftPointsWon() {
        return giftPointsWon;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + giftPointsWon;
        result = prime * result + idClient;
        result = prime * result + idMatch;
        result = prime * result + position;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Classification other = (Classification) obj;
        if (giftPointsWon != other.giftPointsWon)
            return false;
        if (idClient != other.idClient)
            return false;
        if (idMatch != other.idMatch)
            return false;
        if (position != other.position)
            return false;
        return true;
    }

}
