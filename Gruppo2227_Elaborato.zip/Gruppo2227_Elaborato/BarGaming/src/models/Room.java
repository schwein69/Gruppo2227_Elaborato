package models;

import java.util.Objects;

public class Room {
    private final int idRoom;
    private int roomCapacity;
    private int roomActualCapacity;

    public Room(int idRoom, int roomCapacity, int roomActualCapacity) {
        this.idRoom = idRoom;
        this.roomCapacity = Objects.requireNonNull(roomCapacity);
        this.roomActualCapacity = roomActualCapacity;
    }

    public int getIdRoom() {
        return idRoom;
    }

    public int getRoomCapacity() {
        return roomCapacity;
    }

    public int getRoomActualCapacity() {
        return roomActualCapacity;
    }

    public void setRoomCapacity(int roomCapacity) {
        this.roomCapacity = roomCapacity;
    }

    public void setRoomActualCapacity(int roomActualCapacity) {
        this.roomActualCapacity = roomActualCapacity;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + idRoom;
        result = prime * result + roomActualCapacity;
        result = prime * result + roomCapacity;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Room other = (Room) obj;
        if (idRoom != other.idRoom)
            return false;
        if (roomActualCapacity != other.roomActualCapacity)
            return false;
        if (roomCapacity != other.roomCapacity)
            return false;
        return true;
    }

}
