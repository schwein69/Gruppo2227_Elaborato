package models;

import java.util.Objects;

public class RechargeDetail {
    private final int idRecharge;
    private final int idPriceList;
    private final int quantity;
    private double unityPrice;
    private double totalPrice;

    public RechargeDetail(int idRecharge, int idPriceList, int quantity, double unityPrice, double totalPrice) {
        this.idRecharge = idRecharge;
        this.idPriceList = idPriceList;
        this.quantity = Objects.requireNonNull(quantity);
        this.unityPrice = Objects.requireNonNull(unityPrice);
        this.totalPrice = Objects.requireNonNull(totalPrice);
    }

    public int getIdRecharge() {
        return idRecharge;
    }

    public int getIdPriceList() {
        return idPriceList;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getUnityPrice() {
        return unityPrice;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    @Override
    public String toString() {
        return "[idRecharge=" + idRecharge + ", idPriceList=" + idPriceList + ", quantity=" + quantity + ", unityPrice="
                + unityPrice + ", totalPrice=" + totalPrice + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + idPriceList;
        result = prime * result + idRecharge;
        result = prime * result + quantity;
        long temp;
        temp = Double.doubleToLongBits(totalPrice);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(unityPrice);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        RechargeDetail other = (RechargeDetail) obj;
        if (idPriceList != other.idPriceList)
            return false;
        if (idRecharge != other.idRecharge)
            return false;
        if (quantity != other.quantity)
            return false;
        if (Double.doubleToLongBits(totalPrice) != Double.doubleToLongBits(other.totalPrice))
            return false;
        if (Double.doubleToLongBits(unityPrice) != Double.doubleToLongBits(other.unityPrice))
            return false;
        return true;
    }

}
