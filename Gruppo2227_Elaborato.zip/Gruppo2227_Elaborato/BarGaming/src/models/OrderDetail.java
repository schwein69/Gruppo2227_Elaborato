package models;

import java.util.Objects;
import java.util.Optional;

public class OrderDetail {
    private final int idProduct;
    private final int idOrdine;
    private final int quantity;
    private double unityPrice;
    private double totalPrice;
    private int giftPointsPerProduct;
    private final Optional<Integer> discount;

    public OrderDetail(int idProduct, int idOrdine, int quantity, double unityPrice, double totalPrice,
            int giftPointsPerProduct, Optional<Integer> discount) {
        this.idProduct = idProduct;
        this.idOrdine = idOrdine;
        this.quantity = Objects.requireNonNull(quantity);
        this.unityPrice = Objects.requireNonNull(unityPrice);
        this.totalPrice = Objects.requireNonNull(totalPrice);
        this.giftPointsPerProduct = Objects.requireNonNull(giftPointsPerProduct);
        this.discount = discount;
    }

    public OrderDetail(int idProduct, int idOrdine, int quantity, double unityPrice, double totalPrice,
            int giftPointsPerProduct) {
        this(idProduct, idOrdine, quantity, unityPrice, totalPrice, giftPointsPerProduct, Optional.empty());
    }

    public int getIdProduct() {
        return idProduct;
    }

    public int getIdOrdine() {
        return idOrdine;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getUnityPrice() {
        return unityPrice;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public int getGiftPointsPerProduct() {
        return giftPointsPerProduct;
    }

    public Optional<Integer> getDiscount() {
        return discount;
    }

    @Override
    public String toString() {
        return "[Id prodotto=" + idProduct + ", quantità=" + quantity + ", prezzo unitario=" + unityPrice
                + ", prezzo totale=" + totalPrice + ", punti regalo =" + giftPointsPerProduct + ", sconto="
                + discount.orElse(0) + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((discount == null) ? 0 : discount.hashCode());
        result = prime * result + giftPointsPerProduct;
        result = prime * result + idOrdine;
        result = prime * result + idProduct;
        result = prime * result + quantity;
        long temp;
        temp = Double.doubleToLongBits(totalPrice);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(unityPrice);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        OrderDetail other = (OrderDetail) obj;
        if (discount == null) {
            if (other.discount != null)
                return false;
        } else if (!discount.equals(other.discount))
            return false;
        if (giftPointsPerProduct != other.giftPointsPerProduct)
            return false;
        if (idOrdine != other.idOrdine)
            return false;
        if (idProduct != other.idProduct)
            return false;
        if (quantity != other.quantity)
            return false;
        if (Double.doubleToLongBits(totalPrice) != Double.doubleToLongBits(other.totalPrice))
            return false;
        if (Double.doubleToLongBits(unityPrice) != Double.doubleToLongBits(other.unityPrice))
            return false;
        return true;
    }

}
