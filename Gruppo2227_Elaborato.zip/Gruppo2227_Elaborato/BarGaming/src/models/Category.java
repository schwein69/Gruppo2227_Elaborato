package models;

import java.util.Objects;

public class Category {
    private final int idCategory;
    private final String nameCategory;

    public Category(final int idCategory, final String nameCategory) {
        this.idCategory = idCategory;
        this.nameCategory = Objects.requireNonNull(nameCategory);
    }

    public int getIdCategory() {
        return idCategory;
    }

    public String getNameCategory() {
        return nameCategory;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + idCategory;
        result = prime * result + ((nameCategory == null) ? 0 : nameCategory.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Category other = (Category) obj;
        if (idCategory != other.idCategory)
            return false;
        if (nameCategory == null) {
            if (other.nameCategory != null)
                return false;
        } else if (!nameCategory.equals(other.nameCategory))
            return false;
        return true;
    }
    
}
