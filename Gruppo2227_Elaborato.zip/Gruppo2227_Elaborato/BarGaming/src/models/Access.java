package models;

import java.util.Date;
import java.util.Optional;

public class Access {
    private final int idDevice;
    private final int idClient;
    private Date accessDate;
    private String accessTime;
    private Optional<Date> logoutDate;
    private Optional<String> lougoutTime;

    public Access(int idDevice, int idClient, Date accessDate, String accessTime, Optional<Date> logoutDate,
            Optional<String> lougoutTime) {
        this.idDevice = idDevice;
        this.idClient = idClient;
        this.accessDate = accessDate;
        this.accessTime = accessTime;
        this.logoutDate = logoutDate;
        this.lougoutTime = lougoutTime;
    }

    public Date getAccessDate() {
        return accessDate;
    }

    public void setAccessDate(Date accessDate) {
        this.accessDate = accessDate;
    }

    public String getAccessTime() {
        return accessTime;
    }

    public void setAccessTime(String accessTime) {
        this.accessTime = accessTime;
    }

    public Optional<Date> getLogoutDate() {
        return logoutDate;
    }

    public void setLogoutDate(Optional<Date> logoutDate) {
        this.logoutDate = logoutDate;
    }

    public Optional<String> getLougoutTime() {
        return lougoutTime;
    }

    public void setLougoutTime(Optional<String> lougoutTime) {
        this.lougoutTime = lougoutTime;
    }

    public int getIdDevice() {
        return idDevice;
    }

    public int getIdClient() {
        return idClient;
    }

}
