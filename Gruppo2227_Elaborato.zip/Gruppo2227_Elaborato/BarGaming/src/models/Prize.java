package models;

import java.util.Objects;

public class Prize {
    private final int idPrize;
    private String prizeName;
    private int prizePoints;
    private int prizeQuantity;

    public Prize(int idPrize, String prizeName, int prizePoints, int prizeQuantity) {
        this.idPrize = idPrize;
        this.prizeName = Objects.requireNonNull(prizeName);
        this.prizePoints = Objects.requireNonNull(prizePoints);
        this.prizeQuantity = Objects.requireNonNull(prizeQuantity);
    }

    public int getIdPrize() {
        return idPrize;
    }

    public String getPrizeName() {
        return prizeName;
    }

    public int getPrizePoints() {
        return prizePoints;
    }

    public int getPrizeQuantity() {
        return prizeQuantity;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + idPrize;
        result = prime * result + ((prizeName == null) ? 0 : prizeName.hashCode());
        result = prime * result + prizePoints;
        result = prime * result + prizeQuantity;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Prize other = (Prize) obj;
        if (idPrize != other.idPrize)
            return false;
        if (prizeName == null) {
            if (other.prizeName != null)
                return false;
        } else if (!prizeName.equals(other.prizeName))
            return false;
        if (prizePoints != other.prizePoints)
            return false;
        if (prizeQuantity != other.prizeQuantity)
            return false;
        return true;
    }

}
