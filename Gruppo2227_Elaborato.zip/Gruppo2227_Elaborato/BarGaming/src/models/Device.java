package models;

import java.util.Objects;

public class Device {
    private final int idDevice;
    private final int idRoom;
    private final int idModel;
    private String deviceName;
    private String stateDevice;
    private String occuped;
    private int memoryDevice;

    public Device(int idDevice, int idRoom, int idModel, String deviceName, String stateDevice, String occuped,
            int memoryDevice) {
        this.idDevice = idDevice;
        this.idRoom = Objects.requireNonNull(idRoom);
        this.idModel = Objects.requireNonNull(idModel);
        this.deviceName = Objects.requireNonNull(deviceName);
        this.stateDevice = Objects.requireNonNull(stateDevice);
        this.occuped = Objects.requireNonNull(occuped);
        this.memoryDevice = Objects.requireNonNull(memoryDevice);
    }

    public int getIdDevice() {
        return idDevice;
    }

    public int getIdRoom() {
        return idRoom;
    }

    public int getIdModel() {
        return idModel;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public String getStateDevice() {
        return stateDevice;
    }

    public String getOccuped() {
        return occuped;
    }

    public int getMemoryDevice() {
        return memoryDevice;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((deviceName == null) ? 0 : deviceName.hashCode());
        result = prime * result + idDevice;
        result = prime * result + idModel;
        result = prime * result + idRoom;
        result = prime * result + memoryDevice;
        result = prime * result + ((occuped == null) ? 0 : occuped.hashCode());
        result = prime * result + ((stateDevice == null) ? 0 : stateDevice.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Device other = (Device) obj;
        if (deviceName == null) {
            if (other.deviceName != null)
                return false;
        } else if (!deviceName.equals(other.deviceName))
            return false;
        if (idDevice != other.idDevice)
            return false;
        if (idModel != other.idModel)
            return false;
        if (idRoom != other.idRoom)
            return false;
        if (memoryDevice != other.memoryDevice)
            return false;
        if (occuped == null) {
            if (other.occuped != null)
                return false;
        } else if (!occuped.equals(other.occuped))
            return false;
        if (stateDevice == null) {
            if (other.stateDevice != null)
                return false;
        } else if (!stateDevice.equals(other.stateDevice))
            return false;
        return true;
    }

}
