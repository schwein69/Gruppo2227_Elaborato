package models;

import java.util.Objects;

public class Game {
    private final int idGame;
    private final int idCategory;
    private String gameName;
    private int memoryOccuped;

    public Game(int idGame, int idCategory, String gameName, int memoryOccuped) {
        this.idGame = idGame;
        this.idCategory = Objects.requireNonNull(idCategory);
        this.gameName = Objects.requireNonNull(gameName);
        this.memoryOccuped = Objects.requireNonNull(memoryOccuped);
    }

    public int getIdGame() {
        return idGame;
    }

    public int getIdCategory() {
        return idCategory;
    }

    public String getGameName() {
        return gameName;
    }

    public int getMemoryOccuped() {
        return memoryOccuped;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((gameName == null) ? 0 : gameName.hashCode());
        result = prime * result + idCategory;
        result = prime * result + idGame;
        result = prime * result + memoryOccuped;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Game other = (Game) obj;
        if (gameName == null) {
            if (other.gameName != null)
                return false;
        } else if (!gameName.equals(other.gameName))
            return false;
        if (idCategory != other.idCategory)
            return false;
        if (idGame != other.idGame)
            return false;
        if (memoryOccuped != other.memoryOccuped)
            return false;
        return true;
    }

}
