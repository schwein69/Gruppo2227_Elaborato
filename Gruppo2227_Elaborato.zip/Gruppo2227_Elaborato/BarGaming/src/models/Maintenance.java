package models;

import java.util.Date;
import java.util.Objects;

public class Maintenance {
    private final int idMain;
    private final int idDevice;
    private final int idEmployee;
    private String description;
    private double cost;
    private Date date;

    public Maintenance(int idMain, int idDevice, int idEmployee, String description, double cost, Date date) {
        this.idMain = idMain;
        this.idDevice = Objects.requireNonNull(idDevice);
        this.idEmployee = Objects.requireNonNull(idEmployee);
        this.description = Objects.requireNonNull(description);
        this.cost = Objects.requireNonNull(cost);
        this.date = Objects.requireNonNull(date);
    }

    public int getIdDevice() {
        return idDevice;
    }

    public int getIdEmployee() {
        return idEmployee;
    }

    public String getDescription() {
        return description;
    }

    public double getCost() {
        return cost;
    }

    public Date getDate() {
        return date;
    }

    public int getIdMain() {
        return idMain;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        long temp;
        temp = Double.doubleToLongBits(cost);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        result = prime * result + ((date == null) ? 0 : date.hashCode());
        result = prime * result + ((description == null) ? 0 : description.hashCode());
        result = prime * result + idDevice;
        result = prime * result + idEmployee;
        result = prime * result + idMain;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Maintenance other = (Maintenance) obj;
        if (Double.doubleToLongBits(cost) != Double.doubleToLongBits(other.cost))
            return false;
        if (date == null) {
            if (other.date != null)
                return false;
        } else if (!date.equals(other.date))
            return false;
        if (description == null) {
            if (other.description != null)
                return false;
        } else if (!description.equals(other.description))
            return false;
        if (idDevice != other.idDevice)
            return false;
        if (idEmployee != other.idEmployee)
            return false;
        if (idMain != other.idMain)
            return false;
        return true;
    }

}
