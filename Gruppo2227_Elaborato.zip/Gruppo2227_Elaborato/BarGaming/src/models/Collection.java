package models;

import java.util.Objects;

public class Collection {
    private final int idCollection;
    private final int idClient;
    private final int idPrize;
    private int quantity;
    private int giftPointsNecessaryForPrize;

    public Collection(int idCollection, int idClient, int idPrize, int quantity, int giftPointsNecessaryForPrize) {
        this.idCollection = idCollection;
        this.idClient = Objects.requireNonNull(idClient);
        this.idPrize = Objects.requireNonNull(idPrize);
        this.quantity = Objects.requireNonNull(quantity);
        this.giftPointsNecessaryForPrize = Objects.requireNonNull(giftPointsNecessaryForPrize);
    }

    public int getIdClient() {
        return idClient;
    }

    public int getIdPrize() {
        return idPrize;
    }

    public int getQuantity() {
        return quantity;
    }

    public int getGiftPointsNecessaryForPrize() {
        return giftPointsNecessaryForPrize;
    }

    public int getIdCollection() {
        return idCollection;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + giftPointsNecessaryForPrize;
        result = prime * result + idClient;
        result = prime * result + idCollection;
        result = prime * result + idPrize;
        result = prime * result + quantity;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Collection other = (Collection) obj;
        if (giftPointsNecessaryForPrize != other.giftPointsNecessaryForPrize)
            return false;
        if (idClient != other.idClient)
            return false;
        if (idCollection != other.idCollection)
            return false;
        if (idPrize != other.idPrize)
            return false;
        if (quantity != other.quantity)
            return false;
        return true;
    }

}
