package models;

import java.util.Date;
import java.util.Objects;
import java.util.Optional;

public class Contract {
    private final int idContract;
    private String type;
    private double salary;
    private Date startDate;
    private Optional<Date> finishDate;

    public Contract(int idContract, String type, double salary, Date startDate, Optional<Date> finishDate) {
        this.idContract = idContract;
        this.type = Objects.requireNonNull(type);
        this.salary = Objects.requireNonNull(salary);
        this.startDate = Objects.requireNonNull(startDate);
        this.finishDate = finishDate;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Optional<Date> getFinishDate() {
        return finishDate;
    }

    public void setFinishDate(Optional<Date> finishDate) {
        this.finishDate = finishDate;
    }

    public int getIdContract() {
        return idContract;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((finishDate == null) ? 0 : finishDate.hashCode());
        result = prime * result + idContract;
        long temp;
        temp = Double.doubleToLongBits(salary);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        result = prime * result + ((startDate == null) ? 0 : startDate.hashCode());
        result = prime * result + ((type == null) ? 0 : type.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Contract other = (Contract) obj;
        if (finishDate == null) {
            if (other.finishDate != null)
                return false;
        } else if (!finishDate.equals(other.finishDate))
            return false;
        if (idContract != other.idContract)
            return false;
        if (Double.doubleToLongBits(salary) != Double.doubleToLongBits(other.salary))
            return false;
        if (startDate == null) {
            if (other.startDate != null)
                return false;
        } else if (!startDate.equals(other.startDate))
            return false;
        if (type == null) {
            if (other.type != null)
                return false;
        } else if (!type.equals(other.type))
            return false;
        return true;
    }

}
