package models;

import java.util.Objects;

public class Model {
    private final int idModel;
    private String modelName;
    private int memory;

    public Model(int idModel, String modelName, int memory) {
        this.idModel = idModel;
        this.modelName = Objects.requireNonNull(modelName);
        this.memory = Objects.requireNonNull(memory);
    }

    public int getIdModel() {
        return idModel;
    }

    public String getModelName() {
        return modelName;
    }

    public int getMemory() {
        return memory;
    }

    public void setModelName(String modelName) {
        this.modelName = modelName;
    }

    public void setMemory(int memory) {
        this.memory = memory;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + idModel;
        result = prime * result + memory;
        result = prime * result + ((modelName == null) ? 0 : modelName.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Model other = (Model) obj;
        if (idModel != other.idModel)
            return false;
        if (memory != other.memory)
            return false;
        if (modelName == null) {
            if (other.modelName != null)
                return false;
        } else if (!modelName.equals(other.modelName))
            return false;
        return true;
    }

}
