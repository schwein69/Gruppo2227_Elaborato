package userScene;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ResourceBundle;
import connection.ConnectionProvider;
import connection.Utils;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import models.Classification;
import models.Client;
import models.Collection;
import models.Match;
import models.Order;
import models.Prize;
import tables.ClientTable;
import tables.OrderTable;

class JoinMatchClassModel {
    private Match match;
    private Classification classif;

    public JoinMatchClassModel(Match match, Classification classif) {
        this.match = match;
        this.classif = classif;

    }

    public Match getMatch() {
        return match;
    }

    public void setMatch(Match match) {
        this.match = match;
    }

    public Classification getClassif() {
        return classif;
    }

    public void setClassif(Classification classif) {
        this.classif = classif;
    }

}

class JoinPrizeCollecModel {
    private Prize prize;
    private Collection colle;

    public JoinPrizeCollecModel(Prize prize, Collection colle) {
        this.prize = prize;
        this.colle = colle;

    }

    public Prize getPrize() {
        return prize;
    }

    public void setPrize(Prize prize) {
        this.prize = prize;
    }

    public Collection getColle() {
        return colle;
    }

    public void setColle(Collection colle) {
        this.colle = colle;
    }

}

public class UserController implements Initializable {
    private int idClient;
    final static String username = "root";
    final static String password = "";
    final static String dbName = "databasegigi";

    final ConnectionProvider connectionProvider = new ConnectionProvider(username, password, dbName);
    final OrderTable orderTable = new OrderTable(connectionProvider.getMySQLConnection());
    final ClientTable clientTable = new ClientTable(connectionProvider.getMySQLConnection());
    final Connection con = connectionProvider.getMySQLConnection();

    public UserController(int id) {
        this.idClient = id;
    }

    @FXML
    private TableView<JoinPrizeCollecModel> prizeTableView;

    @FXML
    private Label lastName;

    @FXML
    private TableColumn<Order, Double> orderPirceColumn;

    @FXML
    private TableColumn<Order, Integer> orderIdColumn;

    @FXML
    private Label code;

    @FXML
    private TableColumn<JoinMatchClassModel, Integer> matchPointsColumn;

    @FXML
    private Label gender;

    @FXML
    private Label city;

    @FXML
    private TableColumn<JoinPrizeCollecModel, Integer> prizeIdColumn;

    @FXML
    private TableView<JoinMatchClassModel> matchTableView;

    @FXML
    private Label points;

    @FXML
    private TableColumn<JoinPrizeCollecModel, Integer> prizeQuantityColumn;

    @FXML
    private Label pin;

    @FXML
    private Label id;

    @FXML
    private Label email;

    @FXML
    private TableColumn<JoinMatchClassModel, Integer> matchId;

    @FXML
    private TableColumn<JoinMatchClassModel, String> nameMatchColumn;

    @FXML
    private Label address;

    @FXML
    private TableView<Order> orderTableView;

    @FXML
    private TableColumn<Order, String> orderDateColumn;

    @FXML
    private TableColumn<JoinMatchClassModel, String> matchDateColumn;

    @FXML
    private TableColumn<Order, Integer> orderPointsColumn;

    @FXML
    private TableColumn<JoinMatchClassModel, String> matchStateColumn;

    @FXML
    private TableColumn<JoinMatchClassModel, Integer> matchPositionColumn;

    @FXML
    private Label phone;

    @FXML
    private Label name;

    @FXML
    private TableColumn<JoinPrizeCollecModel, String> prizeNameColumn;
    @FXML
    private TableColumn<JoinPrizeCollecModel, Integer> collectIdColumn;
    @FXML
    private Label time;

    private void initializationLabels() {
        Client cl = clientTable.findByPrimaryKey(this.idClient).get();
        id.setText(String.valueOf(cl.getIdClient()));
        name.setText(cl.getName());
        lastName.setText(cl.getLastName());
        gender.setText(cl.getGender());
        email.setText(cl.getEmail());
        phone.setText(cl.getPhoneNumber());
        pin.setText(cl.getPin());
        address.setText(cl.getAddress());
        city.setText(cl.getCity());
        code.setText(cl.getPostalCode());
        points.setText(String.valueOf(cl.getGiftPoints()));
        time.setText(cl.getTime());

    }

    private ObservableList<JoinMatchClassModel> readMatchFromResultSet(final ResultSet resultSet) {
        ObservableList<JoinMatchClassModel> listJoin = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {
                JoinMatchClassModel newObject = new JoinMatchClassModel(
                        new Match(resultSet.getInt("IdGara"), resultSet.getInt("IdModello"),
                                resultSet.getInt("IdGioco"), resultSet.getString("NomeGara"),
                                Utils.sqlDateToDate(resultSet.getDate("DataGara")), resultSet.getInt("Capienza"),
                                resultSet.getInt("IscrittiAttuali"), resultSet.getString("StatoGara"),
                                resultSet.getDouble("QuotaIscrizione")),
                        new Classification(resultSet.getInt("IdGara"), resultSet.getInt("IdCliente"),
                                resultSet.getInt("Posizione"), resultSet.getInt("PuntiPremioVinti")));
                listJoin.add(newObject);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listJoin;
    }

    private ObservableList<JoinMatchClassModel> findAllMatchClass() {
        try (final Statement statement = this.con.createStatement()) {
            final ResultSet rs = statement.executeQuery(
                    "SELECT *  FROM gara g, classificazione c WHERE g.IdGara = c.IdGara  AND c.IdCliente = "
                            + this.idClient);
            return readMatchFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    private ObservableList<JoinPrizeCollecModel> readPrizeFromResultSet(final ResultSet resultSet) {
        ObservableList<JoinPrizeCollecModel> listJoin = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {
                JoinPrizeCollecModel newObject = new JoinPrizeCollecModel(
                        new Prize(resultSet.getInt("IdPremio"), resultSet.getString("NomePremio"),
                                resultSet.getInt("PuntiPremioNecessari"), resultSet.getInt("QuantitàPremioResidua")),
                        new Collection(resultSet.getInt("IdRiscossione"), resultSet.getInt("IdCliente"),
                                resultSet.getInt("IdPremio"), resultSet.getInt("QuantitàRiscossione"),
                                resultSet.getInt("CostoPremio")));
                listJoin.add(newObject);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listJoin;
    }

    private ObservableList<JoinPrizeCollecModel> findAllPrizeColl() {
        try (final Statement statement = this.con.createStatement()) {
            final ResultSet rs = statement.executeQuery(
                    "SELECT *  FROM riscossione r, premio p WHERE r.IdPremio  = p.IdPremio AND r.IdCliente = "
                            + this.idClient);
            return readPrizeFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    private void refresh() {
        matchTableView.setItems(this.findAllMatchClass());
        prizeTableView.setItems(this.findAllPrizeColl());
        orderTableView.setItems(orderTable.findByClient(this.idClient));
    }

    private void initializeMatchTable() {
        matchId.setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getMatch().getIdMatch()).asObject());
        nameMatchColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getMatch().getMatchName()));
        matchStateColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getMatch().getState()));
        matchPositionColumn.setCellValueFactory(
                e -> new SimpleIntegerProperty(e.getValue().getClassif().getPosition()).asObject());
        matchPointsColumn.setCellValueFactory(
                e -> new SimpleIntegerProperty(e.getValue().getClassif().getGiftPointsWon()).asObject());
        matchDateColumn.setCellValueFactory(e -> {
            SimpleStringProperty property = new SimpleStringProperty();
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            property.setValue(dateFormat.format(e.getValue().getMatch().getMatchDate()));
            return property;
        });
    }

    private void initializeOrderTable() {
        orderIdColumn.setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getIdOrder()).asObject());
        orderPointsColumn.setCellValueFactory(
                e -> new SimpleIntegerProperty(e.getValue().getOrderGiftPoints().get()).asObject());
        orderPirceColumn
                .setCellValueFactory(e -> new SimpleDoubleProperty(e.getValue().getOrderTotalPrice()).asObject());
        orderDateColumn.setCellValueFactory(e -> {
            SimpleStringProperty property = new SimpleStringProperty();
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            property.setValue(dateFormat.format(e.getValue().getOrderDay()));
            return property;
        });
    }

    private void initializePrizeTable() {
        collectIdColumn.setCellValueFactory(
                e -> new SimpleIntegerProperty(e.getValue().getColle().getIdCollection()).asObject());
        prizeIdColumn
                .setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getPrize().getIdPrize()).asObject());
        prizeQuantityColumn
                .setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getColle().getQuantity()).asObject());
        prizeNameColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getPrize().getPrizeName()));
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        // TODO Auto-generated method stub
        initializationLabels();
        initializePrizeTable();
        initializeOrderTable();
        initializeMatchTable();
        refresh();
    }
}
