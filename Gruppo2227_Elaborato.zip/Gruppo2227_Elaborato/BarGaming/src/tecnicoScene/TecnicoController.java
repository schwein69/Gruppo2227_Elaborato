package tecnicoScene;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.AnchorPane;

public class TecnicoController implements Initializable {
    private int idEmp;
    private TecnicoTabController tecAdController;
    private TecnicoHistoryTabController tecHisController;

    public TecnicoController(int id) {
        this.idEmp = id;
    }

    @FXML
    private TabPane tabs;

    @FXML
    private Tab tab1;

    @FXML
    private Tab tab2;

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        // TODO Auto-generated method stub
        FXMLLoader loader = new FXMLLoader(getClass().getResource("TecnicoAdminTab.fxml"));
        try {
            AnchorPane anch1 = loader.load();
            tecAdController = loader.getController();
            tecAdController.initData(idEmp);
            tab1.setContent(anch1);
        } catch (Exception e) {
            System.out.println("unable to load tab1");
            e.printStackTrace();
        }
        loader = new FXMLLoader(getClass().getResource("TecnicoHistoryTab.fxml"));
        try {
            AnchorPane anch1 = loader.load();
            tecHisController = loader.getController();
            tab2.setContent(anch1);
        } catch (Exception e) {
            System.out.println("unable to load tab2");
            e.printStackTrace();
        }
        tabs.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Tab>() {
            @Override
            public void changed(ObservableValue<? extends Tab> ov, Tab t, Tab t1) {
                tecAdController.refresh();
                tecHisController.refresh();
            }

        });
    }

}
