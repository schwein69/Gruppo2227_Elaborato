package tecnicoScene;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

import connection.ConnectionProvider;
import connection.Utils;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;

import models.Association;
import models.Category;
import models.Device;
import models.Game;
import models.Maintenance;
import models.Model;

import tables.AssociationTable;
import tables.CategoryTable;
import tables.DeviceTable;
import tables.GameTable;
import tables.MainteinceTable;
import tables.ModelTable;

class JoinDeviceModel {
    private Device device;
    private Model model;

    public JoinDeviceModel(Device device, Model model) {
        this.device = device;
        this.model = model;

    }

    public Device getDevice() {
        return device;
    }

    public void setDevice(Device device) {
        this.device = device;
    }

    public Model getModel() {
        return model;
    }

}

public class TecnicoTabController implements Initializable {
    final static String username = "root";
    final static String password = "";
    final static String dbName = "databasegigi";

    final ConnectionProvider connectionProvider = new ConnectionProvider(username, password, dbName);

    final CategoryTable cateTable = new CategoryTable(connectionProvider.getMySQLConnection());
    final DeviceTable deviceTable = new DeviceTable(connectionProvider.getMySQLConnection());
    final ModelTable modelTable = new ModelTable(connectionProvider.getMySQLConnection());
    final GameTable gameTable = new GameTable(connectionProvider.getMySQLConnection());
    final AssociationTable assocTable = new AssociationTable(connectionProvider.getMySQLConnection());
    final MainteinceTable mainTable = new MainteinceTable(connectionProvider.getMySQLConnection());
    final Connection con = connectionProvider.getMySQLConnection();

    public void initData(int id) {
        IdDipLabel.setText(String.valueOf(id));
    }

    @FXML
    private Label IdDipLabel;

    @FXML
    private TableColumn<JoinDeviceModel, String> deviceModelnameColumn;

    @FXML
    private Button searchButton;

    @FXML
    private TableColumn<Game, String> gameMemoryColumn;

    @FXML
    private TableColumn<Association, Integer> assocDeviceIdColumn;

    @FXML
    private TableColumn<Category, String> categoryNameColumn;

    @FXML
    private ComboBox<Integer> removeGameId;

    @FXML
    private TextField repairDescr;

    @FXML
    private TableColumn<Game, Integer> gameIdColumn;

    @FXML
    private ComboBox<Integer> insertDeviceId;

    @FXML
    private Button repairbutton;

    @FXML
    private TableColumn<JoinDeviceModel, Integer> deviceModelIdColumn;

    @FXML
    private TableColumn<Category, Integer> categoryIdColumn;

    @FXML
    private ComboBox<Integer> repairDeviceId;

    @FXML
    private TableColumn<Game, Integer> gameCategoryColumn;

    @FXML
    private TableColumn<Association, Integer> assocGameIdColumn;

    @FXML
    private TableColumn<JoinDeviceModel, Integer> deviceModelMemoryColumn;

    @FXML
    private TableColumn<JoinDeviceModel, Integer> deviceMemoryColumn;

    @FXML
    private ComboBox<Integer> removeDeviceId;

    @FXML
    private Button insertGameButton;

    @FXML
    private Button removeButton;

    @FXML
    private ComboBox<Integer> insertGameId;

    @FXML
    private TableColumn<JoinDeviceModel, String> deviceNameColumn;

    @FXML
    private TableView<Association> assocTableView;

    @FXML
    private TableColumn<JoinDeviceModel, String> deviceStateColumn;

    @FXML
    private TableView<Game> gameTableView;

    @FXML
    private TableColumn<Game, String> gameNameColumn;

    @FXML
    private TableColumn<JoinDeviceModel, Integer> deviceIdColumn;

    @FXML
    private ComboBox<Integer> searchDeviceId;

    @FXML
    private TableView<JoinDeviceModel> deviceTableView;

    @FXML
    private TextField repairCost;

    @FXML
    private TableView<Category> categoryTable;

    private ObservableList<JoinDeviceModel> readJoinFromResultSet(final ResultSet resultSet) {
        ObservableList<JoinDeviceModel> listJoin = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {
                JoinDeviceModel newObject = new JoinDeviceModel(
                        new Device(resultSet.getInt("idDevice"), resultSet.getInt("idSala"),
                                resultSet.getInt("idModello"), resultSet.getString("NomeDevice"),
                                resultSet.getString("StatoDevice"), resultSet.getString("OccupatoDevice"),
                                resultSet.getInt("MemoriaDevice")),
                        new Model(resultSet.getInt("idModello"), resultSet.getString("NomeModello"),
                                resultSet.getInt("MemoriaDisponibile")));
                listJoin.add(newObject);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listJoin;
    }

    private ObservableList<JoinDeviceModel> findAllWithJoinInDeviceTable() {
        try (final Statement statement = this.con.createStatement()) {
            final ResultSet rs = statement.executeQuery("SELECT *  FROM device dev"
                    + " JOIN modello ON dev.idModello = modello.idModello " + " ORDER BY dev.IdDevice");
            return readJoinFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    private void cleanLabels() {
        repairCost.setText("");
        repairDescr.setText("");
    }

    public void refresh() {
        repairDeviceId.setItems(deviceTable.findAll().stream().map(e -> e.getIdDevice())
                .collect(Collectors.toCollection(FXCollections::observableArrayList)));
        insertDeviceId.setItems(deviceTable.findAll().stream().map(e -> e.getIdDevice())
                .collect(Collectors.toCollection(FXCollections::observableArrayList)));
        removeDeviceId.setItems(deviceTable.findAll().stream().map(e -> e.getIdDevice())
                .collect(Collectors.toCollection(FXCollections::observableArrayList)));
        searchDeviceId.setItems(deviceTable.findAll().stream().map(e -> e.getIdDevice())
                .collect(Collectors.toCollection(FXCollections::observableArrayList)));
        insertGameId.setItems(gameTable.findAll().stream().map(e -> e.getIdGame())
                .collect(Collectors.toCollection(FXCollections::observableArrayList)));
        removeGameId.setItems(gameTable.findAll().stream().map(e -> e.getIdGame())
                .collect(Collectors.toCollection(FXCollections::observableArrayList)));
        ObservableList<JoinDeviceModel> list1 = this.findAllWithJoinInDeviceTable();
        deviceTableView.setItems(list1);
        ObservableList<Association> list2 = assocTable.findAll();
        assocTableView.setItems(list2);
        ObservableList<Game> list3 = gameTable.findAll();
        gameTableView.setItems(list3);
        ObservableList<Category> list4 = cateTable.findAll();
        categoryTable.setItems(list4);
    }

    private void initializeDeviceTable() {
        deviceIdColumn
                .setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getDevice().getIdDevice()).asObject());
        deviceNameColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getDevice().getDeviceName()));
        deviceStateColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getDevice().getStateDevice()));
        deviceMemoryColumn.setCellValueFactory(
                e -> new SimpleIntegerProperty(e.getValue().getDevice().getMemoryDevice()).asObject());
        deviceModelIdColumn
                .setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getDevice().getIdModel()).asObject());
        deviceModelnameColumn
                .setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getModel().getModelName()));
        deviceModelMemoryColumn
                .setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getModel().getMemory()).asObject());
    }

    private void initializeGameTable() {
        gameIdColumn.setCellValueFactory(new PropertyValueFactory<>("idGame"));
        gameNameColumn.setCellValueFactory(new PropertyValueFactory<>("gameName"));
        gameMemoryColumn.setCellValueFactory(new PropertyValueFactory<>("memoryOccuped"));
        gameCategoryColumn.setCellValueFactory(new PropertyValueFactory<>("idCategory"));
    }

    private void initializeAssocTable() {
        assocDeviceIdColumn.setCellValueFactory(new PropertyValueFactory<>("idDevice"));
        assocGameIdColumn.setCellValueFactory(new PropertyValueFactory<>("idGame"));
    }

    private void initializeCategoryTable() {
        categoryIdColumn.setCellValueFactory(new PropertyValueFactory<>("idCategory"));
        categoryNameColumn.setCellValueFactory(new PropertyValueFactory<>("nameCategory"));
    }

    @FXML
    void assocGameDevice(ActionEvent event) {
        this.insertGameButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) { // TODO Auto-generated
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (insertDeviceId.getValue() != null && insertGameId.getValue() != null) {
                        if (!assocTable.isGameAlreadyPresentInDevice(insertDeviceId.getValue(),
                                insertGameId.getValue())) {
                            if ((deviceTable.findByPrimaryKey(insertDeviceId.getValue()).get().getMemoryDevice()
                                    + gameTable.findByPrimaryKey(insertGameId.getValue()).get()
                                            .getMemoryOccuped()) <= modelTable
                                                    .findById(deviceTable.findByPrimaryKey(insertDeviceId.getValue())
                                                            .get().getIdModel())
                                                    .get().getMemory()) {
                                assocTable.save(new Association(insertDeviceId.getValue(), insertGameId.getValue()));
                                deviceTable.updateMemory(insertDeviceId.getValue(),
                                        gameTable.findByPrimaryKey(insertGameId.getValue()).get().getMemoryOccuped(),
                                        true);
                                cleanLabels();
                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("Memory not enough!");
                                nullLabels.showAndWait();
                            }

                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("Game already present in the device!");
                            nullLabels.showAndWait();
                        }

                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                    refresh();
                }
            }
        });
    }

    @FXML
    void searchGameDevice(ActionEvent event) {
        this.searchButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) { // TODO Auto-generated
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (searchDeviceId.getValue() != null) {
                        assocTableView.setItems(assocTable.findByDevice(searchDeviceId.getValue()));
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                }
            }
        });
    }

    @FXML
    void repairDevice(ActionEvent event) {

        this.repairbutton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) { // TODO Auto-generated
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (repairDeviceId.getValue() != null && !repairDescr.getText().isEmpty()
                            && !repairCost.getText().isEmpty()) {
                        if (Utils.isNumeric(repairCost.getText())) {
                            if (!deviceTable.findByPrimaryKey(repairDeviceId.getValue()).get().getStateDevice()
                                    .equals("Working")) {
                                mainTable.save(new Maintenance(0, repairDeviceId.getValue(),
                                        Integer.valueOf(IdDipLabel.getText()), repairDescr.getText(),
                                        Double.valueOf(repairCost.getText()), java.sql.Date.valueOf(LocalDate.now())));
                                if (deviceTable.findByPrimaryKey(repairDeviceId.getValue()).get()
                                        .getMemoryDevice() != 0) {
                                    deviceTable.updateState(repairDeviceId.getValue(), "Working");
                                }
                                cleanLabels();
                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("Device is not damaged!");
                                nullLabels.showAndWait();
                            }

                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("RepairCost should be numeric!");
                            nullLabels.showAndWait();
                        }

                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                    refresh();
                }
            }
        });

    }

    @FXML
    void removeGakeFromDevice(ActionEvent event) {
        this.removeButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) { // TODO Auto-generated
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (removeDeviceId.getValue() != null && removeGameId.getValue() != null) {
                        if (assocTable.isGameAlreadyPresentInDevice(removeDeviceId.getValue(),
                                removeGameId.getValue())) {
                            assocTable.delete(removeDeviceId.getValue(), removeGameId.getValue());
                            deviceTable.updateMemory(removeDeviceId.getValue(),
                                    gameTable.findByPrimaryKey(removeGameId.getValue()).get().getMemoryOccuped(),
                                    false);
                            if (deviceTable.findByPrimaryKey(removeDeviceId.getValue()).get().getMemoryDevice() == 0) {
                                deviceTable.updateState(removeDeviceId.getValue(), "No Game");
                            }
                            cleanLabels();
                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("Game not present in the device!");
                            nullLabels.showAndWait();
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                    refresh();
                }
            }
        });
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        // TODO Auto-generated method stub
        initializeDeviceTable();
        initializeGameTable();
        initializeAssocTable();
        initializeCategoryTable();
        refresh();
    }
}
