package tecnicoScene;

import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Optional;
import java.util.ResourceBundle;
import connection.ConnectionProvider;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert.AlertType;
import models.Maintenance;
import tables.MainteinceTable;

public class TecnicoHistoryTabController implements Initializable {
    final static String username = "root";
    final static String password = "";
    final static String dbName = "databasegigi";

    final ConnectionProvider connectionProvider = new ConnectionProvider(username, password, dbName);
    final MainteinceTable mainTable = new MainteinceTable(connectionProvider.getMySQLConnection());

    @FXML
    private TableView<Maintenance> mainteninceTableView;

    @FXML
    private Button searchButton;

    @FXML
    private TableColumn<Maintenance, Double> costColumn;

    @FXML
    private Button showAll;

    @FXML
    private TableColumn<Maintenance, Integer> mainIdColumn;

    @FXML
    private TableColumn<Maintenance, Integer> deviceIdColumn;

    @FXML
    private TableColumn<Maintenance, Integer> employeeIdColumn;

    @FXML
    private ComboBox<Integer> searchEmployeeId;

    @FXML
    private TableColumn<Maintenance, String> dateColumn;

    @FXML
    private TableColumn<Maintenance, String> descriptionColumn;

    public void refresh() {
        searchEmployeeId.setItems(mainTable.findAllDistinctEmployee());
        ObservableList<Maintenance> list1 = mainTable.findAll();
        mainteninceTableView.setItems(list1);

    }

    private void initializeDeviceTable() {
        mainIdColumn.setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getIdMain()).asObject());
        deviceIdColumn.setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getIdDevice()).asObject());
        employeeIdColumn.setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getIdEmployee()).asObject());
        descriptionColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getDescription()));
        costColumn.setCellValueFactory(e -> new SimpleDoubleProperty(e.getValue().getCost()).asObject());
        dateColumn.setCellValueFactory(e -> {
            SimpleStringProperty property = new SimpleStringProperty();
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            property.setValue(dateFormat.format(e.getValue().getDate()));
            return property;
        });
    }

    @FXML
    void searchEmployee(ActionEvent event) {
        this.searchButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) { // TODO Auto-generated
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (searchEmployeeId.getValue() != null) {
                        mainteninceTableView.setItems(mainTable.findAllOfEmployee(searchEmployeeId.getValue()));
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                }
            }
        });
    }

    @FXML
    void showAll(ActionEvent event) {
        refresh();
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        // TODO Auto-generated method stub
        initializeDeviceTable();
        refresh();
    }

}
