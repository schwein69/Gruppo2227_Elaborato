package staffScene;

import java.net.URL;

import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.AnchorPane;

public class StaffController implements Initializable {
    private int idEmp;
    private StaffRegistrationTabController regiController;
    private StaffUpdateClientTabController updateController;
    private StaffAssignTabController assignController;
    private StaffAdminMatchTabController matchController;
    private MatchSignTabController matchSignController;
    private DeviceAdminTabController deviceAdController;
    private AssignPrizeTabController assignPrizeController;
    private ClassificationController claController;
    private RechargeTabController rechargeController;

    public StaffController(int id) {
        this.idEmp = id;
    }

    @FXML
    private TabPane tabs;

    @FXML
    private Tab tab1;

    @FXML
    private Tab tab2;

    @FXML
    private Tab tab3;

    @FXML
    private Tab tab4;

    @FXML
    private Tab tab5;

    @FXML
    private Tab tab6;

    @FXML
    private Tab tab7;

    @FXML
    private Tab tab8;

    @FXML
    private Tab tab9;

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        // TODO Auto-generated method stub
        FXMLLoader loader = new FXMLLoader(getClass().getResource("StaffRegistrationClientTab.fxml"));
        try {
            AnchorPane anch1 = loader.load();
            regiController = loader.getController();
            tab1.setContent(anch1);
        } catch (Exception e) {
            System.out.println("unable to load tab1");
            e.printStackTrace();
        }
        loader = new FXMLLoader(getClass().getResource("StaffUpdateClientTab.fxml"));
        try {
            AnchorPane anch1 = loader.load();
            updateController = loader.getController();
            tab2.setContent(anch1);
        } catch (Exception e) {
            System.out.println("unable to load tab2");
            e.printStackTrace();
        }
        loader = new FXMLLoader(getClass().getResource("StaffAssignmentTab.fxml"));
        try {
            AnchorPane anch1 = loader.load();
            assignController = loader.getController();
            tab3.setContent(anch1);
        } catch (Exception e) {
            System.out.println("unable to load tab3");
            e.printStackTrace();
        }
        loader = new FXMLLoader(getClass().getResource("RechargeTab.fxml"));
        try {
            AnchorPane anch1 = loader.load();
            rechargeController = loader.getController();
            rechargeController.initData(idEmp);
            tab4.setContent(anch1);
        } catch (Exception e) {
            System.out.println("unable to load tab4");
            e.printStackTrace();
        }
        loader = new FXMLLoader(getClass().getResource("StaffAdminMatchTab.fxml"));
        try {
            AnchorPane anch1 = loader.load();
            matchController = loader.getController();
            tab5.setContent(anch1);
        } catch (Exception e) {
            System.out.println("unable to load tab5");
            e.printStackTrace();
        }
        loader = new FXMLLoader(getClass().getResource("MatchSignTab.fxml"));
        try {
            AnchorPane anch1 = loader.load();
            matchSignController = loader.getController();
            tab6.setContent(anch1);
        } catch (Exception e) {
            System.out.println("unable to load tab6");
            e.printStackTrace();
        }

        loader = new FXMLLoader(getClass().getResource("ClassificationTab.fxml"));
        try {
            AnchorPane anch1 = loader.load();
            claController = loader.getController();
            tab7.setContent(anch1);
        } catch (Exception e) {
            System.out.println("unable to load tab7");
            e.printStackTrace();
        }

        loader = new FXMLLoader(getClass().getResource("DeviceAdminTab.fxml"));
        try {
            AnchorPane anch1 = loader.load();
            deviceAdController = loader.getController();
            tab8.setContent(anch1);
        } catch (Exception e) {
            System.out.println("unable to load tab8");
            e.printStackTrace();
        }
        loader = new FXMLLoader(getClass().getResource("AssignPrizeTab.fxml"));
        try {
            AnchorPane anch1 = loader.load();
            assignPrizeController = loader.getController();
            assignPrizeController.initData(idEmp);
            tab9.setContent(anch1);
        } catch (Exception e) {
            System.out.println("unable to load tab9");
            e.printStackTrace();
        }

        tabs.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Tab>() {
            @Override
            public void changed(ObservableValue<? extends Tab> ov, Tab t, Tab t1) {
                // TODO Auto-generated method stub
                regiController.refresh();
                updateController.refresh();
                assignController.refresh();
                matchController.refresh();
                matchSignController.refresh();
                deviceAdController.refresh();
                assignPrizeController.refresh();
                claController.refresh();
                rechargeController.refresh();
            }

        });
    }

}
