package staffScene;

import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

import connection.ConnectionProvider;
import connection.Utils;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import models.Advisement;
import models.Game;
import models.Match;
import models.Model;
import models.Sponsor;
import tables.AdvisertmentTable;
import tables.DeviceTable;
import tables.GameTable;
import tables.MatchTable;
import tables.ModelTable;
import tables.SponsorTable;

public class StaffAdminMatchTabController implements Initializable {
    final static String username = "root";
    final static String password = "";
    final static String dbName = "databasegigi";

    final ConnectionProvider connectionProvider = new ConnectionProvider(username, password, dbName);
    final GameTable gameTable = new GameTable(connectionProvider.getMySQLConnection());
    final ModelTable modelTable = new ModelTable(connectionProvider.getMySQLConnection());
    final MatchTable matchTable = new MatchTable(connectionProvider.getMySQLConnection());
    final SponsorTable sponsorTable = new SponsorTable(connectionProvider.getMySQLConnection());
    final AdvisertmentTable advTable = new AdvisertmentTable(connectionProvider.getMySQLConnection());
    final DeviceTable deviceTable = new DeviceTable(connectionProvider.getMySQLConnection());
    @FXML
    private TextField capacityLabel;

    @FXML
    private TableColumn<Sponsor, String> sponsorNameColumn;

    @FXML
    private TableColumn<Match, Integer> matchCapacityColumn;

    @FXML
    private Button CreateButton;

    @FXML
    private TableColumn<Game, Integer> gameIdColumn;

    @FXML
    private Button SponsorizationButton;

    @FXML
    private ComboBox<Integer> modelIdLabel;

    @FXML
    private TableView<Advisement> matchSponsorTableView;

    @FXML
    private TableColumn<Match, String> matchGameColumn;

    @FXML
    private TableColumn<Match, Double> matchCostColumn;

    @FXML
    private TableColumn<Sponsor, String> sponsorContactColumn;

    @FXML
    private TableColumn<Model, Integer> modelIdColumn;

    @FXML
    private TableColumn<Sponsor, Integer> sponsorIdColumn;

    @FXML
    private TextField nameLabel;

    @FXML
    private ComboBox<Integer> sponsorMatchId1Label;

    @FXML
    private TableColumn<Match, Integer> matchactualColumn;

    @FXML
    private TableColumn<Advisement, Integer> JoinSponsorIdColumn;

    @FXML
    private TableView<Sponsor> SponsorTableView;

    @FXML
    private TableColumn<Match, Integer> idMatchColumn;

    @FXML
    private TextField cancelMatchIdLabel;

    @FXML
    private ComboBox<Integer> sponsorMatchId2Label;

    @FXML
    private Button updateMatchButton;

    @FXML
    private TableColumn<Match, String> matchDateColumn;

    @FXML
    private TextField sponsorQuoteLabel;

    @FXML
    private TableColumn<Match, String> MatchModelColumn;

    @FXML
    private DatePicker dateLabel;

    @FXML
    private TableView<Model> ModelTableview;

    @FXML
    private TableColumn<Match, String> matchNameColumn;

    @FXML
    private TextField costLabel;

    @FXML
    private TableColumn<Match, String> matchStateColumn;

    @FXML
    private TableColumn<Game, String> gameNameColumn;

    @FXML
    private TableColumn<Model, String> modelNameColumn;

    @FXML
    private Button removeMatchButton;

    @FXML
    private TableColumn<Advisement, Integer> JoinmatchIdColumn;

    @FXML
    private TableView<Game> GameTableview;

    @FXML
    private TableView<Match> matchTableview;

    @FXML
    private TableColumn<Sponsor, String> sponsorEmailColumn;

    @FXML
    private TextField updateMatchIdLabel;

    @FXML
    private ComboBox<Integer> gameIdLabel;

    @FXML
    private Button eliminateSponsorizationButton;

    @FXML
    private TableColumn<Advisement, Double> JoinSponsorQuoteColumn;

    @FXML
    private Button updateSponsorizationButton;

    private void cleanLabels() {
        nameLabel.setText("");
        dateLabel.setValue(null);
        capacityLabel.setText("");
        gameIdLabel.setValue(null);
        modelIdLabel.setValue(null);
        costLabel.setText("");
        updateMatchIdLabel.setText("");
        cancelMatchIdLabel.setText("");
        sponsorMatchId1Label.setValue(null);
        sponsorMatchId2Label.setValue(null);
        sponsorQuoteLabel.setText("");
    }

    public void refresh() {
        gameIdLabel.setItems(gameTable.findAll().stream().map(e -> e.getIdGame())
                .collect(Collectors.toCollection(FXCollections::observableArrayList)));
        modelIdLabel.setItems(modelTable.findAll().stream().map(e -> e.getIdModel())
                .collect(Collectors.toCollection(FXCollections::observableArrayList)));
        sponsorMatchId2Label.setItems(sponsorTable.findAll().stream().map(e -> e.getIdSponsor())
                .collect(Collectors.toCollection(FXCollections::observableArrayList)));
        sponsorMatchId1Label.setItems(matchTable.findAll().stream().map(e -> e.getIdMatch())
                .collect(Collectors.toCollection(FXCollections::observableArrayList)));
        ObservableList<Game> list1 = gameTable.findAll();
        GameTableview.setItems(list1);
        ObservableList<Sponsor> list2 = sponsorTable.findAll();
        SponsorTableView.setItems(list2);
        ObservableList<Advisement> list3 = advTable.findAll();
        matchSponsorTableView.setItems(list3);
        ObservableList<Model> list4 = modelTable.findAll();
        ModelTableview.setItems(list4);
        ObservableList<Match> list5 = matchTable.findAll();
        matchTableview.setItems(list5);
    }

    private void initializeMatchTable() {
        idMatchColumn.setCellValueFactory(new PropertyValueFactory<>("idMatch"));
        matchNameColumn.setCellValueFactory(new PropertyValueFactory<>("matchName"));
        matchDateColumn.setCellValueFactory(e -> {
            SimpleStringProperty property = new SimpleStringProperty();
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            property.setValue(dateFormat.format(e.getValue().getMatchDate()));
            return property;
        });
        matchCostColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        MatchModelColumn.setCellValueFactory(new PropertyValueFactory<>("idModel"));
        matchGameColumn.setCellValueFactory(new PropertyValueFactory<>("idGame"));
        matchCapacityColumn.setCellValueFactory(new PropertyValueFactory<>("capacity"));
        matchStateColumn.setCellValueFactory(new PropertyValueFactory<>("state"));
        matchactualColumn.setCellValueFactory(new PropertyValueFactory<>("actualPerson"));
    }

    private void initializeSponsorTable() {
        sponsorIdColumn.setCellValueFactory(new PropertyValueFactory<>("idSponsor"));
        sponsorNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        sponsorContactColumn.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
        sponsorEmailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
    }

    private void initializeAdvTable() {
        JoinmatchIdColumn.setCellValueFactory(new PropertyValueFactory<>("idMatch"));
        JoinSponsorIdColumn.setCellValueFactory(new PropertyValueFactory<>("idSponsor"));
        JoinSponsorQuoteColumn.setCellValueFactory(new PropertyValueFactory<>("sponsorization"));
    }

    private void initializeGameTable() {
        gameIdColumn.setCellValueFactory(new PropertyValueFactory<>("idGame"));
        gameNameColumn.setCellValueFactory(new PropertyValueFactory<>("gameName"));
    }

    private void initializeModelTable() {
        modelIdColumn.setCellValueFactory(new PropertyValueFactory<>("idModel"));
        modelNameColumn.setCellValueFactory(new PropertyValueFactory<>("modelName"));
    }

    @FXML
    void createNewMatch(ActionEvent event) {
        this.CreateButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!nameLabel.getText().isEmpty() && !capacityLabel.getText().isEmpty()
                            && !costLabel.getText().isEmpty() && dateLabel.getValue() != null
                            && gameIdLabel.getValue() != null && modelIdLabel.getValue() != null) {
                        if (Utils.isNumeric(capacityLabel.getText()) && Utils.isNumeric(costLabel.getText())) {
                            int maxCapacity = deviceTable
                                    .findAllDeviceByModelAndGame(modelIdLabel.getValue(), gameIdLabel.getValue())
                                    .size();          
                            if (Integer.valueOf(capacityLabel.getText()) > 0
                                    && Integer.valueOf(capacityLabel.getText()) <= maxCapacity) {
                                if (matchTable.save(new Match(0, modelIdLabel.getValue(), gameIdLabel.getValue(),
                                        nameLabel.getText(), java.sql.Date.valueOf(dateLabel.getValue()),
                                        Integer.valueOf(capacityLabel.getText()), 0, "On",
                                        Double.valueOf(costLabel.getText())))) {
                                    cleanLabels();
                                }
                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText(
                                        "Capacity must be greater than 0 and less than !" + maxCapacity);
                                nullLabels.showAndWait();
                            }
                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("Capacity and cost are numeric!");
                            nullLabels.showAndWait();
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }
        });
    }

    @FXML
    void removeMatch(ActionEvent event) {
        this.removeMatchButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!cancelMatchIdLabel.getText().isEmpty()) {
                        if (Utils.isNumeric(cancelMatchIdLabel.getText())) {
                            if (matchTable.findByPrimaryKey(Integer.valueOf(cancelMatchIdLabel.getText()))
                                    .isPresent()) {
                                if (matchTable.isMatchOn(Integer.valueOf(cancelMatchIdLabel.getText()))) {
                                    matchTable.delete(Integer.valueOf(cancelMatchIdLabel.getText()));
                                    cleanLabels();
                                } else {
                                    Alert nullLabels = new Alert(AlertType.INFORMATION);
                                    nullLabels.setContentText("Can't remove a terminated match!");
                                    nullLabels.showAndWait();
                                }

                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("Sponsor not exist!");
                                nullLabels.showAndWait();
                                cancelMatchIdLabel.setText("");
                            }
                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("id label should be numeric!");
                            nullLabels.showAndWait();
                            cancelMatchIdLabel.setText("");
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }
        });
    }

    @FXML
    void InsertSponsorization(ActionEvent event) {
        this.SponsorizationButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!sponsorQuoteLabel.getText().isEmpty() && sponsorMatchId1Label.getValue() != null
                            && sponsorMatchId2Label.getValue() != null) {
                        if (Utils.isNumeric(sponsorQuoteLabel.getText())) {
                            if (Double.valueOf(sponsorQuoteLabel.getText()) > 0.0) {
                                if (!advTable.isSponsorAlreadyPresent(sponsorMatchId1Label.getValue(),
                                        sponsorMatchId2Label.getValue())) {
                                    advTable.insert(new Advisement(sponsorMatchId1Label.getValue(),
                                            sponsorMatchId2Label.getValue(),
                                            Double.valueOf(sponsorQuoteLabel.getText())));
                                    cleanLabels();
                                } else {
                                    Alert nullLabels = new Alert(AlertType.INFORMATION);
                                    nullLabels.setContentText("Sponsor already present!");
                                    nullLabels.showAndWait();
                                }
                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("Quote label must be greater than 0!");
                                nullLabels.showAndWait();
                            }
                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("Quote label must be numeric!");
                            nullLabels.showAndWait();
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }
        });
    }

    @FXML
    void eliminateSponsorization(ActionEvent event) {
        this.eliminateSponsorizationButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (sponsorMatchId1Label.getValue() != null && sponsorMatchId2Label.getValue() != null) {
                        if (advTable.findByPrimaryKey(sponsorMatchId1Label.getValue(), sponsorMatchId2Label.getValue())
                                .isPresent()) {
                            if (advTable.delete(sponsorMatchId1Label.getValue(), sponsorMatchId2Label.getValue())) {
                                cleanLabels();
                            }
                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("Match or Sponsor not exist!");
                            nullLabels.showAndWait();
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }
        });
    }

    @FXML
    void updateMatch(ActionEvent event) {
        this.updateMatchButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!updateMatchIdLabel.getText().isEmpty()) {
                        if (Utils.isNumeric(updateMatchIdLabel.getText())) {
                            if (matchTable.findByPrimaryKey(Integer.valueOf(updateMatchIdLabel.getText()))
                                    .isPresent()) {
                                if (matchTable.isMatchOn(Integer.valueOf(updateMatchIdLabel.getText()))) {
                                    if (matchTable.updateMatch(Integer.valueOf(updateMatchIdLabel.getText()),
                                            modelIdLabel.getValue() == null ? null : modelIdLabel.getValue(),
                                            gameIdLabel.getValue() == null ? null : gameIdLabel.getValue(),
                                            costLabel.getText().isEmpty() ? null : Double.valueOf(costLabel.getText()),
                                            nameLabel.getText(),
                                            dateLabel.getValue() == null ? null
                                                    : java.sql.Date.valueOf((dateLabel.getValue())),
                                            capacityLabel.getText().isEmpty() ? null
                                                    : Integer.valueOf(capacityLabel.getText()))) {
                                        cleanLabels();
                                    }
                                } else {
                                    Alert nullLabels = new Alert(AlertType.INFORMATION);
                                    nullLabels.setContentText("Can't update a terminated match!");
                                    nullLabels.showAndWait();
                                }
                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("Match not exist!");
                                nullLabels.showAndWait();
                            }
                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("id label should be numeric!");
                            nullLabels.showAndWait();
                            updateMatchIdLabel.setText("");
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }
        });
    }

    @FXML
    void updateSponsorization(ActionEvent event) {
        this.updateSponsorizationButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (sponsorMatchId1Label.getValue() != null && sponsorMatchId2Label.getValue() != null
                            && !sponsorQuoteLabel.getText().isEmpty()) {
                        if (Utils.isNumeric(sponsorQuoteLabel.getText())) {
                            if (Double.valueOf(sponsorQuoteLabel.getText()) > 0.0) {
                                if (advTable.isSponsorAlreadyPresent(sponsorMatchId1Label.getValue(),
                                        sponsorMatchId2Label.getValue())) {
                                    advTable.updatePrize(sponsorMatchId1Label.getValue(),
                                            sponsorMatchId2Label.getValue(),
                                            Double.valueOf(sponsorQuoteLabel.getText()));
                                    cleanLabels();
                                } else {
                                    Alert nullLabels = new Alert(AlertType.INFORMATION);
                                    nullLabels.setContentText("Match is not sponsorized by this sponsor!");
                                    nullLabels.showAndWait();
                                }
                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("Quote label must be greater than 0!");
                                nullLabels.showAndWait();
                            }
                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("Quote label must be numeric!");
                            nullLabels.showAndWait();
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }
        });
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        // TODO Auto-generated method stub
        initializeSponsorTable();
        initializeAdvTable();
        initializeGameTable();
        initializeModelTable();
        initializeMatchTable();
        refresh();
    }

}
