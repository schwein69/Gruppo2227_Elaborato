package staffScene;

import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

import connection.ConnectionProvider;
import connection.Utils;
import tables.ClassificationTable;
import tables.ClientTable;
import tables.MatchTable;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import models.Classification;
import models.Client;
import models.Match;

public class MatchSignTabController implements Initializable {
    final static String username = "root";
    final static String password = "";
    final static String dbName = "databasegigi";

    final ConnectionProvider connectionProvider = new ConnectionProvider(username, password, dbName);

    final MatchTable matchTable = new MatchTable(connectionProvider.getMySQLConnection());
    final ClientTable clientTable = new ClientTable(connectionProvider.getMySQLConnection());
    final ClassificationTable claTable = new ClassificationTable(connectionProvider.getMySQLConnection());

    @FXML
    private Button findButton;

    @FXML
    private TableView<Match> matchTableView;

    @FXML
    private TableColumn<Client, Integer> idClientColumn;

    @FXML
    private TableColumn<Match, Integer> matchCapacityColumn;

    @FXML
    private Button signButton;

    @FXML
    private TableColumn<Client, String> nameColumn;

    @FXML
    private TableColumn<Match, String> matchModelColumn;

    @FXML
    private TableColumn<Client, Integer> pointsColumn;

    @FXML
    private TableColumn<Match, String> matchGameColumn;

    @FXML
    private TableColumn<Match, Double> matchCostColumn;

    @FXML
    private TableColumn<Match, Integer> matchActualColumn;

    @FXML
    private TableView<Client> ClientTableView;

    @FXML
    private TableColumn<Match, Integer> idMatchColumn;

    @FXML
    private TextField findLastName;

    @FXML
    private TextField findName;

    @FXML
    private TextField idMatchD;

    @FXML
    private TableColumn<Match, String> matchDateColumn;

    @FXML
    private TableColumn<Client, String> lastnameColumn;

    @FXML
    private TableColumn<Client, String> timeColumn;

    @FXML
    private TableColumn<Match, String> matchNameColumn;

    @FXML
    private TableColumn<Match, String> matchStateColumn;

    @FXML
    private TextField idClientD;

    @FXML
    private TextField idMatchInsert;

    @FXML
    private TextField idClientInsert;

    @FXML
    private ComboBox<Integer> searchMatch;

    @FXML
    private Button removeButton;

    @FXML
    private Button showAllButton;

    @FXML
    private Button searchMatchButton;

    @FXML
    private TableView<Classification> joinTableView;

    @FXML
    private TableColumn<Classification, Integer> joinIdClientColumn;

    @FXML
    private TableColumn<Classification, Integer> joidIdMatchColumn;

    private void cleanLabels() {
        idMatchInsert.setText("");
        idClientInsert.setText("");
        findName.setText("");
        findLastName.setText("");
        idMatchD.setText("");
        idClientD.setText("");
        searchMatch.setValue(null);
    }

    public void refresh() {
        searchMatch.setItems(matchTable.findAll().stream().map(e -> e.getIdMatch())
                .collect(Collectors.toCollection(FXCollections::observableArrayList)));
        ObservableList<Client> list1 = clientTable.findAll();
        ClientTableView.setItems(list1);
        ObservableList<Match> list2 = matchTable.findAll();
        matchTableView.setItems(list2);
        ObservableList<Classification> list3 = claTable.findAll();
        joinTableView.setItems(list3);
    }

    private void initializeMatchTable() {
        idMatchColumn.setCellValueFactory(new PropertyValueFactory<>("idMatch"));
        matchNameColumn.setCellValueFactory(new PropertyValueFactory<>("matchName"));
        matchDateColumn.setCellValueFactory(e -> {
            SimpleStringProperty property = new SimpleStringProperty();
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            property.setValue(dateFormat.format(e.getValue().getMatchDate()));
            return property;
        });
        matchCostColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        matchModelColumn.setCellValueFactory(new PropertyValueFactory<>("idModel"));
        matchGameColumn.setCellValueFactory(new PropertyValueFactory<>("idGame"));
        matchCapacityColumn.setCellValueFactory(new PropertyValueFactory<>("capacity"));
        matchStateColumn.setCellValueFactory(new PropertyValueFactory<>("state"));
        matchActualColumn.setCellValueFactory(new PropertyValueFactory<>("actualPerson"));
    }

    private void initializeClientTable() {
        idClientColumn.setCellValueFactory(new PropertyValueFactory<>("idClient"));
        lastnameColumn.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        timeColumn.setCellValueFactory(new PropertyValueFactory<>("time"));
        pointsColumn.setCellValueFactory(new PropertyValueFactory<>("giftPoints"));
    }

    private void initializeClassificationTable() {
        joidIdMatchColumn.setCellValueFactory(new PropertyValueFactory<>("idMatch"));
        joinIdClientColumn.setCellValueFactory(new PropertyValueFactory<>("idClient"));
    }

    @FXML
    void signUp(ActionEvent event) {
        this.signButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!idMatchInsert.getText().isEmpty() && !idClientInsert.getText().isEmpty()) {
                        if (Utils.isNumeric(idMatchInsert.getText()) && Utils.isNumeric(idClientInsert.getText())) {
                            if (matchTable.findByPrimaryKey(Integer.valueOf(idMatchInsert.getText())).isPresent()
                                    && clientTable.findByPrimaryKey(Integer.valueOf(idClientInsert.getText()))
                                            .isPresent()) {
                                if (!claTable.isClientAlreadyPresentInMatch(Integer.valueOf(idMatchInsert.getText()),
                                        Integer.valueOf(idClientInsert.getText()))) {
                                    if (matchTable.isMatchOn(Integer.valueOf(idMatchInsert.getText()))) {
                                        if (matchTable.isFullMatch(Integer.valueOf(idMatchInsert.getText()))) {
                                            claTable.save(new Classification(Integer.valueOf(idMatchInsert.getText()),
                                                    Integer.valueOf(idClientInsert.getText()), 0, 0));
                                            matchTable.updateInsert(Integer.valueOf(idMatchInsert.getText()));
                                            cleanLabels();
                                        } else {
                                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                                            nullLabels.setContentText("Match Full!");
                                            nullLabels.showAndWait();
                                        }
                                    } else {
                                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                                        nullLabels.setContentText("Match is Over!");
                                        nullLabels.showAndWait();
                                    }

                                } else {
                                    Alert nullLabels = new Alert(AlertType.INFORMATION);
                                    nullLabels.setContentText("Client already present in that match!");
                                    nullLabels.showAndWait();
                                }
                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("Match or client not exist!");
                                nullLabels.showAndWait();
                            }
                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("Labels shoul be numeric!");
                            nullLabels.showAndWait();
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }
        });
    }

    @FXML
    void remove(ActionEvent event) {
        this.removeButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!idMatchD.getText().isEmpty() && !idClientD.getText().isEmpty()) {
                        if (Utils.isNumeric(idMatchD.getText()) && Utils.isNumeric(idClientD.getText())) {
                            if (matchTable.findByPrimaryKey(Integer.valueOf(idMatchD.getText())).isPresent()) {
                                if (claTable.isClientAlreadyPresentInMatch(Integer.valueOf(idMatchD.getText()),
                                        Integer.valueOf(idClientD.getText()))) {
                                    if (matchTable.isMatchOn(Integer.valueOf(idMatchD.getText()))) {
                                        claTable.deleteClientFromMatch(Integer.valueOf(idMatchD.getText()),
                                                Integer.valueOf(idClientD.getText()));
                                        matchTable.updateDelete(Integer.valueOf(idMatchD.getText()));
                                        cleanLabels();
                                    } else {
                                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                                        nullLabels.setContentText("Can't remove client from over match!");
                                        nullLabels.showAndWait();
                                    }

                                } else {
                                    Alert nullLabels = new Alert(AlertType.INFORMATION);
                                    nullLabels.setContentText("Client not present in that match!");
                                    nullLabels.showAndWait();
                                }
                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("Match not exist!");
                                nullLabels.showAndWait();
                            }
                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("Labels shoul be numeric!");
                            nullLabels.showAndWait();
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }
        });
    }

    @FXML
    void searchMatchFunc(ActionEvent event) {
        this.searchMatchButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                if (searchMatch.getValue() != null) {
                    joinTableView.setItems(claTable.findMatch(searchMatch.getValue()));
                } else {
                    Alert nullLabels = new Alert(AlertType.INFORMATION);
                    nullLabels.setContentText("Select a Match!");
                    nullLabels.showAndWait();
                }

            }
        });
    }

    @FXML
    void findClient(ActionEvent event) {
        this.findButton.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!findLastName.getText().isEmpty() && !findName.getText().isEmpty()) {
                        ClientTableView.setItems(
                                clientTable.findByNameAndLastName(findName.getText(), findLastName.getText()));
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Empty label");
                        nullLabels.showAndWait();
                    }
                }
                cleanLabels();
            }
        });
    }

    @FXML
    void showAllClient(ActionEvent event) {
        ClientTableView.setItems(clientTable.findAll());
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        // TODO Auto-generated method stub
        initializeMatchTable();
        initializeClientTable();
        initializeClassificationTable();
        refresh();
    }
}
