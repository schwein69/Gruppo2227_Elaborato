package staffScene;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Optional;
import java.util.ResourceBundle;

import connection.ConnectionProvider;
import connection.Utils;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import models.Access;
import models.Category;
import models.Client;
import models.Device;
import models.Game;
import models.Model;
import models.Room;
import tables.*;

class JoinRoomDevice {
    private Room room;
    private Device device;
    private Model model;
    private Access access;

    public JoinRoomDevice(Room room, Device device, Model model, Access access) {
        this.room = room;
        this.device = device;
        this.model = model;
        this.access = access;
    }

    public Room getRoom() {
        return room;
    }

    public void setRoom(Room room) {
        this.room = room;
    }

    public Device getDevice() {
        return device;
    }

    public void setDevice(Device device) {
        this.device = device;
    }

    public Model getModel() {
        return model;
    }

    public Access getAccess() {
        return access;
    }

}

public class StaffAssignTabController implements Initializable {
    final static String username = "root";
    final static String password = "";
    final static String dbName = "databasegigi";

    final ConnectionProvider connectionProvider = new ConnectionProvider(username, password, dbName);
    final GameTable gameTable = new GameTable(connectionProvider.getMySQLConnection());
    final ClientTable clientTable = new ClientTable(connectionProvider.getMySQLConnection());
    final ModelTable modelTable = new ModelTable(connectionProvider.getMySQLConnection());
    final AccessTable accessTable = new AccessTable(connectionProvider.getMySQLConnection());
    final DeviceTable deviceTable = new DeviceTable(connectionProvider.getMySQLConnection());
    final CategoryTable categoryTable = new CategoryTable(connectionProvider.getMySQLConnection());
    final Connection con = connectionProvider.getMySQLConnection();

    @FXML
    private TableColumn<Client, String> ClientLastNameColumn;

    @FXML
    private TableView<Client> ClientTable;

    @FXML
    private TableColumn<Client, String> ClientNameColumn;

    @FXML
    private TableColumn<JoinRoomDevice, String> DeviceModelColumn;

    @FXML
    private TableColumn<JoinRoomDevice, Integer> idClientColumn;

    @FXML
    private TableColumn<JoinRoomDevice, String> DeviceNameColumn;

    @FXML
    private TableColumn<JoinRoomDevice, Integer> RoomColumn;

    @FXML
    private TableColumn<Client, Integer> ClientPointsColumn;

    @FXML
    private Button findDeviceWithModelButton;

    @FXML
    private TableColumn<Game, Integer> IdGameColumn;

    @FXML
    private TableColumn<JoinRoomDevice, String> DeviceStateColumn;

    @FXML
    private TableView<Game> GameTable;

    @FXML
    private TableColumn<Client, Time> ClientLastTimeColumn;

    @FXML
    private TextField gameNameLabel;

    @FXML
    private TableColumn<Game, String> GameNameColumn;

    @FXML
    private TableColumn<JoinRoomDevice, Integer> DeviceIdColumn;

    @FXML
    private TableColumn<Client, Integer> CLientIdColumn;

    @FXML
    private TextField findNameLabel;

    @FXML
    private Button showGamesButton;

    @FXML
    private Button disconnectButton;

    @FXML
    private TextField DeviceIdLabel;

    @FXML
    private Button FindDeviceWithgameButton;

    @FXML
    private TextField ModelNameLabel;

    @FXML
    private Button assignButton;

    @FXML
    private TableColumn<JoinRoomDevice, String> DeviceOccupationColumn;

    @FXML
    private TextField ClientIdLabel;

    @FXML
    private TextField findLastNameLabel;

    @FXML
    private TableView<JoinRoomDevice> DeviceTable;

    @FXML
    private Button findClientButton;

    @FXML
    private Button showClientButton;

    @FXML
    private TableColumn<Category, String> categorynameColumn;

    @FXML
    private Button findDeviceWithCategoryButton;

    @FXML
    private TableView<Category> categoryTableView;

    @FXML
    private TableColumn<Category, Integer> categoryIdColumn;

    @FXML
    private TextField categoryLabel;

    private void cleanLabels() {
        ClientIdLabel.setText("");
        DeviceIdLabel.setText("");
        gameNameLabel.setText("");
        ModelNameLabel.setText("");
        findLastNameLabel.setText("");
        findNameLabel.setText("");
        categoryLabel.setText("");
    }

    private ObservableList<JoinRoomDevice> orderDeviceByGame(String gameName) {
        final String query = "SELECT *  FROM device dev " + "JOIN sala ON sala.IdSala = dev.IdSala "
                + "JOIN modello ON dev.idModello = modello.idModello "
                + "JOIN associazione ON associazione.IdDevice = dev.IdDevice "
                + "JOIN gioco ON associazione.IdGioco = gioco.idGioco  "
                + "LEFT JOIN ( SELECT * FROM accesso WHERE accesso.DataFine IS NULL AND accesso.OraFineAccesso IS NULL) A ON dev.IdDevice = A.IdDevice "
                + " WHERE NomeGioco LIKE CONCAT('%',?,'%') AND dev.StatoDevice = 'Working' GROUP BY dev.IdDevice";
        try (final PreparedStatement statement = this.con.prepareStatement(query)) {
            statement.setString(1, gameName);
            final ResultSet rs = statement.executeQuery();
            return this.readDeviceFromResultSetJoinRoomDevice(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    private ObservableList<JoinRoomDevice> orderDeviceByModel(String ModelName) {
        final String query = "SELECT * FROM device dev " + "JOIN sala ON sala.IdSala = dev.IdSala "
                + "JOIN modello ON dev.idModello = modello.idModello "
                + "LEFT JOIN ( SELECT * FROM accesso WHERE accesso.DataFine IS NULL AND accesso.OraFineAccesso IS NULL) A ON dev.IdDevice = A.IdDevice "
                + " WHERE NomeModello LIKE CONCAT('%',?,'%') AND dev.StatoDevice = 'Working' GROUP BY dev.IdDevice";
        try (final PreparedStatement statement = this.con.prepareStatement(query)) {
            statement.setString(1, ModelName);
            final ResultSet rs = statement.executeQuery();
            return this.readDeviceFromResultSetJoinRoomDevice(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    private ObservableList<JoinRoomDevice> orderDeviceByCategory(String categoryName) {
        final String query = "SELECT * FROM device dev " + "JOIN sala ON sala.IdSala = dev.IdSala "
                + "JOIN modello ON dev.idModello = modello.idModello JOIN associazione ON associazione.IdDevice = dev.IdDevice JOIN gioco ON associazione.IdGioco = gioco.idGioco JOIN categoria ON categoria.IdCategoria = gioco.IdCategoria   "
                + "LEFT JOIN ( SELECT * FROM accesso WHERE accesso.DataFine IS NULL AND accesso.OraFineAccesso IS NULL) A ON dev.IdDevice = A.IdDevice "
                + " WHERE NomeCategoria LIKE CONCAT('%',?,'%') AND dev.StatoDevice = 'Working' GROUP BY dev.IdDevice";
        try (final PreparedStatement statement = this.con.prepareStatement(query)) {
            statement.setString(1, categoryName);
            final ResultSet rs = statement.executeQuery();
            return this.readDeviceFromResultSetJoinRoomDevice(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    @FXML
    void orderDeviceByGame(ActionEvent event) {
        this.FindDeviceWithgameButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!gameNameLabel.getText().isEmpty()) {
                        DeviceTable.setItems(orderDeviceByGame(gameNameLabel.getText()));
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Empty label");
                        nullLabels.showAndWait();
                    }
                }
                cleanLabels();
            }

        });
    }

    @FXML
    void findDeviceWithCategory(ActionEvent event) {
        this.findDeviceWithCategoryButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!categoryLabel.getText().isEmpty()) {
                        DeviceTable.setItems(orderDeviceByCategory(categoryLabel.getText()));
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Empty label");
                        nullLabels.showAndWait();
                    }
                }
                cleanLabels();
            }
        });
    }

    @FXML
    void showAllDevice(ActionEvent event) {
        DeviceTable.setItems(this.findAllWithJoinInDeviceTable());
    }

    @FXML
    void showAllClient(ActionEvent event) {
        ClientTable.setItems(clientTable.findAll());
    }

    @FXML
    void orderDeviceByModel(ActionEvent event) {
        this.findDeviceWithModelButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!ModelNameLabel.getText().isEmpty()) {
                        DeviceTable.setItems(orderDeviceByModel(ModelNameLabel.getText()));
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Empty label");
                        nullLabels.showAndWait();
                    }
                }
                cleanLabels();
            }
        });
    }

    @FXML
    void assignDeviceToClient(ActionEvent event) {
        this.assignButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!ClientIdLabel.getText().isEmpty() && Utils.isNumeric(ClientIdLabel.getText())
                            && !DeviceIdLabel.getText().isEmpty() && Utils.isNumeric(DeviceIdLabel.getText())) {
                        if (accessTable.isClientAlreadyPlaying(Integer.valueOf(ClientIdLabel.getText()))
                                || (accessTable.isDeviceAlreadyOccuped(Integer.valueOf(DeviceIdLabel.getText())))) {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText(
                                    "Client is already playing or Device is occuped! Must disconnect before");
                            nullLabels.showAndWait();
                        } else {
                            if (deviceTable.isDeviceWorking(Integer.valueOf(DeviceIdLabel.getText()))) {
                                if (clientTable.enoughtTime(Integer.valueOf(ClientIdLabel.getText()))
                                        && accessTable.save(new Access(Integer.valueOf(DeviceIdLabel.getText()),
                                                Integer.valueOf(ClientIdLabel.getText()),
                                                java.sql.Date.valueOf(LocalDate.now()),
                                                LocalTime.now().withNano(0).toString(), null, null))
                                        && deviceTable.updateOccupation(Integer.valueOf(DeviceIdLabel.getText()),
                                                "Occuped")) {
                                    refresh();
                                } else {
                                    Alert nullLabels = new Alert(AlertType.INFORMATION);
                                    nullLabels.setContentText("Client's time is not sufficient");
                                    nullLabels.showAndWait();
                                }
                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("Device is not working");
                                nullLabels.showAndWait();
                            }

                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Empty label or not numeric");
                        nullLabels.showAndWait();
                    }
                }
                cleanLabels();
            }
        });
    }

    @FXML
    void disconnectClientFromDevice(ActionEvent event) {
        this.disconnectButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!ClientIdLabel.getText().isEmpty() && Utils.isNumeric(ClientIdLabel.getText())
                            && !DeviceIdLabel.getText().isEmpty() && Utils.isNumeric(DeviceIdLabel.getText())) {
                        if (deviceTable.findByPrimaryKey(Integer.valueOf(DeviceIdLabel.getText())).isPresent()) {
                            if (accessTable.isThisDeviceOccupedByThisClient(Integer.valueOf(DeviceIdLabel.getText()),
                                    Integer.valueOf(ClientIdLabel.getText()))) {
                                if (accessTable.update(Integer.valueOf(DeviceIdLabel.getText()),
                                        Integer.valueOf(ClientIdLabel.getText()))
                                        && deviceTable.updateOccupation(Integer.valueOf(DeviceIdLabel.getText()),
                                                "Empty")) {
                                    int accessTimeInSeconds = accessTable.getAccessTime(
                                            Integer.valueOf(DeviceIdLabel.getText()),
                                            Integer.valueOf(ClientIdLabel.getText()));
                                    int leaveTimeInSeconds = accessTable.getLeaveTime(
                                            Integer.valueOf(DeviceIdLabel.getText()),
                                            Integer.valueOf(ClientIdLabel.getText()));
                                    int newTime = leaveTimeInSeconds > accessTimeInSeconds
                                            ? leaveTimeInSeconds - accessTimeInSeconds
                                            : leaveTimeInSeconds + 86400 - accessTimeInSeconds;
                                    if (newTime < 0) {
                                        newTime = 0;
                                    }
                                    clientTable.updateTime(Integer.valueOf(ClientIdLabel.getText()), newTime);
                                    refresh();
                                }
                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("Device is not occuped by this client!Can't disconnect");
                                nullLabels.showAndWait();
                            }
                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("Wrong device id!");
                            nullLabels.showAndWait();
                            DeviceIdLabel.setText("");
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Empty label or not numeric");
                        nullLabels.showAndWait();
                    }
                }
                cleanLabels();
            }
        });
    }

    @FXML
    void findClient(ActionEvent event) {
        this.findClientButton.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!findLastNameLabel.getText().isEmpty() && !findNameLabel.getText().isEmpty()) {
                        ClientTable.setItems(clientTable.findByNameAndLastName(findNameLabel.getText(),
                                findLastNameLabel.getText()));
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Empty label");
                        nullLabels.showAndWait();
                    }
                }
                cleanLabels();
            }
        });
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        // TODO Auto-generated method stub
        initializeClientTable();
        initializeDeviceTable();
        initializeGameTable();
        initializeCategoryTable();
    }

    public void refresh() {
        ObservableList<Client> list1 = clientTable.findAll();
        ClientTable.setItems(list1);
        ObservableList<Game> list2 = gameTable.findAll();
        GameTable.setItems(list2);
        ObservableList<JoinRoomDevice> list3 = this.findAllWithJoinInDeviceTable();
        DeviceTable.setItems(list3);
    }

    private ObservableList<JoinRoomDevice> readDeviceFromResultSetJoinRoomDevice(final ResultSet resultSet) {
        ObservableList<JoinRoomDevice> listJoin = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {
                JoinRoomDevice newObject = new JoinRoomDevice(
                        new Room(resultSet.getInt("idSala"), resultSet.getInt("CapienzaMassimaSala"),
                                resultSet.getInt("CapienzaAttuale")),
                        new Device(resultSet.getInt("idDevice"), resultSet.getInt("idSala"),
                                resultSet.getInt("idModello"), resultSet.getString("NomeDevice"),
                                resultSet.getString("StatoDevice"), resultSet.getString("OccupatoDevice"),
                                resultSet.getInt("MemoriaDevice")),
                        new Model(resultSet.getInt("idModello"), resultSet.getString("NomeModello"),
                                resultSet.getInt("MemoriaDisponibile")),
                        new Access(resultSet.getInt("IdDevice"), resultSet.getInt("IdCliente"),
                                Utils.sqlDateToDate(resultSet.getDate("DataAccesso")),
                                resultSet.getString("OraAccesso"),
                                Optional.ofNullable(Utils.sqlDateToDate(resultSet.getDate("DataFine"))),
                                Optional.ofNullable(resultSet.getString("OraFineAccesso"))));
                listJoin.add(newObject);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listJoin;
    }

    private ObservableList<JoinRoomDevice> findAllWithJoinInDeviceTable() {
        try (final Statement statement = this.con.createStatement()) {
            final ResultSet rs = statement.executeQuery("SELECT *  FROM device dev"
                    + " JOIN sala ON dev.IdSala = sala.IdSala " + " JOIN modello ON dev.idModello = modello.idModello "
                    + " LEFT JOIN ( SELECT * FROM accesso WHERE accesso.DataFine IS NULL AND accesso.OraFineAccesso IS NULL) "
                    + " A ON dev.IdDevice = A.IdDevice" + " ORDER BY dev.IdSala");
            /* la cosa del timer a parole */
            return readDeviceFromResultSetJoinRoomDevice(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    private void initializeDeviceTable() {
        this.RoomColumn
                .setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getRoom().getIdRoom()).asObject());
        this.DeviceIdColumn
                .setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getDevice().getIdDevice()).asObject());
        this.DeviceNameColumn
                .setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getDevice().getDeviceName()));
        this.DeviceStateColumn
                .setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getDevice().getStateDevice()));
        this.DeviceOccupationColumn
                .setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getDevice().getOccuped()));
        this.DeviceModelColumn
                .setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getModel().getModelName()));
        this.idClientColumn
                .setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getAccess().getIdClient()).asObject());
        ObservableList<JoinRoomDevice> list = this.findAllWithJoinInDeviceTable();
        DeviceTable.setItems(list);
    }

    private void initializeClientTable() {
        CLientIdColumn.setCellValueFactory(new PropertyValueFactory<>("idClient"));
        ClientLastNameColumn.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        ClientNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        ClientLastTimeColumn.setCellValueFactory(new PropertyValueFactory<>("time"));
        ClientPointsColumn.setCellValueFactory(new PropertyValueFactory<>("giftPoints"));
        ObservableList<Client> list = clientTable.findAll();
        ClientTable.setItems(list);
    }

    private void initializeGameTable() {
        this.IdGameColumn.setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getIdGame()).asObject());
        this.GameNameColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getGameName()));
        ObservableList<Game> list = gameTable.findAll();
        GameTable.setItems(list);
    }

    private void initializeCategoryTable() {
        this.categoryIdColumn
                .setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getIdCategory()).asObject());
        this.categorynameColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getNameCategory()));
        ObservableList<Category> list = categoryTable.findAll();
        categoryTableView.setItems(list);
    }

}
