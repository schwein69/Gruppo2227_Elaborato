package staffScene;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.text.DateFormat;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Optional;
import java.util.ResourceBundle;

import connection.ConnectionProvider;
import connection.Utils;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import models.Client;
import tables.ClientTable;

public class StaffUpdateClientTabController implements Initializable {
    final static String username = "root";
    final static String password = "";
    final static String dbName = "databasegigi";

    final ConnectionProvider connectionProvider = new ConnectionProvider(username, password, dbName);
    final ClientTable clientTable = new ClientTable(connectionProvider.getMySQLConnection());
    final Connection con = connectionProvider.getMySQLConnection();
    Format formatter = new SimpleDateFormat("dd/MM/yy");
    @FXML
    private TableColumn<Client, Integer> clientIdColumn;

    @FXML
    private TableColumn<Client, Integer> clientPhoneColumn;

    @FXML
    private TextField findLastName;

    @FXML
    private TextField findName;

    @FXML
    private TableColumn<Client, String> clientAddressColumn;

    @FXML
    private TableView<Client> ClientTable;

    @FXML
    private TextField InsertPhoneLabel;

    @FXML
    private TextField InsertPostalCodeLabel;

    @FXML
    private TableColumn<Client, String> clientNameColumn;

    @FXML
    private TextField InsertCityLabel;

    @FXML
    private TextField InsertAddressLabel;

    @FXML
    private TextField InsertIdLabel;

    @FXML
    private TableColumn<Client, Time> clientTimeColumn;

    @FXML
    private TableColumn<Client, Integer> clientPointsColumn;

    @FXML
    private TextField InsertEmailLabel;

    @FXML
    private TableColumn<Client, String> clientPostalCodeColumn;

    @FXML
    private TableColumn<Client, String> clientCityColumn;

    @FXML
    private TableColumn<Client, String> birthdayColumn;

    @FXML
    private TableColumn<Client, String> clientEmailColumn;

    @FXML
    private TableColumn<Client, String> clientLastNameColumn;

    @FXML
    private PasswordField InsertPinLabel;

    @FXML
    private DatePicker birthdayLabel;

    @FXML
    private ComboBox<String> genderLabel;

    @FXML
    private Button updateButton;
    
    @FXML
    private Button showAllClientButton;

    @FXML
    private Button findButton;

    private void cleanLabels() {
        InsertPinLabel.setText("");
        InsertEmailLabel.setText("");
        InsertIdLabel.setText("");
        InsertCityLabel.setText("");
        InsertAddressLabel.setText("");
        InsertPhoneLabel.setText("");
        InsertPostalCodeLabel.setText("");
        findLastName.setText("");
        findName.setText("");
        birthdayLabel.setValue(null);
        genderLabel.setValue(null);
    }

    private boolean updateRow(int clientId) {
        String query = "SELECT * FROM cliente WHERE IdCliente = " + clientId;

        try (final Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                ResultSet.CONCUR_UPDATABLE)) {
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                if (!InsertEmailLabel.getText().isEmpty()) {
                    rs.updateString("EmailCliente", InsertEmailLabel.getText());
                }
                if (!InsertPhoneLabel.getText().isEmpty()) {
                    rs.updateString("TelefonoCliente", InsertPhoneLabel.getText());
                }
                if (!InsertPinLabel.getText().isEmpty()) {
                    rs.updateString("PinCliente", InsertPinLabel.getText());
                }
                if (!InsertAddressLabel.getText().isEmpty()) {
                    rs.updateString("Via", InsertAddressLabel.getText());
                }
                if (!InsertPostalCodeLabel.getText().isEmpty()) {
                    rs.updateString("CodicePostale", InsertPostalCodeLabel.getText());
                }
                if (!InsertCityLabel.getText().isEmpty()) {
                    rs.updateString("Città", InsertCityLabel.getText());
                }
                if (genderLabel.getValue() != null) {
                    rs.updateString("GenereCliente", genderLabel.getValue());
                }
                if (birthdayLabel.getValue() != null) {
                    rs.updateDate("DataDiNascitaCliente", java.sql.Date.valueOf(birthdayLabel.getValue()));
                }
                rs.updateRow();
            }
            return true;
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return false;
    }

    @FXML
    void TryUpdateClient(ActionEvent event) throws IOException {
        this.updateButton.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!InsertIdLabel.getText().isEmpty() && Utils.isNumeric(InsertIdLabel.getText())) {
                        if (updateRow(Integer.valueOf(InsertIdLabel.getText()))) {
                            refresh();
                        } else {
                            Alert alert2 = new Alert(AlertType.INFORMATION);
                            alert2.setContentText("Insert more");
                            alert2.showAndWait();
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Empty label or not numeric");
                        nullLabels.showAndWait();
                    }
                }
                cleanLabels();
            }
        });
    }

    @FXML
    void FindClient(ActionEvent event) throws IOException {
        this.findButton.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!findLastName.getText().isEmpty() && !findName.getText().isEmpty()) {
                        ClientTable.setItems(
                                clientTable.findByNameAndLastName(findName.getText(), findLastName.getText()));
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Empty label");
                        nullLabels.showAndWait();
                    }
                }
                cleanLabels();
            }
        });

    }
    
    @FXML
    void showAllClient(ActionEvent event) throws IOException {
        this.showAllClientButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    refresh();
                }
            }
        });

    }

    public void refresh() {
        ObservableList<Client> list = clientTable.findAll();
        ClientTable.setItems(list);
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        initializeTable();
    }

    private void setComboBox() {
        this.genderLabel.getItems().add("Male");
        this.genderLabel.getItems().add("Female");
    }

    private void initializeTable() {     
        clientIdColumn.setCellValueFactory(new PropertyValueFactory<>("idClient"));
        clientLastNameColumn.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        clientNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        clientEmailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
        clientPhoneColumn.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
        birthdayColumn.setCellValueFactory(e -> {
            SimpleStringProperty property = new SimpleStringProperty();
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            property.setValue(dateFormat.format(e.getValue().getBirthday()));
            return property;
        });
        clientAddressColumn.setCellValueFactory(new PropertyValueFactory<>("address"));
        clientPostalCodeColumn.setCellValueFactory(new PropertyValueFactory<>("postalCode"));
        clientCityColumn.setCellValueFactory(new PropertyValueFactory<>("city"));
        clientTimeColumn.setCellValueFactory(new PropertyValueFactory<>("time"));
        clientPointsColumn.setCellValueFactory(new PropertyValueFactory<>("giftPoints"));
        ObservableList<Client> list = clientTable.findAll();
        ClientTable.setItems(list);
        setComboBox();
    }
}
