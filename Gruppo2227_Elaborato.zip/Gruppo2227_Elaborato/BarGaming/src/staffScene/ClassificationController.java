package staffScene;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.stream.Collectors;
import java.time.LocalDate;
import java.time.LocalTime;
import connection.ConnectionProvider;
import connection.Utils;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert.AlertType;
import models.Access;
import models.Classification;
import models.Client;
import models.Game;
import models.Match;
import models.Model;
import tables.AccessTable;
import tables.ClassificationTable;
import tables.ClientTable;
import tables.DeviceTable;
import tables.MatchTable;

class JoinMatchModelGame {
    private Match match;
    private Model model;
    private Game game;

    public JoinMatchModelGame(Match match, Model model, Game game) {
        this.match = match;
        this.model = model;
        this.game = game;
    }

    public Match getMatch() {
        return match;
    }

    public Model getModel() {
        return model;
    }

    public Game getGame() {
        return game;
    }

}

class JoinClientClass {
    private Client client;
    private Classification cla;

    public JoinClientClass(Client client, Classification cla) {
        this.client = client;
        this.cla = cla;
    }

    public Client getClient() {
        return client;
    }

    public Classification getCla() {
        return cla;
    }

}

public class ClassificationController implements Initializable {
    private final static String username = "root";
    private final static String password = "";
    private final static String dbName = "databasegigi";
    private final static String IDGARA = "Id Gara :";
    private final static int POINTS = 50;

    private final ConnectionProvider connectionProvider = new ConnectionProvider(username, password, dbName);
    private final ClientTable clientTable = new ClientTable(connectionProvider.getMySQLConnection());
    private final MatchTable matchTable = new MatchTable(connectionProvider.getMySQLConnection());
    private final DeviceTable deviceTable = new DeviceTable(connectionProvider.getMySQLConnection());
    private final AccessTable accessTable = new AccessTable(connectionProvider.getMySQLConnection());
    private final ClassificationTable claTable = new ClassificationTable(connectionProvider.getMySQLConnection());
    private final Connection con = connectionProvider.getMySQLConnection();
    @FXML
    private TableColumn<JoinClientClass, Integer> clientIdColumn;

    @FXML
    private TableColumn<JoinMatchModelGame, String> joinMatchDateColumn;

    @FXML
    private TableColumn<JoinMatchModelGame, Integer> joinActualNumberColumn;

    @FXML
    private Label idMatchLabel;

    @FXML
    private TableColumn<JoinMatchModelGame, Integer> joinCapacityColumn;

    @FXML
    private TableColumn<JoinMatchModelGame, String> joinNameGameColumn;

    @FXML
    private TableColumn<JoinMatchModelGame, Integer> joinGameIdColumn;

    @FXML
    private TableColumn<JoinMatchModelGame, String> joinNameMatchColumn;

    @FXML
    private TableColumn<JoinClientClass, String> clientNameColumn;

    @FXML
    private TableColumn<JoinClientClass, Integer> clientActualPointsColumn;

    @FXML
    private TableColumn<JoinClientClass, String> clientPhoneColumn;

    @FXML
    private TableColumn<JoinMatchModelGame, String> joinStateColumn;

    @FXML
    private TableColumn<JoinMatchModelGame, Double> joinMatchCostColumn;

    @FXML
    private TableView<JoinClientClass> joinClientClassificationTableView;

    @FXML
    private Button searchMatchButton;

    @FXML
    private ComboBox<Integer> createMatchCombo;

    @FXML
    private ComboBox<Integer> startMatchIdCombo;

    @FXML
    private TableView<JoinMatchModelGame> joinMatchModelGameTbleView;

    @FXML
    private TableColumn<JoinMatchModelGame, Integer> joinModelIdColumn;

    @FXML
    private TableColumn<JoinMatchModelGame, Integer> joinIdMatchColumn;

    @FXML
    private TableColumn<JoinMatchModelGame, String> joinModelNameColumn;

    @FXML
    private ComboBox<Integer> searchMatchCombo;

    @FXML
    private Button createClassButton;

    @FXML
    private Button startMatchButton;

    @FXML
    private TableColumn<JoinClientClass, Integer> clientPositionColumn;

    @FXML
    private TableColumn<JoinClientClass, String> clientEmailColumn;

    @FXML
    private TableColumn<JoinClientClass, String> clientLastNameColumn;

    @FXML
    private TableColumn<JoinClientClass, Integer> clientWinPointsColumn;

    private ObservableList<JoinMatchModelGame> readJoinMatchModelGameFromResultSet(final ResultSet resultSet) {
        ObservableList<JoinMatchModelGame> listJoin = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {
                JoinMatchModelGame newObject = new JoinMatchModelGame(
                        new Match(resultSet.getInt("IdGara"), resultSet.getInt("IdModello"),
                                resultSet.getInt("IdGioco"), resultSet.getString("NomeGara"),
                                Utils.sqlDateToDate(resultSet.getDate("DataGara")), resultSet.getInt("Capienza"),
                                resultSet.getInt("IscrittiAttuali"), resultSet.getString("StatoGara"),
                                resultSet.getDouble("QuotaIscrizione")),
                        new Model(resultSet.getInt("idModello"), resultSet.getString("NomeModello"),
                                resultSet.getInt("MemoriaDisponibile")),
                        new Game(resultSet.getInt("idGioco"), resultSet.getInt("IdCategoria"),
                                resultSet.getString("NomeGioco"), resultSet.getInt("MemoriaOccupata")));
                listJoin.add(newObject);
            }

        } catch (

        SQLException e) {
            e.printStackTrace();
        }
        return listJoin;
    }

    private ObservableList<JoinMatchModelGame> findAllJoinMatchModelGame() {
        try (final Statement statement = this.con.createStatement()) {
            final ResultSet rs = statement.executeQuery(
                    "SELECT *  FROM gara m, modello mo, gioco g WHERE m.IdModello = mo.IdModello AND m.IdGioco = g.idGioco ORDER BY m.StatoGara");
            return readJoinMatchModelGameFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    private ObservableList<JoinClientClass> readJoinClientClassFromResultSet(final ResultSet resultSet) {
        ObservableList<JoinClientClass> listJoin = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {
                JoinClientClass newObject = new JoinClientClass(
                        new Client(resultSet.getInt("idCliente"), resultSet.getString("NomeCliente"),
                                resultSet.getString("CognomeCliente"), resultSet.getString("GenereCliente"),
                                Utils.sqlDateToDate(resultSet.getDate("DataDiNascitaCliente")),
                                resultSet.getString("TelefonoCliente"), resultSet.getString("EmailCliente"),
                                resultSet.getString("PinCliente"), resultSet.getString("Città"),
                                resultSet.getString("Via"), resultSet.getString("CodicePostale"),
                                resultSet.getString("Tempo"), resultSet.getInt("PuntiPremio")),
                        new Classification(resultSet.getInt("IdGara"), resultSet.getInt("IdCliente"),
                                resultSet.getInt("Posizione"), resultSet.getInt("PuntiPremioVinti")));
                listJoin.add(newObject);
            }

        } catch (

        SQLException e) {
            e.printStackTrace();
        }
        return listJoin;
    }

    private ObservableList<JoinClientClass> findAllJoinClientClass() {
        try (final Statement statement = this.con.createStatement()) {
            final ResultSet rs = statement.executeQuery(
                    "SELECT *  FROM cliente c, classificazione cl WHERE c.IdCliente = cl.IdCliente AND cl.IdGara = "
                            + this.searchMatchCombo.getValue() + " ORDER BY cl.Posizione");
            return readJoinClientClassFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    private void cleanLabels() {
        createMatchCombo.setValue(null);
        searchMatchCombo.setValue(null);
        idMatchLabel.setText(IDGARA);
    }

    public void refresh() {
        createMatchCombo.setItems(matchTable.findAllStartedMatch().stream().map(e -> e.getIdMatch())
                .collect(Collectors.toCollection(FXCollections::observableArrayList)));
        searchMatchCombo.setItems(matchTable.findAll().stream().map(e -> e.getIdMatch())
                .collect(Collectors.toCollection(FXCollections::observableArrayList)));
        startMatchIdCombo.setItems(matchTable.findAllNotStartedMatch().stream().map(e -> e.getIdMatch())
                .collect(Collectors.toCollection(FXCollections::observableArrayList)));
        ObservableList<JoinMatchModelGame> list1 = this.findAllJoinMatchModelGame();
        joinMatchModelGameTbleView.setItems(list1);

    }

    private void initializePrizeTable() {
        joinIdMatchColumn
                .setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getMatch().getIdMatch()).asObject());
        joinNameMatchColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getMatch().getMatchName()));
        joinMatchDateColumn.setCellValueFactory(e -> {
            SimpleStringProperty property = new SimpleStringProperty();
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            property.setValue(dateFormat.format(e.getValue().getMatch().getMatchDate()));
            return property;
        });

        joinMatchCostColumn
                .setCellValueFactory(e -> new SimpleDoubleProperty(e.getValue().getMatch().getPrice()).asObject());
        joinModelIdColumn
                .setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getMatch().getIdModel()).asObject());
        joinModelNameColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getModel().getModelName()));
        joinGameIdColumn
                .setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getMatch().getIdGame()).asObject());
        joinNameGameColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getGame().getGameName()));
        joinCapacityColumn
                .setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getMatch().getCapacity()).asObject());
        joinStateColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getMatch().getState()));
        joinActualNumberColumn.setCellValueFactory(
                e -> new SimpleIntegerProperty(e.getValue().getMatch().getActualPerson()).asObject());
    }

    private void initializeClientTable() {
        clientIdColumn
                .setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getClient().getIdClient()).asObject());
        clientLastNameColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getClient().getLastName()));
        clientNameColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getClient().getName()));
        clientEmailColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getClient().getEmail()));
        clientPhoneColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getClient().getPhoneNumber()));
        clientActualPointsColumn.setCellValueFactory(
                e -> new SimpleIntegerProperty(e.getValue().getClient().getGiftPoints()).asObject());
        clientPositionColumn
                .setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getCla().getPosition()).asObject());
        clientWinPointsColumn.setCellValueFactory(
                e -> new SimpleIntegerProperty(e.getValue().getCla().getGiftPointsWon()).asObject());
    }

    @FXML
    void createClass(ActionEvent event) {
        this.createClassButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (createMatchCombo.getValue() != null) {
                        matchTable.finishMatch(createMatchCombo.getValue());// termina gara
                        joinMatchModelGameTbleView.setItems(findAllJoinMatchModelGame());// aggiorna tabella gara
                        List<Integer> UsedPositions = new ArrayList<>();
                        int numberOfSign = matchTable.findByPrimaryKey(createMatchCombo.getValue()).get()
                                .getActualPerson();
                        for (Integer idCliente : claTable.findAllSignedClients(createMatchCombo.getValue())) {
                            int position = new Random().nextInt(numberOfSign) + 1;
                            while (UsedPositions.contains(position)) {
                                position = new Random().nextInt(numberOfSign) + 1;
                            }
                            UsedPositions.add(position);

                            claTable.updateClassification(createMatchCombo.getValue(), idCliente, position,
                                    POINTS / position);
                            clientTable.updatePointsShop(idCliente, POINTS / position);
                        }
                        for (Integer idDevice : deviceTable.findAllOccupedDeviceByModelAndGame(
                                matchTable.findByPrimaryKey(createMatchCombo.getValue()).get().getIdModel(),
                                matchTable.findByPrimaryKey(createMatchCombo.getValue()).get().getIdGame())) {
                            deviceTable.updateOccupation(idDevice, "Empty");
                            accessTable.updateMatchDevice(idDevice);
                        }

                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Select a match id!");
                        nullLabels.showAndWait();
                    }
                }
                joinClientClassificationTableView.setItems(findAllJoinClientClass());
                refresh();
                cleanLabels();       
            }
        });
    }

    @FXML
    void searchmatch(ActionEvent event) {
        this.searchMatchButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (searchMatchCombo.getValue() != null) {
                        joinClientClassificationTableView.setItems(findAllJoinClientClass());
                        idMatchLabel.setText(new String(IDGARA).concat(searchMatchCombo.getValue().toString()));
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Select a client id!");
                        nullLabels.showAndWait();
                    }
                }
            }
        });
    }

    @FXML
    void startMatch(ActionEvent event) {
        this.startMatchButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (startMatchIdCombo.getValue() != null) {
                        matchTable.startMatch(startMatchIdCombo.getValue());
                        joinMatchModelGameTbleView.setItems(findAllJoinMatchModelGame());

                        List<Integer> devicesForMatch = deviceTable.findAllDeviceByModelAndGame(
                                matchTable.findByPrimaryKey(startMatchIdCombo.getValue()).get().getIdModel(),
                                matchTable.findByPrimaryKey(startMatchIdCombo.getValue()).get().getIdGame());
                        int numDevice = 0;
                        for (Integer idClient : claTable.findAllSignedClients(startMatchIdCombo.getValue())) {
                            if (accessTable.isClientAlreadyPlaying(idClient)) {
                                int deviceOccupedByThisClient = accessTable.getDeviceId(idClient);
                                accessTable.updateIdClient(idClient);// se il partecipante è connesso lo disconnetto
                                deviceTable.updateOccupation(deviceOccupedByThisClient, "Empty");
                                int accessTimeInSeconds = accessTable.getAccessTime(deviceOccupedByThisClient,
                                        idClient);
                                int leaveTimeInSeconds = accessTable.getLeaveTime(deviceOccupedByThisClient, idClient);
                                int newTime = leaveTimeInSeconds > accessTimeInSeconds
                                        ? leaveTimeInSeconds - accessTimeInSeconds
                                        : leaveTimeInSeconds + 86400 - accessTimeInSeconds;
                                clientTable.updateTime(idClient, newTime);
                            }
                            if (accessTable.isDeviceAlreadyOccuped(devicesForMatch.get(numDevice))) {
                                accessTable.updateIdDevice(devicesForMatch.get(numDevice));
                                deviceTable.updateOccupation(devicesForMatch.get(numDevice), "Empty");

                            }
                            accessTable.save(new Access(devicesForMatch.get(numDevice), idClient,
                                    java.sql.Date.valueOf(LocalDate.now()), LocalTime.now().withNano(0).toString(),
                                    null, null));
                            deviceTable.updateOccupation(devicesForMatch.get(numDevice), "Occuped");
                            numDevice++;
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Select a match id to start!");
                        nullLabels.showAndWait();
                    }
                }
                cleanLabels();
                refresh();
            }
        });
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        // TODO Auto-generated method stub
        initializePrizeTable();
        initializeClientTable();
        refresh();
    }
}
