package staffScene;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

import connection.ConnectionProvider;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import models.Client;
import tables.ClientTable;
import connection.Utils;

public class StaffRegistrationTabController implements Initializable {
    final static String username = "root";
    final static String password = "";
    final static String dbName = "databasegigi";

    final ConnectionProvider connectionProvider = new ConnectionProvider(username, password, dbName);
    final ClientTable clientTable = new ClientTable(connectionProvider.getMySQLConnection());

    @FXML
    private TableView<Client> ClientTable;
    @FXML
    private TableColumn<Client, Integer> clientIdColumn;

    @FXML
    private TableColumn<Client, Integer> clientPhoneColumn;

    @FXML
    private TableColumn<Client, Integer> clientTimeColumn;

    @FXML
    private TableColumn<Client, Integer> clientPointsColumn;

    @FXML
    private TableColumn<Client, String> clientAddressColumn;

    @FXML
    private TableColumn<Client, String> clientEmailColumn;

    @FXML
    private TableColumn<Client, String> clientLastNameColumn;

    @FXML
    private TableColumn<Client, String> clientNameColumn;

    @FXML
    private TableColumn<Client, String> clientCityColumn;

    @FXML
    private TableColumn<Client, String> clientPostalCodeColumn;

    @FXML
    private Button removeClientButton;

    @FXML
    private PasswordField pinLabel;

    @FXML
    private TextField addressLabel;

    @FXML
    private TextField emailLabel;

    @FXML
    private TextField nameLabel;

    @FXML
    private TextField phoneLabel;

    @FXML
    private TextField lastNameLabel;

    @FXML
    private TextField CityLabel;

    @FXML
    private TextField clientIdCanelLabel;

    @FXML
    private Button insertNewClientButton;

    @FXML
    private DatePicker birthdaylLabel;

    @FXML
    private ComboBox<String> genderComboBox;

    @FXML
    private TextField postalcodeLabel;

    private void cleanLabels() {
        nameLabel.setText("");
        CityLabel.setText("");
        lastNameLabel.setText("");
        phoneLabel.setText("");
        emailLabel.setText("");
        pinLabel.setText("");
        postalcodeLabel.setText("");
        addressLabel.setText("");
        birthdaylLabel.setValue(null);
        genderComboBox.setValue(null);
    }

    private boolean notNullLabels() {
        return nameLabel.getText().isEmpty() || CityLabel.getText().isEmpty() || lastNameLabel.getText().isEmpty()
                || phoneLabel.getText().isEmpty() || emailLabel.getText().isEmpty() || pinLabel.getText().isEmpty()
                || postalcodeLabel.getText().isEmpty() || addressLabel.getText().isEmpty()
                || birthdaylLabel.getValue() == null || genderComboBox.getValue() == null;
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        // TODO Auto-generated method stub
        initializeTable();

    }

    private void initializeTable() {
        clientIdColumn.setCellValueFactory(new PropertyValueFactory<>("idClient"));
        clientLastNameColumn.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        clientNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        clientEmailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
        clientPhoneColumn.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
        clientAddressColumn.setCellValueFactory(new PropertyValueFactory<>("address"));
        clientTimeColumn.setCellValueFactory(new PropertyValueFactory<>("time"));
        clientPostalCodeColumn.setCellValueFactory(new PropertyValueFactory<>("postalCode"));
        clientCityColumn.setCellValueFactory(new PropertyValueFactory<>("city"));
        clientPointsColumn.setCellValueFactory(new PropertyValueFactory<>("giftPoints"));
        ObservableList<Client> list = clientTable.findAll();
        ClientTable.setItems(list);
        setComboBox();
    }

    public void refresh() {
        ObservableList<Client> list = clientTable.findAll();
        ClientTable.setItems(list);
    }

    private void setComboBox() {
        this.genderComboBox.getItems().add("Male");
        this.genderComboBox.getItems().add("Female");
    }

    @FXML
    void addNewClient(ActionEvent event) {

        this.insertNewClientButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");

                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!notNullLabels()) {
                        Client newClient = new Client(0, nameLabel.getText(), lastNameLabel.getText(),
                                genderComboBox.getValue(), java.sql.Date.valueOf(birthdaylLabel.getValue()),
                                phoneLabel.getText(), emailLabel.getText(), pinLabel.getText(), CityLabel.getText(),
                                addressLabel.getText(), postalcodeLabel.getText(), "00:00:00", 0);
                        if (clientTable.save(newClient)) {
                            cleanLabels();
                        }
                    } else {

                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }
        });
    }

    @FXML
    void removeClient(ActionEvent event) {
        this.removeClientButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Confirmation");
                alert.setContentText("Select okay to proceed or cancel this action.");

                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!clientIdCanelLabel.getText().isEmpty() && Utils.isNumeric(clientIdCanelLabel.getText())) {
                        if (clientTable.delete(Integer.valueOf(clientIdCanelLabel.getText()))) {
                            clientIdCanelLabel.setText("");
                        } else {
                            Alert clientNotExist = new Alert(AlertType.INFORMATION);
                            clientNotExist.setContentText("Client not exist");
                            clientNotExist.showAndWait();
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Empty label or not numeric");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }
        });
    }
}
