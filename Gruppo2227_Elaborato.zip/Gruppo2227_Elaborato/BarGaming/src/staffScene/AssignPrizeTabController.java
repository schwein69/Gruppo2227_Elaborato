package staffScene;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

import connection.ConnectionProvider;
import connection.Utils;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import models.Client;
import models.Collection;
import models.Prize;
import tables.ClientTable;
import tables.CollectionTable;
import tables.OrderDetailTable;
import tables.OrderTable;
import tables.PrizeTable;

public class AssignPrizeTabController implements Initializable {
    final static String username = "root";
    final static String password = "";
    final static String dbName = "databasegigi";

    final ConnectionProvider connectionProvider = new ConnectionProvider(username, password, dbName);
    final ClientTable clientTable = new ClientTable(connectionProvider.getMySQLConnection());
    final PrizeTable prizeTable = new PrizeTable(connectionProvider.getMySQLConnection());
    final OrderDetailTable orderDetailTable = new OrderDetailTable(connectionProvider.getMySQLConnection());
    final OrderTable orderTable = new OrderTable(connectionProvider.getMySQLConnection());
    final CollectionTable collTable = new CollectionTable(connectionProvider.getMySQLConnection());

    public void initData(int id) {
        IdDipLabel.setText(String.valueOf(id));
    }

    @FXML
    private TableColumn<Client, Integer> clientIdColumn;

    @FXML
    private TableView<Prize> prizeTableView;

    @FXML
    private Label IdDipLabel;

    @FXML
    private TextField findLastName;

    @FXML
    private TextField quantity;

    @FXML
    private ComboBox<Integer> clientId;

    @FXML
    private TextField findName;

    @FXML
    private TableColumn<Prize, Integer> prizeIdColumn;

    @FXML
    private Button addButton;

    @FXML
    private TableColumn<Client, String> lastnameColumn;

    @FXML
    private ComboBox<Integer> prizeId;

    @FXML
    private TableColumn<Prize, Integer> prizeQuantityColumn;

    @FXML
    private TableColumn<Client, String> timeColumn;

    @FXML
    private TableColumn<Client, String> nameColumn;

    @FXML
    private TableColumn<Client, Integer> pointsColumn;

    @FXML
    private Button findClient;

    @FXML
    private TableColumn<Prize, String> prizeNameColumn;

    @FXML
    private TableColumn<Prize, Integer> prizePointsColumn;

    @FXML
    private TableView<Client> clientTableView;

    @FXML
    private TableColumn<Collection, Integer> collectIdPrizedColumn;

    @FXML
    private ComboBox<Integer> findCollectCombo;

    @FXML
    private TableView<Collection> collectTableView;

    @FXML
    private TableColumn<Collection, Integer> collectidClientdColumn;

    @FXML
    private Button findCollectOfClientButton;

    @FXML
    private TableColumn<Collection, Integer> collectQuantitydColumn;

    @FXML
    private Button showAllCollectButton;

    @FXML
    private TableColumn<Collection, Integer> idCollectdColumn;

    @FXML
    void findCollectOfClient(ActionEvent event) {
        this.findCollectOfClientButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (findCollectCombo.getValue() != null) {
                        collectTableView.setItems(collTable.findByClient(findCollectCombo.getValue()));
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Empty labels!");
                        nullLabels.showAndWait();
                    }

                }
            }
        });
    }

    @FXML
    void showAllCollect(ActionEvent event) {
        this.showAllCollectButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    collectTableView.setItems(collTable.findAll());
                }
            }
        });
    }

    @FXML
    void findClient(ActionEvent event) {
        this.findClient.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!findLastName.getText().isEmpty() && !findName.getText().isEmpty()) {
                        clientTableView.setItems(
                                clientTable.findByNameAndLastName(findName.getText(), findLastName.getText()));
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Empty label");
                        nullLabels.showAndWait();
                    }
                }
                cleanLabels();
            }
        });
    }

    @FXML
    void addPrizeToClient(ActionEvent event) {
        this.addButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) { // TODO Auto-generated
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (prizeId.getValue() != null && clientId.getValue() != null && !quantity.getText().isEmpty()) {
                        if (Utils.isNumeric(quantity.getText())) {
                            if (prizeTable.findByPrimaryKey(prizeId.getValue()).get().getPrizeQuantity() != 0) {
                                if (Integer.valueOf(quantity.getText()) > 0) {
                                    if (Integer.valueOf(quantity.getText()) <= prizeTable
                                            .findByPrimaryKey(prizeId.getValue()).get().getPrizeQuantity()) {
                                        int pointToConsume = prizeTable.findByPrimaryKey(prizeId.getValue()).get()
                                                .getPrizePoints() * Integer.valueOf(quantity.getText());
                                        if (clientTable.enoughtPoints(clientId.getValue(), pointToConsume)) {
                                            clientTable.updatePoints(clientId.getValue(), pointToConsume);
                                            prizeTable
                                                    .updatePrize(prizeId.getValue(), "", null,
                                                            prizeTable.findByPrimaryKey(prizeId.getValue()).get()
                                                                    .getPrizeQuantity()
                                                                    - Integer.valueOf(quantity.getText()));
                                            collTable.save(new Collection(0, clientId.getValue(), prizeId.getValue(),
                                                    Integer.valueOf(quantity.getText()), pointToConsume));
                                            cleanLabels();
                                        } else {
                                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                                            nullLabels.setContentText("Client's points not sufficient!");
                                            nullLabels.showAndWait();
                                            quantity.setText("");
                                        }
                                    } else {
                                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                                        nullLabels.setContentText("Too many quantity requested!");
                                        nullLabels.showAndWait();
                                        quantity.setText("");
                                    }
                                } else {
                                    Alert nullLabels = new Alert(AlertType.INFORMATION);
                                    nullLabels.setContentText("Quantity should be greater than 0!");
                                    nullLabels.showAndWait();
                                    quantity.setText("");
                                }

                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("Prize finished!");
                                nullLabels.showAndWait();
                                cleanLabels();
                            }

                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("Quantity label should be numeric!");
                            nullLabels.showAndWait();
                            quantity.setText("");
                        }

                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill labels!");
                        nullLabels.showAndWait();
                        quantity.setText("");

                    }
                    refresh();
                }
            }
        });
    }

    private void cleanLabels() {
        prizeId.setValue(null);
        clientId.setValue(null);
        findCollectCombo.setValue(null);
        quantity.setText("");
        findName.setText("");
        findLastName.setText("");
    }

    public void refresh() {
        prizeId.setItems(prizeTable.findAll().stream().map(e -> e.getIdPrize())
                .collect(Collectors.toCollection(FXCollections::observableArrayList)));
        clientId.setItems(clientTable.findAll().stream().map(e -> e.getIdClient())
                .collect(Collectors.toCollection(FXCollections::observableArrayList)));
        findCollectCombo.setItems(clientTable.findAll().stream().map(e -> e.getIdClient())
                .collect(Collectors.toCollection(FXCollections::observableArrayList)));
        ObservableList<Prize> list1 = prizeTable.findAll();
        prizeTableView.setItems(list1);
        ObservableList<Client> list2 = clientTable.findAll();
        clientTableView.setItems(list2);
        ObservableList<Collection> list3 = collTable.findAll();
        collectTableView.setItems(list3);
    }

    private void initializePrizeTable() {
        prizeIdColumn.setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getIdPrize()).asObject());
        prizeNameColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getPrizeName()));
        prizePointsColumn.setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getPrizePoints()).asObject());
        prizeQuantityColumn
                .setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getPrizeQuantity()).asObject());
    }

    private void initializeCollectionTable() {
        idCollectdColumn.setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getIdPrize()).asObject());
        collectidClientdColumn
                .setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getIdClient()).asObject());
        collectIdPrizedColumn.setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getIdPrize()).asObject());
        collectQuantitydColumn
                .setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getQuantity()).asObject());
    }

    private void initializeClientTable() {
        clientIdColumn.setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getIdClient()).asObject());
        lastnameColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getLastName()));
        nameColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getName()));
        timeColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getTime()));
        pointsColumn.setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getGiftPoints()).asObject());
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        // TODO Auto-generated method stub
        initializePrizeTable();
        initializeClientTable();
        initializeCollectionTable();
        refresh();
    }
}
