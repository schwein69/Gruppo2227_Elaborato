package staffScene;

import java.net.URL;
import java.sql.Connection;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

import connection.ConnectionProvider;
import connection.Utils;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import models.Client;
import models.PriceList;
import models.Recharge;
import models.RechargeDetail;
import tables.ClientTable;
import tables.PriceListTable;
import tables.RechargeDetailTable;
import tables.RechargeTable;

public class RechargeTabController implements Initializable {
    private String textToShow = "";
    private List<RechargeDetail> listDetailRecharge = new ArrayList<RechargeDetail>();
    private List<Integer> listIdPriceList = new ArrayList<Integer>();
    final static String username = "root";
    final static String password = "";
    final static String dbName = "databasegigi";

    final ConnectionProvider connectionProvider = new ConnectionProvider(username, password, dbName);
    final ClientTable clientTable = new ClientTable(connectionProvider.getMySQLConnection());
    final PriceListTable priceListTable = new PriceListTable(connectionProvider.getMySQLConnection());
    final RechargeDetailTable rechargeDetailTable = new RechargeDetailTable(connectionProvider.getMySQLConnection());
    final RechargeTable rechargeTable = new RechargeTable(connectionProvider.getMySQLConnection());
    final Connection con = connectionProvider.getMySQLConnection();

    public void initData(int id) {
        employeeIdLabel.setText(String.valueOf(id));
    }

    @FXML
    private TableColumn<Client, Integer> clientIdColumn;

    @FXML
    private TableColumn<PriceList, Integer> idPriceListColumn;

    @FXML
    private Button addToListButton;

    @FXML
    private TextArea totalPriceLabel;

    @FXML
    private TableColumn<RechargeDetail, Integer> rechargeDetailPriceListColumn;

    @FXML
    private ComboBox<Integer> findDetailRechargeCombo;

    @FXML
    private TableColumn<Recharge, Double> rechargeTotalPriceColumn;

    @FXML
    private TableView<RechargeDetail> rechargeDetailTableView;

    @FXML
    private TableColumn<RechargeDetail, Double> rechargeDetailTotalPriceColumn;

    @FXML
    private ComboBox<Integer> findRechargeOfClientCombo;

    @FXML
    private Button clearButton;

    @FXML
    private TableView<PriceList> priceListTableView;

    @FXML
    private TextArea totalHoursLabel;

    @FXML
    private TableColumn<PriceList, Integer> hoursColumn;

    @FXML
    private ComboBox<Integer> rechargeCliendIdCombo;

    @FXML
    private TableColumn<Recharge, Integer> rechargeIdColumn;

    @FXML
    private ComboBox<Integer> addToListCombo;

    @FXML
    private Button findDetailRechargeButton;

    @FXML
    private Button findRechargeButton;

    @FXML
    private TableColumn<Client, String> clientLastNameColumn;

    @FXML
    private TableColumn<RechargeDetail, Double> rechargeDetailUnitPriceColumn;

    @FXML
    private TableColumn<PriceList, Double> priceColumn;

    @FXML
    private TableColumn<RechargeDetail, Integer> rechargeDetailQuantityColumn;

    @FXML
    private TextField findLastName;

    @FXML
    private TableColumn<Recharge, String> rechargeDateColumn;

    @FXML
    private TableColumn<Recharge, Integer> rechargeTotalHoursColumn;

    @FXML
    private TextField findName;

    @FXML
    private TableColumn<Recharge, Integer> rechargeClientColumn;

    @FXML
    private Label employeeIdLabel;

    @FXML
    private Button rechargeButton;

    @FXML
    private TableColumn<Client, String> clientNameColumn;

    @FXML
    private TextField quantityLabel;

    @FXML
    private Button showAllButton;

    @FXML
    private TableColumn<Client, String> clientTimeColumn;

    @FXML
    private TableColumn<Client, Integer> clientPointsColumn;

    @FXML
    private Button findClientButton;

    @FXML
    private TableColumn<Client, String> clientEmailColumn;

    @FXML
    private TableView<Recharge> rechargeTableView;

    @FXML
    private TableView<Client> clientTableView;

    @FXML
    private TextArea textArea;

    private void cleanLabels() {
        textArea.setText("");
        quantityLabel.setText("");
        totalPriceLabel.setText("");
        totalHoursLabel.setText("");
        findName.setText("");
        findLastName.setText("");
        rechargeCliendIdCombo.setValue(null);
        addToListCombo.setValue(null);
        findRechargeOfClientCombo.setValue(null);
        findDetailRechargeCombo.setValue(null);
    }

    public void refresh() {
        rechargeCliendIdCombo.setItems(clientTable.findAll().stream().map(e -> e.getIdClient())
                .collect(Collectors.toCollection(FXCollections::observableArrayList)));
        addToListCombo.setItems(priceListTable.findAll().stream().map(e -> e.getIdList())
                .collect(Collectors.toCollection(FXCollections::observableArrayList)));
        findRechargeOfClientCombo.setItems(clientTable.findAll().stream().map(e -> e.getIdClient())
                .collect(Collectors.toCollection(FXCollections::observableArrayList)));
        findDetailRechargeCombo.setItems(rechargeTable.findAll().stream().map(e -> e.getIdRecharge())
                .collect(Collectors.toCollection(FXCollections::observableArrayList)));
        ObservableList<PriceList> list1 = priceListTable.findAll();
        priceListTableView.setItems(list1);
        ObservableList<Recharge> list2 = rechargeTable.findAll();
        rechargeTableView.setItems(list2);
        ObservableList<Client> list3 = clientTable.findAll();
        clientTableView.setItems(list3);
    }

    private void initializePriceListTable() {
        idPriceListColumn.setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getIdList()).asObject());
        hoursColumn.setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getTime()).asObject());
        priceColumn.setCellValueFactory(e -> new SimpleDoubleProperty(e.getValue().getPrice()).asObject());

    }

    private void initializeClientTable() {
        clientIdColumn.setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getIdClient()).asObject());
        clientLastNameColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getLastName()));
        clientNameColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getName()));
        clientEmailColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getEmail()));
        clientTimeColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getTime()));
        clientPointsColumn.setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getGiftPoints()).asObject());
    }

    private void initializeRechargeTable() {
        rechargeIdColumn.setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getIdRecharge()).asObject());
        rechargeClientColumn.setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getIdClient()).asObject());
        rechargeDateColumn.setCellValueFactory(e -> {
            SimpleStringProperty property = new SimpleStringProperty();
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            property.setValue(dateFormat.format(e.getValue().getRechargeDay()));
            return property;
        });
        rechargeTotalPriceColumn
                .setCellValueFactory(e -> new SimpleDoubleProperty(e.getValue().getRechargeTotalPrice()).asObject());
        rechargeTotalHoursColumn
                .setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getTotalHours()).asObject());

    }

    private void initializeRechargeDetailTable() {
        rechargeDetailPriceListColumn
                .setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getIdPriceList()).asObject());
        rechargeDetailQuantityColumn
                .setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getQuantity()).asObject());
        rechargeDetailUnitPriceColumn
                .setCellValueFactory(e -> new SimpleDoubleProperty(e.getValue().getUnityPrice()).asObject());
        rechargeDetailTotalPriceColumn
                .setCellValueFactory(e -> new SimpleDoubleProperty(e.getValue().getTotalPrice()).asObject());

    }

    @FXML
    void recharge(ActionEvent event) {
        this.rechargeButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                int numRecharge = rechargeTable.findAll().stream()
                        .max(Comparator.comparing(models.Recharge::getIdRecharge)).get().getIdRecharge() + 1;
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!listIdPriceList.isEmpty()) {
                        if (rechargeCliendIdCombo.getValue() != null) {
                            rechargeTable.save(new Recharge(numRecharge, rechargeCliendIdCombo.getValue(),
                                    Integer.valueOf(employeeIdLabel.getText()), java.sql.Date.valueOf(LocalDate.now()),
                                    Double.valueOf(totalPriceLabel.getText()),
                                    Integer.valueOf(totalHoursLabel.getText())));
                            clientTable.recharge(rechargeCliendIdCombo.getValue(),
                                    3600 * Integer.valueOf(totalHoursLabel.getText()));

                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Empty list");
                        nullLabels.showAndWait();
                    }
                    for (RechargeDetail r : listDetailRecharge) {
                        rechargeDetailTable.save(r);
                    }
                    cleanLabels();
                    listDetailRecharge.clear();
                    listIdPriceList.clear();
                    textToShow = "";
                    refresh();
                }
            }
        });
    }

    @FXML
    void findClient(ActionEvent event) {
        this.findClientButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!findLastName.getText().isEmpty() && !findName.getText().isEmpty()) {
                        clientTableView.setItems(
                                clientTable.findByNameAndLastName(findName.getText(), findLastName.getText()));
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Empty label");
                        nullLabels.showAndWait();
                    }
                }
                cleanLabels();
            }
        });
    }

    @FXML
    void addToList(ActionEvent event) {
        this.addToListButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) { // TODO Auto-generated
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (addToListCombo.getValue() != null && !quantityLabel.getText().isEmpty()) {
                        if (Utils.isNumeric(quantityLabel.getText())) {
                            if (Integer.valueOf(quantityLabel.getText()) > 0) {
                                if (!listIdPriceList.contains(addToListCombo.getValue())) {
                                    PriceList newPrice = priceListTable.findByPrimaryKey(addToListCombo.getValue())
                                            .get();
                                    int numRecharge = rechargeTable.findAll().stream()
                                            .max(Comparator.comparing(models.Recharge::getIdRecharge)).get()
                                            .getIdRecharge() + 1;

                                    int prodQuantity = Integer.valueOf(quantityLabel.getText());
                                    RechargeDetail newDetail = new RechargeDetail(numRecharge, newPrice.getIdList(),
                                            prodQuantity, newPrice.getPrice(), newPrice.getPrice() * prodQuantity);

                                    listIdPriceList.add(addToListCombo.getValue());
                                    listDetailRecharge.add(newDetail);
                                    textToShow = textToShow.concat(newDetail.toString() + "\n");
                                    textArea.setText(textToShow);
                                    Double totalPri = listDetailRecharge.stream().mapToDouble(e -> e.getTotalPrice())
                                            .sum();
                                    int totalHours = listDetailRecharge.stream().mapToInt(
                                            e -> priceListTable.findByPrimaryKey(e.getIdPriceList()).get().getTime()
                                                    * e.getQuantity())
                                            .sum();
                                    totalPriceLabel.setText(totalPri.toString());
                                    totalHoursLabel.setText(String.valueOf(totalHours));
                                } else {
                                    Alert nullLabels = new Alert(AlertType.INFORMATION);
                                    nullLabels.setContentText("Already have pricelist in the shopping list!");
                                    nullLabels.showAndWait();
                                }
                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("Quantity must be greater than one!");
                                nullLabels.showAndWait();
                            }
                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("Quantity label should be numeric!");
                            nullLabels.showAndWait();
                        }

                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }
        });

    }

    @FXML
    void clearTextArea(ActionEvent event) {
        this.clearButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    cleanLabels();
                    listDetailRecharge.clear();
                    listIdPriceList.clear();
                    textToShow = "";
                    refresh();
                }
            }
        });
    }

    @FXML
    void showAllClient(ActionEvent event) {
        this.clientTableView.setItems(clientTable.findAll());
    }

    @FXML
    void findRechargeOfClient(ActionEvent event) {
        this.findRechargeButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (findRechargeOfClientCombo.getValue() != null) {
                        rechargeTableView.setItems(rechargeTable.findByClient(findRechargeOfClientCombo.getValue()));
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Empty labels!");
                        nullLabels.showAndWait();
                    }

                }
            }
        });
    }

    @FXML
    void findDetailRecharge(ActionEvent event) {
        this.findDetailRechargeButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (findDetailRechargeCombo.getValue() != null) {
                        rechargeDetailTableView
                                .setItems(rechargeDetailTable.findByRechargeId(findDetailRechargeCombo.getValue()));
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Empty labels!");
                        nullLabels.showAndWait();
                    }

                }
            }
        });
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        initializePriceListTable();
        initializeClientTable();
        initializeRechargeTable();
        initializeRechargeDetailTable();
        refresh();
    }

}
