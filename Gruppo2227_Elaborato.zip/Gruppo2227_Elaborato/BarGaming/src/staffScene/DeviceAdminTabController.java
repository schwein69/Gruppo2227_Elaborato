package staffScene;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.stream.Collectors;
import connection.ConnectionProvider;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import models.Association;
import models.Device;
import models.Game;
import models.Model;
import tables.AssociationTable;
import tables.DeviceTable;
import tables.GameTable;

class JoinDeviceModel {
    private Device device;
    private Model model;

    public JoinDeviceModel(Device device, Model model) {
        this.device = device;
        this.model = model;

    }

    public Device getDevice() {
        return device;
    }

    public Model getModel() {
        return model;
    }

}

public class DeviceAdminTabController implements Initializable {
    final static String username = "root";
    final static String password = "";
    final static String dbName = "databasegigi";

    final ConnectionProvider connectionProvider = new ConnectionProvider(username, password, dbName);
    final GameTable gameTable = new GameTable(connectionProvider.getMySQLConnection());
    final AssociationTable assocTable = new AssociationTable(connectionProvider.getMySQLConnection());
    final DeviceTable deviceTable = new DeviceTable(connectionProvider.getMySQLConnection());
    final Connection con = connectionProvider.getMySQLConnection();
    @FXML
    private TableColumn<JoinDeviceModel, String> joinNameColumn;

    @FXML
    private TableColumn<Association, Integer> assocDeviceIdColumn;

    @FXML
    private TableView<JoinDeviceModel> joinTableView;

    @FXML
    private Button findButton;

    @FXML
    private TableColumn<JoinDeviceModel, Integer> joinIdDeviceColumn;

    @FXML
    private TableColumn<JoinDeviceModel, String> joinOccupedColumn;

    @FXML
    private TableView<Game> gameTableView;

    @FXML
    private TableColumn<Game, Integer> gameIdColumn;

    @FXML
    private TableColumn<JoinDeviceModel, String> joinStateColumn;

    @FXML
    private ComboBox<Integer> findGameWithId;

    @FXML
    private TableView<Association> assocTableView;

    @FXML
    private ComboBox<Integer> idDeviceUpdate;

    @FXML
    private TableColumn<Game, String> gameNameColumn;

    @FXML
    private TableColumn<JoinDeviceModel, Integer> joinModelIdColumn;

    @FXML
    private TableColumn<JoinDeviceModel, String> joinModelNameColumn;

    @FXML
    private TextField deviceStateupdate;

    @FXML
    private Button updateButton;

    @FXML
    private TableColumn<Association, Integer> assocGameIdColumn;

    @FXML
    private TableColumn<JoinDeviceModel, Integer> joinIdRoomColumn;

    private ObservableList<JoinDeviceModel> readJoinFromResultSet(final ResultSet resultSet) {
        ObservableList<JoinDeviceModel> listJoin = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {
                JoinDeviceModel newObject = new JoinDeviceModel(
                        new Device(resultSet.getInt("idDevice"), resultSet.getInt("idSala"),
                                resultSet.getInt("idModello"), resultSet.getString("NomeDevice"),
                                resultSet.getString("StatoDevice"), resultSet.getString("OccupatoDevice"),
                                resultSet.getInt("MemoriaDevice")),
                        new Model(resultSet.getInt("idModello"), resultSet.getString("NomeModello"),
                                resultSet.getInt("MemoriaDisponibile")));
                listJoin.add(newObject);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listJoin;
    }

    private ObservableList<JoinDeviceModel> findAllWithJoinInDeviceTable() {
        try (final Statement statement = this.con.createStatement()) {
            final ResultSet rs = statement.executeQuery("SELECT *  FROM device dev"
                    + " JOIN modello ON dev.idModello = modello.idModello " + " ORDER BY dev.IdDevice");
            return readJoinFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    private void cleanLabels() {
        deviceStateupdate.setText("");
        idDeviceUpdate.setValue(null);
        findGameWithId.setValue(null);
    }

    public void refresh() {
        idDeviceUpdate.setItems(deviceTable.findAll().stream().map(e -> e.getIdDevice())
                .collect(Collectors.toCollection(FXCollections::observableArrayList)));
        findGameWithId.setItems(deviceTable.findAll().stream().map(e -> e.getIdDevice())
                .collect(Collectors.toCollection(FXCollections::observableArrayList)));
        ObservableList<Association> list1 = assocTable.findAll();
        assocTableView.setItems(list1);
        ObservableList<Game> list2 = gameTable.findAll();
        gameTableView.setItems(list2);
        ObservableList<JoinDeviceModel> list3 = this.findAllWithJoinInDeviceTable();
        joinTableView.setItems(list3);
    }

    private void initializeProductTable() {
        joinIdRoomColumn
                .setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getDevice().getIdRoom()).asObject());
        joinIdDeviceColumn
                .setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getDevice().getIdDevice()).asObject());
        joinNameColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getDevice().getDeviceName()));
        joinStateColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getDevice().getStateDevice()));
        joinOccupedColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getDevice().getOccuped()));
        joinModelIdColumn
                .setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getModel().getIdModel()).asObject());
        joinModelNameColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getModel().getModelName()));
    }

    private void initializeGameTable() {
        gameIdColumn.setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getIdGame()).asObject());
        gameNameColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getGameName()));
    }

    private void initializeAssocTable() {
        assocDeviceIdColumn.setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getIdDevice()).asObject());
        assocGameIdColumn.setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getIdGame()).asObject());
    }

    @FXML
    void updateState(ActionEvent event) {
        this.updateButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) { // TODO Auto-generated
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (idDeviceUpdate.getValue() != null && !deviceStateupdate.getText().isEmpty()) {
                        if (deviceTable.findByPrimaryKey(idDeviceUpdate.getValue()).get().getStateDevice()
                                .equals("Working")
                                && deviceTable.findByPrimaryKey(idDeviceUpdate.getValue()).get().getOccuped()
                                        .equals("Empty")) {
                            deviceTable.updateState(idDeviceUpdate.getValue(), deviceStateupdate.getText());
                            cleanLabels();
                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText(
                                    "Device is already broke or is occuped so the state can't be updated");
                            nullLabels.showAndWait();
                        }

                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill labels");
                        nullLabels.showAndWait();
                    }
                    refresh();
                }
            }
        });

    }

    @FXML
    void findGameInDevice(ActionEvent event) {
        this.findButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) { // TODO Auto-generated
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (findGameWithId.getValue() != null) {
                        assocTableView.setItems(assocTable.findByDevice(findGameWithId.getValue()));
                        cleanLabels();
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill labels");
                        nullLabels.showAndWait();
                    }
                }
            }
        });
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        // TODO Auto-generated method stub
        initializeProductTable();
        initializeGameTable();
        initializeAssocTable();
        refresh();
    }

}
