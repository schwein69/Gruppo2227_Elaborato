package loginScene;

import java.io.IOException;
import java.util.Optional;
import application.Main;
import barScene.BarSceneController;
import connection.ConnectionProvider;
import connection.Utils;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import staffScene.StaffController;
import javafx.scene.control.Alert.AlertType;
import tables.AccountTable;
import tables.ClientTable;
import tecnicoScene.TecnicoController;
import userScene.UserController;

public class LoginController {
    private final static String username = "root";
    private final static String password = "";
    private final static String dbName = "databasegigi";
    private final ConnectionProvider connectionProvider = new ConnectionProvider(username, password, dbName);
    private final ClientTable clientTable = new ClientTable(connectionProvider.getMySQLConnection());
    private final AccountTable accountTable = new AccountTable(connectionProvider.getMySQLConnection());

    @FXML
    private TextField UsernameDip;

    @FXML
    private Button LoginClient;

    @FXML
    private PasswordField PinClient;

    @FXML
    private PasswordField PasswordDip;

    @FXML
    private Button LoginDIp;

    @FXML
    private TextField IdClient;

    @FXML
    public void loginEmployee(ActionEvent event) throws IOException {
        Main m = new Main();
        this.LoginDIp.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!UsernameDip.getText().isEmpty() && !PasswordDip.getText().isEmpty()) {
                        if (accountTable.loginCheck(UsernameDip.getText(), PasswordDip.getText())) {
                            String role = accountTable.checkRole(UsernameDip.getText(), PasswordDip.getText());
                            if (role.equals("Dipendente") || role.equals("dipendente")) {
                                String rol = accountTable.getEmployeeRole(UsernameDip.getText(), PasswordDip.getText())
                                        .toLowerCase();
                                switch (rol) {
                                case "staff":
                                    FXMLLoader loader = new FXMLLoader(
                                            getClass().getResource("/staffScene/StaffScene.fxml"));

                                    StaffController staffController = new StaffController(
                                            (accountTable.getEmployeeId(UsernameDip.getText(), PasswordDip.getText())));
                                    loader.setController(staffController);
                                    Stage stage = new Stage(StageStyle.DECORATED);
                                    try {
                                        stage.setScene(new Scene(loader.load()));
                                        stage.setResizable(false);
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                    stage.show();
                                    try {
                                        m.closeScene();
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                    break;

                                case "barista":
                                    loader = new FXMLLoader(getClass().getResource("/barScene/BarScene.fxml"));

                                    BarSceneController barController = new BarSceneController(
                                            (accountTable.getEmployeeId(UsernameDip.getText(), PasswordDip.getText())));
                                    loader.setController(barController);
                                    stage = new Stage(StageStyle.DECORATED);
                                    try {
                                        stage.setScene(new Scene(loader.load()));
                                        stage.setResizable(false);
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                    stage.show();
                                    try {
                                        m.closeScene();
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                    break;

                                case "tecnico":
                                    loader = new FXMLLoader(getClass().getResource("/tecnicoScene/TecnicoScene.fxml"));

                                    TecnicoController controller = new TecnicoController(
                                            (accountTable.getEmployeeId(UsernameDip.getText(), PasswordDip.getText())));
                                    loader.setController(controller);
                                    stage = new Stage(StageStyle.DECORATED);
                                    try {
                                        stage.setScene(new Scene(loader.load()));
                                        stage.setResizable(false);
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                    stage.show();
                                    try {
                                        m.closeScene();
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                    break;
                                }

                            } else if (role.equals("Admin") || role.equals("admin")) {
                                try {
                                    m.changeScene("/adminScene/AdminScene.fxml");
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("Credenziali errati");
                            nullLabels.showAndWait();

                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Empty labels");
                        nullLabels.showAndWait();
                    }
                }
            }

        });

    }

    @FXML
    public void loginClient(ActionEvent event) throws IOException {
        Main m = new Main();
        this.LoginClient.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!IdClient.getText().isEmpty() && !PinClient.getText().isEmpty()) {
                        if (Utils.isNumeric(IdClient.getText())) {
                            if (clientTable.loginCheck(Integer.valueOf(IdClient.getText()), PinClient.getText())) {
                                FXMLLoader loader = new FXMLLoader(getClass().getResource("/userScene/UserScene.fxml"));
                                UserController controller = new UserController((Integer.valueOf(IdClient.getText())));
                                loader.setController(controller);
                                Stage stage = new Stage(StageStyle.DECORATED);
                                try {
                                    stage.setScene(new Scene(loader.load()));
                                    stage.setResizable(false);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                                stage.show();
                                try {
                                    m.closeScene();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("Credenziali errati");
                                nullLabels.showAndWait();
                            }
                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("Id label should be numeric!");
                            nullLabels.showAndWait();
                        }

                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Empty labels");
                        nullLabels.showAndWait();
                    }
                }
            }

        });
    }
}
