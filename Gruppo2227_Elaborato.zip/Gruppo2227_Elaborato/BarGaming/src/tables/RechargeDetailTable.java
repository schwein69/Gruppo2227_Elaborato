package tables;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.Objects;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import models.RechargeDetail;

public class RechargeDetailTable {
    public static final String TABLE_NAME = "dettaglio_ricarica";
    private final Connection connection;

    public RechargeDetailTable(final Connection connection) {
        this.connection = Objects.requireNonNull(connection);
    }

    private ObservableList<RechargeDetail> readRechargeDetailFromResultSet(final ResultSet resultSet) {
        ObservableList<RechargeDetail> listOrder = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {
                RechargeDetail newOrder = new RechargeDetail(resultSet.getInt("IdRicarica"),
                        resultSet.getInt("IdListino"), resultSet.getInt("QuantitàRicarica"),
                        resultSet.getDouble("PrezzoUnitarioRicarica"), resultSet.getDouble("PrezzoTotaleRicarica"));
                listOrder.add(newOrder);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return listOrder;
    }

    public ObservableList<RechargeDetail> findByRechargeId(Integer primaryKey) {
        // TODO Auto-generated method stub
        final String query = "SELECT * FROM " + TABLE_NAME + " WHERE IdRicarica = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, primaryKey);
            final ResultSet rs = statement.executeQuery();
            return readRechargeDetailFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public ObservableList<RechargeDetail> findAll() {
        // TODO Auto-generated method stub
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet rs = statement.executeQuery("SELECT *  FROM " + TABLE_NAME);
            return readRechargeDetailFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean save(RechargeDetail value) {
        // TODO Auto-generated method stub
        final String query = "INSERT INTO " + TABLE_NAME
                + " (IdRicarica,IdListino,QuantitàRicarica,PrezzoUnitarioRicarica,PrezzoTotaleRicarica) "
                + " VALUES (?,?,?,?,?)";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, value.getIdRecharge());
            statement.setInt(2, value.getIdPriceList());
            statement.setInt(3, value.getQuantity());
            statement.setDouble(4, value.getUnityPrice());
            statement.setDouble(5, value.getTotalPrice());
            statement.executeUpdate();
            return true;
        } catch (final SQLIntegrityConstraintViolationException e) {
            return false;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }
}
