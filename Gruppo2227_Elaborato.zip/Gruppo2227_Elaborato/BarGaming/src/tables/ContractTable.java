package tables;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.Objects;
import java.util.Optional;
import connection.Utils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import models.Contract;

public class ContractTable {
    public static final String TABLE_NAME = "contratto";
    private final Connection connection;

    public ContractTable(final Connection connection) {
        this.connection = Objects.requireNonNull(connection);
    }

    private ObservableList<Contract> readEmployeeFromResultSet(final ResultSet resultSet) {
        ObservableList<Contract> listContract = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {
                Contract newContract = new Contract(resultSet.getInt("IdContratto"), resultSet.getString("Tipo"),
                        resultSet.getDouble("Stipendio"), Utils.sqlDateToDate(resultSet.getDate("DataInizio")),
                        Optional.ofNullable(Utils.sqlDateToDate(resultSet.getDate("DataFine"))));
                listContract.add(newContract);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listContract;
    }

    public Optional<Contract> findByPrimaryKey(int primaryKey) {
        final String query = "SELECT *  FROM " + TABLE_NAME + " where IdContratto  = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, primaryKey);
            final ResultSet rs = statement.executeQuery();
            return readEmployeeFromResultSet(rs).stream().findFirst();
        } catch (final SQLException e) {
            return Optional.empty();
        }
    }

    public ObservableList<Contract> findAll() {
        // TODO Auto-generated method stub
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet rs = statement.executeQuery("SELECT *  FROM " + TABLE_NAME);
            return readEmployeeFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean save(Contract newContract) {
        // TODO Auto-generated method stub
        final String query = "INSERT INTO " + TABLE_NAME + " (Tipo, Stipendio, DataInizio)" + "VALUES (?,?,?)";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setString(1, newContract.getType());
            statement.setDouble(2, newContract.getSalary());
            statement.setDate(3, Utils.dateToSqlDate(newContract.getStartDate()));
            statement.executeUpdate();
            return true;
        } catch (final SQLIntegrityConstraintViolationException e) {
            return false;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean update(int idContract) {
        // TODO Auto-generated method stub
        final String query = "UPDATE " + TABLE_NAME + " SET DataFine = ? " + " WHERE IdContratto = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setDate(1, Utils.dateToSqlDate(java.sql.Date.valueOf(LocalDate.now())));
            statement.setInt(2, idContract);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean isUsedCheckByClient(int idContract) {
        // TODO Auto-generated method stub
        final String query = "SELECT * FROM " + "dipendente" + " WHERE IdContratto = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, idContract);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                return true;
            }
        } catch (final SQLException e) {
            e.getStackTrace();
        }
        return false;
    }

    public boolean isCompletedContract(int idContract) {
        // TODO Auto-generated method stub
        final String query = "SELECT * FROM " + TABLE_NAME + " WHERE IdContratto = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, idContract);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                Optional<String> dataFine = Optional.ofNullable(rs.getString("DataFine"));
                return dataFine.isPresent();
            }
        } catch (final SQLException e) {
            e.getStackTrace();
        }
        return false;
    }

    public boolean updateContract(int salary, String newType, int idContract) {
        // TODO Auto-generated method stub
        final String query = "UPDATE " + TABLE_NAME + " SET " + " Stipendio = ?, Tipo = ? WHERE IdContratto  = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, salary);
            statement.setString(2, newType);
            statement.setInt(3, idContract);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean delete(Integer primaryKey) {
        // TODO Auto-generated method stub
        final String query = "DELETE FROM " + TABLE_NAME + " WHERE IdContratto = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, primaryKey);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }
}
