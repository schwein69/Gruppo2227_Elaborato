package tables;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.Objects;
import java.util.Optional;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import models.Category;

public class CategoryTable {
    public static final String TABLE_NAME = "categoria";
    private final Connection connection;

    public CategoryTable(final Connection connection) {
        this.connection = Objects.requireNonNull(connection);
    }

    public boolean save(Category newCategory) {
        // TODO Auto-generated method stub
        final String query = "INSERT INTO " + TABLE_NAME + " (NomeCategoria) " + " VALUES (?)";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setString(1, newCategory.getNameCategory());
            statement.executeUpdate();
            return true;
        } catch (final SQLIntegrityConstraintViolationException e) {
            return false;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    private ObservableList<Category> readCategoryFromResultSet(final ResultSet resultSet) {
        ObservableList<Category> listCat = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {
                Category newCat = new Category(resultSet.getInt("IdCategoria"), resultSet.getString("NomeCategoria"));
                listCat.add(newCat);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return listCat;
    }

    public Optional<Category> findByName(String name) {
        // TODO Auto-generated method stub
        final String query = "SELECT * FROM " + TABLE_NAME + " WHERE NomeCategoria = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setString(1, name);
            final ResultSet rs = statement.executeQuery();
            return readCategoryFromResultSet(rs).stream().findFirst();
        } catch (final SQLException e) {
            return Optional.empty();
        }
    }

    public ObservableList<Category> findAll() {
        // TODO Auto-generated method stub
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet rs = statement.executeQuery("SELECT *  FROM " + TABLE_NAME);
            return readCategoryFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean update(int categoryId, String newName) {
        // TODO Auto-generated method stub
        final String query = "UPDATE " + TABLE_NAME + " SET NomeCategoria = ?  WHERE IdCategoria = ? ";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setString(1, newName);
            statement.setInt(2, categoryId);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }


}
