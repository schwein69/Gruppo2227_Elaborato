package tables;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.Objects;
import java.util.Optional;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import models.OrderDetail;

public class OrderDetailTable {
    public static final String TABLE_NAME = "dettaglio_acquisto";
    private final Connection connection;

    public OrderDetailTable(final Connection connection) {
        this.connection = Objects.requireNonNull(connection);
    }

    private ObservableList<OrderDetail> readOrderDetailFromResultSet(final ResultSet resultSet) {
        ObservableList<OrderDetail> listOrder = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {
                OrderDetail newOrder = new OrderDetail(resultSet.getInt("IdProdotto"), resultSet.getInt("IdOrdine"),
                        resultSet.getInt("QuantitàAcquisto"), resultSet.getDouble("PrezzoUnitario"),
                        resultSet.getDouble("PrezzoTotale"), resultSet.getInt("PuntiPremioRegaloPerProdotto"),
                        Optional.ofNullable(resultSet.getInt("Sconto")));
                listOrder.add(newOrder);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return listOrder;
    }

    public ObservableList<OrderDetail> findByOrder(Integer primaryKey) {
        // TODO Auto-generated method stub
        final String query = "SELECT * FROM " + TABLE_NAME + " WHERE IdOrdine = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, primaryKey);
            final ResultSet rs = statement.executeQuery();
            return readOrderDetailFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public ObservableList<OrderDetail> findAll() {
        // TODO Auto-generated method stub
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet rs = statement.executeQuery("SELECT *  FROM " + TABLE_NAME);
            return readOrderDetailFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean save(OrderDetail value) {
        // TODO Auto-generated method stub
        final String query = "INSERT INTO " + TABLE_NAME
                + " (IdProdotto,IdOrdine,QuantitàAcquisto,PrezzoUnitario,PrezzoTotale,PuntiPremioRegaloPerProdotto,Sconto) "
                + " VALUES (?,?,?,?,?,?,?)";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, value.getIdProduct());
            statement.setInt(2, value.getIdOrdine());
            statement.setInt(3, value.getQuantity());
            statement.setDouble(4, value.getUnityPrice());
            statement.setDouble(5, value.getTotalPrice());
            statement.setInt(6, value.getGiftPointsPerProduct());
            statement.setObject(7, value.getDiscount().isPresent() ? value.getDiscount().get() : null);
            statement.executeUpdate();
            return true;
        } catch (final SQLIntegrityConstraintViolationException e) {
            return false;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

}
