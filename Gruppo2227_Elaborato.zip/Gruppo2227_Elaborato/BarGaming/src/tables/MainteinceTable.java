package tables;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.Objects;
import java.util.Optional;
import connection.Utils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import models.Maintenance;

public class MainteinceTable {
    public static final String TABLE_NAME = "manutenzione";
    private final Connection connection;

    public MainteinceTable(final Connection connection) {
        this.connection = Objects.requireNonNull(connection);
    }

    private ObservableList<Maintenance> readMainteinceFromResultSet(final ResultSet resultSet) {
        ObservableList<Maintenance> listMainteince = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {
                Maintenance newMain = new Maintenance(resultSet.getInt("IdManutenzione"), resultSet.getInt("IdDevice"),
                        resultSet.getInt("IdDipendente"), resultSet.getString("DescrizioneManutenzione"),
                        resultSet.getDouble("CostoManutenzione"),
                        Utils.sqlDateToDate(resultSet.getDate("DataManutenzione")));
                listMainteince.add(newMain);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listMainteince;
    }

    public Optional<Maintenance> findByPrimaryKey(Integer primaryKey) {
        // TODO Auto-generated method stub
        final String query = "SELECT * FROM " + TABLE_NAME + " where IdManutenzione = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, primaryKey);
            final ResultSet rs = statement.executeQuery();
            return readMainteinceFromResultSet(rs).stream().findFirst();
        } catch (final SQLException e) {
            return Optional.empty();
        }
    }

    public ObservableList<Maintenance> findAll() {
        // TODO Auto-generated method stub
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet rs = statement
                    .executeQuery("SELECT *  FROM " + TABLE_NAME + " ORDER BY IdManutenzione DESC ");
            return readMainteinceFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public ObservableList<Integer> findAllDistinctEmployee() {
        // TODO Auto-generated method stub
        ObservableList<Integer> listId = FXCollections.observableArrayList();
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet resultSet = statement.executeQuery(
                    "SELECT DISTINCT IdDipendente  FROM " + TABLE_NAME + " ORDER BY IdManutenzione DESC ");
            while (resultSet.next()) {
                int newId = resultSet.getInt("IdDipendente");
                listId.add(newId);
            }
            return listId;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public ObservableList<Maintenance> findAllOfEmployee(int idEmployee) {
        // TODO Auto-generated method stub
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet rs = statement.executeQuery("SELECT *  FROM " + TABLE_NAME + " WHERE IdDipendente = "
                    + idEmployee + " ORDER BY IdManutenzione DESC");
            return readMainteinceFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean save(Maintenance value) {
        // TODO Auto-generated method stub
        final String query = "INSERT INTO " + TABLE_NAME
                + " (IdDevice,IdDipendente,DescrizioneManutenzione,CostoManutenzione,DataManutenzione) "
                + " VALUES (?,?,?,?,?)";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, value.getIdDevice());
            statement.setInt(2, value.getIdEmployee());
            statement.setString(3, value.getDescription());
            statement.setDouble(4, value.getCost());
            statement.setDate(5, Utils.dateToSqlDate(value.getDate()));
            statement.executeUpdate();
            return true;
        } catch (final SQLIntegrityConstraintViolationException e) {
            return false;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }
}
