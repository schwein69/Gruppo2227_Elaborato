package tables;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Objects;
import connection.Utils;
import models.Access;

public class AccessTable {
    public static final String TABLE_NAME = "accesso";
    private final Connection connection;

    public AccessTable(final Connection connection) {
        this.connection = Objects.requireNonNull(connection);
    }

    public boolean save(Access newAccess) {
        // TODO Auto-generated method stub
        final String query = "INSERT INTO " + TABLE_NAME + " (IdDevice,IdCliente,DataAccesso,OraAccesso) "
                + " VALUES (?,?,?,?)";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, newAccess.getIdDevice());
            statement.setInt(2, newAccess.getIdClient());
            statement.setDate(3, Utils.dateToSqlDate(newAccess.getAccessDate()));
            statement.setString(4, (newAccess.getAccessTime()));
            statement.executeUpdate();
            return true;
        } catch (final SQLIntegrityConstraintViolationException e) {
            return false;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public int getDeviceId(int idClient) {
        // TODO Auto-generated method stub
        final String query = "SELECT * FROM " + TABLE_NAME
                + " WHERE IdCliente = ? AND DataFine IS NULL AND OraFineAccesso IS NULL";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, idClient);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                return rs.getInt("IdDevice");
            }
        } catch (final SQLException e) {
            e.getStackTrace();
        }
        return 0;
    }

    public int getClientId(int idDevice) {
        // TODO Auto-generated method stub
        final String query = "SELECT * FROM " + TABLE_NAME
                + " WHERE IdDevice  = ? AND DataFine IS NULL AND OraFineAccesso IS NULL";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, idDevice);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                return rs.getInt("IdCliente");
            }
        } catch (final SQLException e) {
            e.getStackTrace();
        }
        return 0;
    }

    public boolean updateMatchDevice(int IdDevice) {
        // TODO Auto-generated method stub
        final String query = "UPDATE " + TABLE_NAME + " SET DataFine = ? , OraFineAccesso = ? "
                + " WHERE IdDevice = ? AND DataFine IS NULL AND OraFineAccesso IS NULL";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setDate(1, Utils.dateToSqlDate(java.sql.Date.valueOf(LocalDate.now())));
            statement.setString(2, LocalTime.now().withNano(0).toString());
            statement.setInt(3, IdDevice);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean updateIdClient(int idClient) {
        // TODO Auto-generated method stub
        final String query = "UPDATE " + TABLE_NAME + " SET DataFine = ? , OraFineAccesso = ? "
                + " WHERE IdCliente = ? AND DataFine IS NULL AND OraFineAccesso IS NULL";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setDate(1, Utils.dateToSqlDate(java.sql.Date.valueOf(LocalDate.now())));
            statement.setString(2, LocalTime.now().withNano(0).toString());
            statement.setInt(3, idClient);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean updateIdDevice(int idDevice) {
        // TODO Auto-generated method stub
        final String query = "UPDATE " + TABLE_NAME + " SET DataFine = ? , OraFineAccesso = ? "
                + " WHERE IdDevice = ? AND DataFine IS NULL AND OraFineAccesso IS NULL";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setDate(1, Utils.dateToSqlDate(java.sql.Date.valueOf(LocalDate.now())));
            statement.setString(2, LocalTime.now().withNano(0).toString());
            statement.setInt(3, idDevice);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean isClientAlreadyPlaying(int idClient) {
        // TODO Auto-generated method stub
        final String query = "SELECT *  FROM " + TABLE_NAME + " WHERE IdCliente = ? AND DataFine is NULL";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, idClient);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                return true;
            }
        } catch (final SQLException e) {
            return false;
        }
        return false;
    }

    public boolean isThisDeviceOccupedByThisClient(int idDevice, int idClient) {
        // TODO Auto-generated method stub
        final String query = "SELECT *  FROM " + TABLE_NAME
                + " WHERE IdDevice = ?  AND IdCliente = ? AND DataFine is NULL";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, idDevice);
            statement.setInt(2, idClient);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                return true;
            }
        } catch (final SQLException e) {
            return false;
        }
        return false;
    }

    public boolean isDeviceAlreadyOccuped(int idDevice) {
        // TODO Auto-generated method stub
        final String query = "SELECT *  FROM " + TABLE_NAME + " WHERE IdDevice = ? AND DataFine is NULL";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, idDevice);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                return true;
            }
        } catch (final SQLException e) {
            return false;
        }
        return false;
    }

    public boolean update(int IdDevice, int IdCliente) {
        // TODO Auto-generated method stub
        final String query = "UPDATE " + TABLE_NAME + " SET DataFine = ? , OraFineAccesso = ? "
                + " WHERE IdDevice = ? AND IdCliente = ? AND DataFine IS NULL AND OraFineAccesso IS NULL";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setDate(1, Utils.dateToSqlDate(java.sql.Date.valueOf(LocalDate.now())));
            statement.setString(2, LocalTime.now().withNano(0).toString());
            statement.setInt(3, IdDevice);
            statement.setInt(4, IdCliente);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public int getAccessTime(int IdDevice, int IdClient) {
        // TODO Auto-generated method stub
        int timeInSeconds = 0;
        final String query = "SELECT OraAccesso FROM " + TABLE_NAME
                + " WHERE IdCliente = ? AND IdDevice = ? ORDER BY DataAccesso DESC";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, IdClient);
            statement.setInt(2, IdDevice);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                String time = rs.getString("OraAccesso");
                String[] sections = time.split(":");
                int totalSeconds = (Integer.parseInt(sections[0]) * 60 * 60) + (Integer.parseInt(sections[1]) * 60)
                        + (Integer.parseInt(sections[2]));
                timeInSeconds = totalSeconds;
            }
        } catch (final SQLException e) {
            return 0;
        }
        return timeInSeconds;
    }

    public int getLeaveTime(int IdDevice, int IdClient) {
        // TODO Auto-generated method stub
        int timeInSeconds = 0;
        final String query = "SELECT OraFineAccesso FROM " + TABLE_NAME
                + " WHERE IdCliente = ? AND IdDevice = ? ORDER BY DataAccesso DESC";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, IdClient);
            statement.setInt(2, IdDevice);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                String time = rs.getString("OraFineAccesso");
                String[] sections = time.split(":");
                int totalSeconds = (Integer.parseInt(sections[0]) * 60 * 60) + (Integer.parseInt(sections[1]) * 60)
                        + (Integer.parseInt(sections[2]));
                timeInSeconds = totalSeconds;
            }
        } catch (final SQLException e) {
            return 0;
        }
        return timeInSeconds;
    }

}
