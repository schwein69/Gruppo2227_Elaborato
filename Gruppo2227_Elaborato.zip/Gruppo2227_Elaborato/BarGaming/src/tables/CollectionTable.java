package tables;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.Objects;
import java.util.Optional;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import models.Collection;

public class CollectionTable {
    public static final String TABLE_NAME = "riscossione";
    private final Connection connection;

    public CollectionTable(final Connection connection) {
        this.connection = Objects.requireNonNull(connection);
    }

    private ObservableList<Collection> readCollectionFromResultSet(final ResultSet resultSet) {
        ObservableList<Collection> listMainteince = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {
                Collection newCollection = new Collection(resultSet.getInt("IdRiscossione"),
                        resultSet.getInt("IdCliente"), resultSet.getInt("IdPremio"),
                        resultSet.getInt("QuantitàRiscossione"), resultSet.getInt("CostoPremio"));
                listMainteince.add(newCollection);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listMainteince;
    }

    public Optional<Collection> findByPrimaryKey(Integer primaryKey) {
        final String query = "SELECT * FROM " + TABLE_NAME + " where IdRiscossione = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, primaryKey);
            final ResultSet rs = statement.executeQuery();
            return readCollectionFromResultSet(rs).stream().findFirst();
        } catch (final SQLException e) {
            return Optional.empty();
        }
    }

    public ObservableList<Collection> findByClient(Integer primaryKey) {
        final String query = "SELECT * FROM " + TABLE_NAME + " WHERE IdCliente = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, primaryKey);
            final ResultSet rs = statement.executeQuery();
            return readCollectionFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public ObservableList<Collection> findAll() {
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet rs = statement.executeQuery("SELECT *  FROM " + TABLE_NAME);
            return readCollectionFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean save(Collection value) {
        // TODO Auto-generated method stub
        final String query = "INSERT INTO " + TABLE_NAME + " (IdCliente,IdPremio,QuantitàRiscossione,CostoPremio) "
                + " VALUES (?,?,?,?)";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, value.getIdClient());
            statement.setInt(2, value.getIdPrize());
            statement.setInt(3, value.getQuantity());
            statement.setInt(4, value.getGiftPointsNecessaryForPrize());
            statement.executeUpdate();
            return true;
        } catch (final SQLIntegrityConstraintViolationException e) {
            return false;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }
}
