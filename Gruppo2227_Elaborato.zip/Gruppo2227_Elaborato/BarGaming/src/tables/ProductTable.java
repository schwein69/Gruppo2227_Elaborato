package tables;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.Objects;
import java.util.Optional;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import models.Product;

public class ProductTable {
    public static final String TABLE_NAME = "prodotto";

    private final Connection connection;

    public ProductTable(final Connection connection) {
        this.connection = Objects.requireNonNull(connection);
    }

    public ObservableList<Product> readProductFromResultSet(final ResultSet resultSet) {
        ObservableList<Product> listJoin = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {
                Product newObject = new Product(resultSet.getInt("IdProdotto"), resultSet.getString("NomeProdotto"),
                        resultSet.getDouble("PrezzoProdotto"), resultSet.getInt("PuntiPremioRegalo"));
                listJoin.add(newObject);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listJoin;
    }

    public Optional<Product> findByPrimaryKey(Integer primaryKey) {
        // TODO Auto-generated method stub
        final String query = "SELECT * FROM " + TABLE_NAME + " where IdProdotto = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, primaryKey);
            final ResultSet rs = statement.executeQuery();
            return readProductFromResultSet(rs).stream().findFirst();
        } catch (final SQLException e) {
            return Optional.empty();
        }
    }

    public ObservableList<Product> findAll() {
        // TODO Auto-generated method stub
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet rs = statement.executeQuery("SELECT * FROM " + TABLE_NAME);
            return readProductFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean save(Product value) {
        // TODO Auto-generated method stub
        final String query = "INSERT INTO " + TABLE_NAME + " (NomeProdotto,PrezzoProdotto,PuntiPremioRegalo) "
                + " VALUES (?,?,?)";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setString(1, value.getProductName());
            statement.setDouble(2, value.getProductPrice());
            statement.setInt(3, value.getProductGiftPo());
            statement.executeUpdate();
            return true;
        } catch (final SQLIntegrityConstraintViolationException e) {
            return false;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean update(Integer id, String name, Double price, Integer points) {
        // TODO Auto-generated method stub
        final String query = "Select * FROM " + TABLE_NAME + " WHERE IdProdotto = " + id;
        try (final Statement stmt = this.connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                ResultSet.CONCUR_UPDATABLE)) {
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                if (!name.isEmpty()) {
                    rs.updateString("NomeProdotto", name);
                }
                if (price != null && price > 0.0) {
                    rs.updateDouble("PrezzoProdotto", price);
                }
                if (points != null && points > 0) {
                    rs.updateInt("PuntiPremioRegalo", points);
                }
                rs.updateRow();
                return true;
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return false;
    }

    public boolean delete(Integer primaryKey) {
        // TODO Auto-generated method stub
        final String query = "DELETE FROM " + TABLE_NAME + " WHERE IdProdotto   = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, primaryKey);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }
}
