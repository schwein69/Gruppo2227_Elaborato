package tables;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.Objects;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import models.Account;

public class AccountTable {
    public static final String TABLE_NAME = "account";
    private final Connection connection;

    public AccountTable(final Connection connection) {
        this.connection = Objects.requireNonNull(connection);
    }

    private ObservableList<Account> readAccountFromResultSet(final ResultSet resultSet) {
        ObservableList<Account> listAccount = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {
                Account newAccount = new Account(resultSet.getInt("IdAccount"), resultSet.getString("Username"),
                        resultSet.getString("Password"), resultSet.getString("RuoloAccount"));
                listAccount.add(newAccount);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return listAccount;
    }

    public boolean isUsedCheck(int idAccount) {
        // TODO Auto-generated method stub
        final String query = "SELECT * FROM " + "dipendente" + " WHERE idAccount = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, idAccount);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                return true;
            }
        } catch (final SQLException e) {
            e.getStackTrace();
        }
        return false;
    }

    public String getEmployeeRole(String userName, String password) {
        final String query = "SELECT * FROM account A, dipendente D WHERE A.IdAccount = D.idAccount AND Username = ? AND Password = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setString(1, userName);
            statement.setString(2, password);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                return rs.getString("Ruolo");
            }
        } catch (final SQLException e) {
            e.getStackTrace();
        }
        return "";
    }

    public int getEmployeeId(String userName, String password) {
        // TODO Auto-generated method stub
        final String query = "SELECT * FROM account A, dipendente D WHERE A.IdAccount = D.idAccount AND Username = ? AND Password = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setString(1, userName);
            statement.setString(2, password);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                return rs.getInt("IdDipendente");
            }
        } catch (final SQLException e) {
            e.getStackTrace();
        }
        return 0;
    }

    public boolean loginCheck(String userName, String password) {
        // TODO Auto-generated method stub
        final String query = "SELECT * FROM " + TABLE_NAME + " WHERE Username = ? AND Password = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setString(1, userName);
            statement.setString(2, password);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                return true;
            }
        } catch (final SQLException e) {
            e.getStackTrace();
        }
        return false;
    }

    public String checkRole(String userName, String password) {
        // TODO Auto-generated method stub
        final String query = "SELECT RuoloAccount FROM " + TABLE_NAME + " WHERE Username = ? AND Password = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setString(1, userName);
            statement.setString(2, password);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                String ruolo = rs.getString("RuoloAccount");
                return ruolo;
            }
        } catch (final SQLException e) {
            e.getStackTrace();
        }
        return "";
    }

    public ObservableList<Account> findAll() {
        // TODO Auto-generated method stub
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet rs = statement.executeQuery(
                    "SELECT * FROM " + TABLE_NAME + " WHERE RuoloAccount != 'admin' AND  RuoloAccount != 'Admin' ");
            return readAccountFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean save(Account value) {
        // TODO Auto-generated method stub
        final String query = "INSERT INTO " + TABLE_NAME + " (Username,Password,RuoloAccount) " + " VALUES (?,?,?)";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setString(1, value.getUserName());
            statement.setString(2, value.getPassWord());
            statement.setString(3, value.getRole());
            statement.executeUpdate();
            return true;
        } catch (final SQLIntegrityConstraintViolationException e) {
            return false;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean isUsernameExist(String userName) {
        // TODO Auto-generated method stub
        final String query = "SELECT * FROM " + TABLE_NAME + " WHERE Username = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setString(1, userName);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                return true;
            }
        } catch (final SQLException e) {
            e.getStackTrace();
        }
        return false;
    }

    public boolean isIdAccountExist(int idAccount) {
        // TODO Auto-generated method stub
        final String query = "SELECT * FROM " + TABLE_NAME + " WHERE IdAccount  = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, idAccount);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                return true;
            }
        } catch (final SQLException e) {
            e.getStackTrace();
        }
        return false;
    }

    public boolean updateAccount(int idAccount, String newPassword) {
        // TODO Auto-generated method stub
        final String query = "UPDATE " + TABLE_NAME + " SET " + " Password = ? WHERE IdAccount  = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setString(1, newPassword);
            statement.setInt(2, idAccount);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean delete(Integer primaryKey) {
        // TODO Auto-generated method stub
        final String query = "DELETE FROM " + TABLE_NAME + " WHERE IdAccount  = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, primaryKey);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

}
