package tables;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.Objects;
import java.util.Optional;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import models.Sponsor;

public class SponsorTable {
    public static final String TABLE_NAME = "sponsor";
    private final Connection connection;

    public SponsorTable(final Connection connection) {
        this.connection = Objects.requireNonNull(connection);
    }

    private ObservableList<Sponsor> readSponsFromResultSet(final ResultSet resultSet) {
        ObservableList<Sponsor> listSpons = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {
                Sponsor newSpon = new Sponsor(resultSet.getInt("IdSponsor"), resultSet.getString("NomeSponsor"),
                        resultSet.getString("ContattoSponsor"), resultSet.getString("EmailSponsor"));
                listSpons.add(newSpon);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return listSpons;
    }

    public Optional<Sponsor> findByPrimaryKey(Integer primaryKey1) {
        // TODO Auto-generated method stub
        final String query = "SELECT * FROM " + TABLE_NAME + " WHERE IdSponsor = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, primaryKey1);
            final ResultSet rs = statement.executeQuery();
            return readSponsFromResultSet(rs).stream().findFirst();
        } catch (final SQLException e) {
            return Optional.empty();
        }
    }

    public ObservableList<Sponsor> findAll() {
        // TODO Auto-generated method stub
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet rs = statement.executeQuery("SELECT *  FROM " + TABLE_NAME);
            return readSponsFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean save(Sponsor value) {
        // TODO Auto-generated method stub
        final String query = "INSERT INTO " + TABLE_NAME + " (NomeSponsor,ContattoSponsor,EmailSponsor) "
                + " VALUES (?,?,?)";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setString(1, value.getName());
            statement.setString(2, value.getPhoneNumber());
            statement.setString(3, value.getEmail());
            statement.executeUpdate();
            return true;
        } catch (final SQLIntegrityConstraintViolationException e) {
            return false;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean update(Integer id, String newName, String newEmail, String newContact) {
        // TODO Auto-generated method stub
        final String query = "Select * FROM " + TABLE_NAME + " WHERE IdSponsor = " + id;
        try (final Statement stmt = this.connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                ResultSet.CONCUR_UPDATABLE)) {
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                if (!newName.isEmpty()) {
                    rs.updateString("NomeSponsor", newName);
                }
                if (!newEmail.isEmpty()) {
                    rs.updateString("EmailSponsor", newEmail);
                }
                if (!newContact.isEmpty()) {
                    rs.updateString("ContattoSponsor", newContact);
                }
                rs.updateRow();
                return true;
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return false;
    }

    public boolean delete(Integer SponsorId) {
        final String query = "DELETE FROM " + TABLE_NAME + " WHERE IdSponsor = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, SponsorId);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }
}
