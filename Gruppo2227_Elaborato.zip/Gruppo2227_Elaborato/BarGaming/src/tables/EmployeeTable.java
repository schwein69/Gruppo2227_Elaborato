package tables;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.Objects;
import java.util.Optional;

import connection.Utils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import models.Client;
import models.Employee;

public class EmployeeTable {
    public static final String TABLE_NAME = "dipendente";
    private final Connection connection;

    public EmployeeTable(final Connection connection) {
        this.connection = Objects.requireNonNull(connection);
    }

    private ObservableList<Employee> readEmployeeFromResultSet(final ResultSet resultSet) {
        ObservableList<Employee> listEmployee = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {
                Employee newEmployee = new Employee(resultSet.getInt("IdDipendente"), resultSet.getInt("IdContratto"),
                        resultSet.getInt("idAccount"), resultSet.getString("NomeDipendente"),
                        resultSet.getString("CognomeDipendente"), resultSet.getString("GenereDipendente"),
                        Utils.sqlDateToDate(resultSet.getDate("DataDiNascitaDipendente")),
                        resultSet.getString("TelefonoDipendente"), resultSet.getString("EmailDipendente"),
                        resultSet.getString("Città"), resultSet.getString("Via"), resultSet.getString("CodicePostale"),
                        resultSet.getString("Ruolo"));        
                listEmployee.add(newEmployee);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return listEmployee;
    }

    public Optional<Employee> findByPrimaryKey(int primaryKey) {
        // TODO Auto-generated method stub
        final String query = "SELECT *  FROM " + TABLE_NAME + " where IdDipendente  = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, primaryKey);
            final ResultSet rs = statement.executeQuery();
            return readEmployeeFromResultSet(rs).stream().findFirst();
        } catch (final SQLException e) {
            return Optional.empty();
        }
    }

    public ObservableList<Employee> findByNameAndLastName(String name, String lastName) {
        // TODO Auto-generated method stub
        final String query = "SELECT *  FROM " + TABLE_NAME + " WHERE NomeDipendente = ? AND CognomeDipendente = ? ";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setString(1, name);
            statement.setString(2, lastName);
            final ResultSet rs = statement.executeQuery();
            return readEmployeeFromResultSet(rs);
        } catch (final SQLException e) {
            return null;
        }
    }

    public ObservableList<Employee> findAll() {
        // TODO Auto-generated method stub
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet rs = statement.executeQuery("SELECT *  FROM " + TABLE_NAME);
            return readEmployeeFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean save(Employee newEmployee) {
        // TODO Auto-generated method stub
        final String query = "INSERT INTO " + TABLE_NAME + " (NomeDipendente, CognomeDipendente, GenereDipendente,"
                + " DataDiNascitaDipendente, TelefonoDipendente, EmailDipendente, "
                + "Città, Via, CodicePostale, Ruolo,IdContratto,idAccount ) " + " VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setString(1, newEmployee.getName());
            statement.setString(2, newEmployee.getLastName());
            statement.setString(3, newEmployee.getGender());
            statement.setDate(4, Utils.dateToSqlDate(newEmployee.getBirthday()));
            statement.setString(5, newEmployee.getPhoneNumber());
            statement.setString(6, newEmployee.getEmail());
            statement.setString(7, newEmployee.getCity());
            statement.setString(8, newEmployee.getAddress());
            statement.setString(9, newEmployee.getPostalCode());
            statement.setString(10, newEmployee.getRole());
            statement.setInt(11, newEmployee.getIdContract());
            statement.setInt(12, newEmployee.getIdAccount());
            statement.executeUpdate();
            return true;
        } catch (final SQLIntegrityConstraintViolationException e) {
            return false;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public String getRole(int idEmployee) {
        // TODO Auto-generated method stub
        String ruolo = "";
        final String query = "SELECT Ruolo FROM " + TABLE_NAME + " WHERE IdDipendente  = ? ";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, idEmployee);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                ruolo = rs.getString("Ruolo");
            }
        } catch (final SQLException e) {
            return null;
        }
        return ruolo;
    }
    
    public int getAccountId(int idEmployee) {
        // TODO Auto-generated method stub
        int idAccount = 0;
        final String query = "SELECT idAccount FROM " + TABLE_NAME + " WHERE IdDipendente  = ? ";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, idEmployee);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                idAccount = rs.getInt("idAccount");
            }
        } catch (final SQLException e) {
            e.printStackTrace();
        }
        return idAccount;
    }
    public int getContractId(int idEmployee) {
        // TODO Auto-generated method stub
        int idContract = 0;
        final String query = "SELECT IdContratto  FROM " + TABLE_NAME + " WHERE IdDipendente = ? ";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, idEmployee);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                idContract = rs.getInt("IdContratto");
            }
        } catch (final SQLException e) {
            e.printStackTrace();
        }
        return idContract;
    }

    public boolean update(Client updatedValue) {
        // TODO Auto-generated method stub
        return false;
    }

    public boolean delete(Integer primaryKey) {
        // TODO Auto-generated method stub
        final String query = "DELETE FROM " + TABLE_NAME + " WHERE IdDipendente  = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, primaryKey);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

}
