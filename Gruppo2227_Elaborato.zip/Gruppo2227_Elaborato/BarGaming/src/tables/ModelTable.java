package tables;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.Objects;
import java.util.Optional;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import models.Model;

public class ModelTable {
    public static final String TABLE_NAME = "modello";
    private final Connection connection;

    public ModelTable(final Connection connection) {
        this.connection = Objects.requireNonNull(connection);
    }

    private ObservableList<Model> readStudentsFromResultSet(final ResultSet resultSet) {
        ObservableList<Model> listModel = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {
                Model newClient = new Model(resultSet.getInt("idModello"), resultSet.getString("NomeModello"),
                        resultSet.getInt("MemoriaDisponibile"));
                listModel.add(newClient);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listModel;
    }

    public ObservableList<Model> findByModelName(String modelName) {
        // TODO Auto-generated method stub
        final String query = "SELECT *  FROM " + TABLE_NAME + " WHERE NomeModello = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setString(1, modelName);
            final ResultSet rs = statement.executeQuery();
            return readStudentsFromResultSet(rs);
        } catch (final SQLException e) {
            return null;
        }
    }

    public Optional<Model> findByModelNameAndMemory(String modelName, int memory) {
        // TODO Auto-generated method stub
        final String query = "SELECT *  FROM " + TABLE_NAME + " WHERE NomeModello = ? AND MemoriaDisponibile = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setString(1, modelName);
            statement.setInt(2, memory);
            final ResultSet rs = statement.executeQuery();
            return readStudentsFromResultSet(rs).stream().findFirst();
        } catch (final SQLException e) {
            return null;
        }
    }

    public Optional<Model> findById(int idModel) {
        // TODO Auto-generated method stub
        final String query = "SELECT *  FROM " + TABLE_NAME + " WHERE IdModello  = ? ";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, idModel);
            final ResultSet rs = statement.executeQuery();
            return readStudentsFromResultSet(rs).stream().findFirst();
        } catch (final SQLException e) {
            return null;
        }
    }

    public ObservableList<Model> findAll() {
        // TODO Auto-generated method stub
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet rs = statement.executeQuery("SELECT *  FROM " + TABLE_NAME);
            return readStudentsFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean save(Model newModel) {
        // TODO Auto-generated method stub
        final String query = "INSERT INTO " + TABLE_NAME + " (NomeModello, MemoriaDisponibile) " + " VALUES (?,?)";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setString(1, newModel.getModelName());
            statement.setInt(2, newModel.getMemory());
            statement.executeUpdate();
            return true;
        } catch (final SQLIntegrityConstraintViolationException e) {
            return false;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean update(Model updatedValue) {
        // TODO Auto-generated method stub
        return false;
    }

    public boolean delete(int ModelId) {
        // TODO Auto-generated method stub
        final String query = "DELETE FROM " + TABLE_NAME + " WHERE idModello = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, ModelId);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

}
