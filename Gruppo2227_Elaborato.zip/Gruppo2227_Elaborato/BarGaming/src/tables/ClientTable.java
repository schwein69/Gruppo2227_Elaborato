package tables;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.Objects;
import java.util.Optional;

import models.Client;
import connection.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;


public class ClientTable {
    public static final String TABLE_NAME = "cliente";
    private final Connection connection;

    public ClientTable(final Connection connection) {
        this.connection = Objects.requireNonNull(connection);
    }

    private ObservableList<Client> readStudentsFromResultSet(final ResultSet resultSet) {
        ObservableList<Client> listClient = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {
                Client newClient = new Client(resultSet.getInt("idCliente"), resultSet.getString("NomeCliente"),
                        resultSet.getString("CognomeCliente"), resultSet.getString("GenereCliente"),
                        Utils.sqlDateToDate(resultSet.getDate("DataDiNascitaCliente")),
                        resultSet.getString("TelefonoCliente"), resultSet.getString("EmailCliente"),
                        resultSet.getString("PinCliente"), resultSet.getString("Città"), resultSet.getString("Via"),
                        resultSet.getString("CodicePostale"), resultSet.getString("Tempo"),
                        resultSet.getInt("PuntiPremio"));
                listClient.add(newClient);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return listClient;
    }

    public Optional<Client> findByPrimaryKey(int primaryKey) {
        // TODO Auto-generated method stub
        final String query = "SELECT *  FROM " + TABLE_NAME + " where IdCliente = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, primaryKey);
            final ResultSet rs = statement.executeQuery();
            return readStudentsFromResultSet(rs).stream().findFirst();
        } catch (final SQLException e) {
            return Optional.empty();
        }
    }

    public ObservableList<Client> findByNameAndLastName(String name, String lastName) {
        // TODO Auto-generated method stub
        final String query = "SELECT *  FROM " + TABLE_NAME + " WHERE NomeCliente = ? AND CognomeCliente = ? ";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setString(1, name);
            statement.setString(2, lastName);
            final ResultSet rs = statement.executeQuery();
            return readStudentsFromResultSet(rs);
        } catch (final SQLException e) {
            return null;
        }
    }

    public boolean enoughtTime(int idClient) {
        // TODO Auto-generated method stub
        final String query = "SELECT *  FROM " + TABLE_NAME + " WHERE IdCliente = ? ";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, idClient);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                String time = rs.getString("Tempo");
                String[] sections = time.split(":");
                int totalSeconds = (Integer.parseInt(sections[0]) * 60 * 60) + (Integer.parseInt(sections[1]) * 60)
                        + (Integer.parseInt(sections[2]));
                return totalSeconds > 0;
            }
        } catch (final SQLException e) {
            return false;
        }
        return false;
    }

    public boolean enoughtPoints(int idClient, int usedPoints) {
        // TODO Auto-generated method stub
        final String query = "SELECT *  FROM " + TABLE_NAME + " WHERE IdCliente = ? ";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, idClient);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                int points = rs.getInt("PuntiPremio");
                return points >= usedPoints;
            }
        } catch (final SQLException e) {
            return false;
        }
        return false;
    }

    public boolean updatePoints(int idClient, int usedPoints) {
        // TODO Auto-generated method stub
        int newPoints = this.findByPrimaryKey(idClient).get().getGiftPoints() - usedPoints;
        final String query = "UPDATE " + TABLE_NAME + " SET " + "PuntiPremio = ? WHERE IdCliente = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, newPoints);
            statement.setInt(2, idClient);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }
    
    public boolean updatePointsShop(int idClient, int usedPoints) {
        // TODO Auto-generated method stub
        int newPoints = this.findByPrimaryKey(idClient).get().getGiftPoints() + usedPoints;
        final String query = "UPDATE " + TABLE_NAME + " SET " + "PuntiPremio = ? WHERE IdCliente = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, newPoints);
            statement.setInt(2, idClient);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public ObservableList<Client> findAll() {
        // TODO Auto-generated method stub
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet rs = statement.executeQuery("SELECT *  FROM " + TABLE_NAME);
            return readStudentsFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean save(Client newClient) {
        // TODO Auto-generated method stub
        final String query = "INSERT INTO " + TABLE_NAME + " (NomeCliente, CognomeCliente, GenereCliente,"
                + " DataDiNascitaCliente, TelefonoCliente, EmailCliente, "
                + "PinCliente, Città, Via, CodicePostale, Tempo, PuntiPremio) " + " VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setString(1, newClient.getName());
            statement.setString(2, newClient.getLastName());
            statement.setString(3, newClient.getGender());
            statement.setDate(4, Utils.dateToSqlDate(newClient.getBirthday()));
            statement.setString(5, newClient.getPhoneNumber());
            statement.setString(6, newClient.getEmail());
            statement.setString(7, newClient.getPin());
            statement.setString(8, newClient.getCity());
            statement.setString(9, newClient.getAddress());
            statement.setString(10, newClient.getPostalCode());
            statement.setString(11, newClient.getTime());
            statement.setInt(12, newClient.getGiftPoints());
            statement.executeUpdate();
            return true;
        } catch (final SQLIntegrityConstraintViolationException e) {
            return false;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public int getTime(int idClient) {
        // TODO Auto-generated method stub
        int timeInSeconds = 0;
        final String query = "SELECT Tempo FROM " + TABLE_NAME + " WHERE IdCliente = ? ";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, idClient);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                String time = rs.getString("Tempo");
                String[] sections = time.split(":");
                int totalSeconds = (Integer.parseInt(sections[0]) * 60 * 60) + (Integer.parseInt(sections[1]) * 60)
                        + (Integer.parseInt(sections[2]));
                timeInSeconds = totalSeconds;
            }
        } catch (final SQLException e) {
            return 0;
        }
        return timeInSeconds;
    }

    public boolean updateTime(int idClient, int seconds) {
        // TODO Auto-generated method stub
        final String query = "UPDATE " + TABLE_NAME + " SET " + "Tempo = ? WHERE IdCliente = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setString(1, Utils.formatTime(getTime(idClient) - seconds));
            statement.setInt(2, idClient);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }
    
    public boolean recharge(int idClient, int seconds) {
        // TODO Auto-generated method stub
        final String query = "UPDATE " + TABLE_NAME + " SET " + "Tempo = ? WHERE IdCliente = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setString(1, Utils.formatTime(getTime(idClient) + seconds));
            statement.setInt(2, idClient);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean loginCheck(int idClient, String pin) {
        // TODO Auto-generated method stub
        final String query = "SELECT * FROM " + TABLE_NAME + " WHERE IdCliente  = ? AND PinCliente = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, idClient);
            statement.setString(2, pin);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                return true;
            }
        } catch (final SQLException e) {
            e.getStackTrace();
        }
        return false;
    }

    public boolean delete(Integer primaryKey) {
        // TODO Auto-generated method stub
        final String query = "DELETE FROM " + TABLE_NAME + " WHERE IdCliente = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, primaryKey);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

}
