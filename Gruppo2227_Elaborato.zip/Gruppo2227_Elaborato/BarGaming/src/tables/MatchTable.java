package tables;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.Date;
import java.util.Objects;
import java.util.Optional;

import connection.Utils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import models.Match;

public class MatchTable {
    public static final String TABLE_NAME = "gara";
    private final Connection connection;

    public MatchTable(final Connection connection) {
        this.connection = Objects.requireNonNull(connection);
    }

    private ObservableList<Match> readAdvsFromResultSet(final ResultSet resultSet) {
        ObservableList<Match> listMatch = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {
                Match newMatch = new Match(resultSet.getInt("IdGara"), resultSet.getInt("IdModello"),
                        resultSet.getInt("IdGioco"), resultSet.getString("NomeGara"),
                        Utils.sqlDateToDate(resultSet.getDate("DataGara")), resultSet.getInt("Capienza"),
                        resultSet.getInt("IscrittiAttuali"), resultSet.getString("StatoGara"),
                        resultSet.getDouble("QuotaIscrizione"));
                listMatch.add(newMatch);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return listMatch;
    }

    public boolean isFullMatch(int idMatch) {
        // TODO Auto-generated method stub
        final String query = "SELECT *  FROM " + TABLE_NAME + " WHERE IdGara = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, idMatch);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                return rs.getInt("IscrittiAttuali") < rs.getInt("Capienza");
            }
        } catch (final SQLException e) {
            e.getStackTrace();
        }
        return false;
    }

    public boolean isMatchOn(int idMatch) {
        // TODO Auto-generated method stub
        final String query = "SELECT *  FROM " + TABLE_NAME + " WHERE IdGara = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, idMatch);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                return rs.getString("StatoGara").equals("On");
            }
        } catch (final SQLException e) {
            e.getStackTrace();
        }
        return false;
    }

    public Optional<Match> findByPrimaryKey(Integer primaryKey1) {
        // TODO Auto-generated method stub
        final String query = "SELECT * FROM " + TABLE_NAME + " WHERE IdGara  = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, primaryKey1);
            final ResultSet rs = statement.executeQuery();
            return readAdvsFromResultSet(rs).stream().findFirst();
        } catch (final SQLException e) {
            return Optional.empty();
        }
    }

    public ObservableList<Match> findAll() {
        // TODO Auto-generated method stub
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet rs = statement.executeQuery("SELECT *  FROM " + TABLE_NAME);
            return readAdvsFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public ObservableList<Match> findAllStartedMatch() {
        // TODO Auto-generated method stub
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet rs = statement.executeQuery("SELECT *  FROM " + TABLE_NAME + " WHERE StatoGara = 'Start' ");
            return readAdvsFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }
    
    public ObservableList<Match> findAllNotStartedMatch() {
        // TODO Auto-generated method stub
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet rs = statement.executeQuery("SELECT *  FROM " + TABLE_NAME + " WHERE StatoGara = 'On' ");
            return readAdvsFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean save(Match value) {
        // TODO Auto-generated method stub
        final String query = "INSERT INTO " + TABLE_NAME
                + " (NomeGara,DataGara,Capienza,QuotaIscrizione,IscrittiAttuali,StatoGara,IdModello,IdGioco) "
                + " VALUES (?,?,?,?,?,?,?,?)";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setString(1, value.getMatchName());
            statement.setDate(2, Utils.dateToSqlDate(value.getMatchDate()));
            statement.setInt(3, value.getCapacity());
            statement.setDouble(4, value.getPrice());
            statement.setInt(5, value.getActualPerson());
            statement.setString(6, value.getState());
            statement.setInt(7, value.getIdModel());
            statement.setInt(8, value.getIdGame());
            statement.executeUpdate();
            return true;
        } catch (final SQLIntegrityConstraintViolationException e) {
            return false;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean updateMatch(Integer matchId, Integer modelId, Integer gameId, Double newQuote, String newName,
            Date newDate, Integer capacity) {
        // TODO Auto-generated method stub
        final String query = "Select * FROM " + TABLE_NAME + " WHERE IdGara = " + matchId;
        try (final Statement stmt = this.connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                ResultSet.CONCUR_UPDATABLE)) {
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                if (!newName.isEmpty()) {
                    rs.updateString("NomeGara", newName);
                }
                if (modelId != null) {
                    rs.updateInt("IdModello", modelId);
                }
                if (gameId != null) {
                    rs.updateInt("IdGioco", gameId);
                }
                if (newQuote != null && newQuote > 0.0) {
                    rs.updateDouble("QuotaIscrizione", newQuote);
                }
                if (capacity != null && capacity > 0) {
                    rs.updateInt("Capienza", capacity);
                }
                if (newDate != null) {
                    rs.updateDate("DataGara", Utils.dateToSqlDate(newDate));
                }
                rs.updateRow();
                return true;
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return false;
    }

    public boolean finishMatch(int idMatch) {
        // TODO Auto-generated method stub
        final String query = "UPDATE " + TABLE_NAME + " SET StatoGara = ? " + " WHERE IdGara  = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setString(1, "End");
            statement.setInt(2, idMatch);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }
    public boolean startMatch(int idMatch) {
        // TODO Auto-generated method stub
        final String query = "UPDATE " + TABLE_NAME + " SET StatoGara = ? " + " WHERE IdGara  = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setString(1, "Start");
            statement.setInt(2, idMatch);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean delete(Integer matchId) {
        final String query = "DELETE FROM " + TABLE_NAME + " WHERE IdGara  = ? ";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, matchId);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean updateInsert(int idMatch) {
        int newVal = this.findByPrimaryKey(idMatch).get().getActualPerson() + 1;
        final String query = "UPDATE " + TABLE_NAME + " SET " + " IscrittiAttuali = ? WHERE IdGara  = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, newVal);
            statement.setInt(2, idMatch);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean updateDelete(int idMatch) {
        int newVal = this.findByPrimaryKey(idMatch).get().getActualPerson() - 1;
        final String query = "UPDATE " + TABLE_NAME + " SET " + " IscrittiAttuali = ? WHERE IdGara  = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, newVal);
            statement.setInt(2, idMatch);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }
}
