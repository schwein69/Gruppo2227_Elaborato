package tables;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.Objects;
import java.util.Optional;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import models.Prize;

public class PrizeTable {
    public static final String TABLE_NAME = "premio";
    private final Connection connection;

    public PrizeTable(final Connection connection) {
        this.connection = Objects.requireNonNull(connection);
    }

    private ObservableList<Prize> readPrizeListsFromResultSet(final ResultSet resultSet) {
        ObservableList<Prize> listPrize = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {
                Prize newRoom = new Prize(resultSet.getInt("IdPremio"), resultSet.getString("NomePremio"),
                        resultSet.getInt("PuntiPremioNecessari"), resultSet.getInt("QuantitàPremioResidua"));
                listPrize.add(newRoom);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return listPrize;
    }

    public Optional<Prize> findByPrimaryKey(Integer primaryKey) {
        // TODO Auto-generated method stub
        final String query = "SELECT * FROM " + TABLE_NAME + " where IdPremio = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, primaryKey);
            final ResultSet rs = statement.executeQuery();
            return readPrizeListsFromResultSet(rs).stream().findFirst();
        } catch (final SQLException e) {
            return Optional.empty();
        }
    }

    public ObservableList<Prize> findAll() {
        // TODO Auto-generated method stub
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet rs = statement.executeQuery("SELECT *  FROM " + TABLE_NAME);
            return readPrizeListsFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean save(Prize value) {
        // TODO Auto-generated method stub
        final String query = "INSERT INTO " + TABLE_NAME + " (NomePremio,PuntiPremioNecessari,QuantitàPremioResidua) "
                + " VALUES (?,?,?)";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setString(1, value.getPrizeName());
            statement.setDouble(2, value.getPrizePoints());
            statement.setInt(3, value.getPrizeQuantity());
            statement.executeUpdate();
            return true;
        } catch (final SQLIntegrityConstraintViolationException e) {
            return false;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean updatePrize(Integer prizeId, String newName, Integer newPoints, Integer newQuantity) {
        final String query = "Select * FROM " + TABLE_NAME + " WHERE IdPremio  = " + prizeId;
        try (final Statement stmt = this.connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                ResultSet.CONCUR_UPDATABLE)) {
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                if (!newName.isEmpty()) {
                    rs.updateString("NomePremio", newName);
                }
                if (newPoints != null && newPoints >= 0) {
                    rs.updateInt("PuntiPremioNecessari", newPoints);
                }
                if (newQuantity != null && newQuantity >= 0) {
                    rs.updateInt("QuantitàPremioResidua", newQuantity);
                }
                rs.updateRow();
                return true;
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return false;
    }

    public boolean delete(Integer primaryKey) {
        final String query = "DELETE FROM " + TABLE_NAME + " WHERE IdPremio = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, primaryKey);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }
}
