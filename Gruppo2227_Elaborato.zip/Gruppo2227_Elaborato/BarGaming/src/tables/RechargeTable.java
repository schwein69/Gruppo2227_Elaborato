package tables;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.Objects;
import connection.Utils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import models.Recharge;

public class RechargeTable {
    public static final String TABLE_NAME = "ricarica";
    private final Connection connection;

    public RechargeTable(final Connection connection) {
        this.connection = Objects.requireNonNull(connection);
    }

    private ObservableList<Recharge> readRechargeListFromResultSet(final ResultSet resultSet) {
        ObservableList<Recharge> listRecharge = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {
                Recharge newRecharge = new Recharge(resultSet.getInt("IdRicarica"), resultSet.getInt("IdCliente"),
                        resultSet.getInt("IdDipendente"), Utils.sqlDateToDate(resultSet.getDate("DataRicarica")),
                        resultSet.getDouble("PrezzoTotaleRicarica"), resultSet.getInt("NumeroOreTotali"));
                listRecharge.add(newRecharge);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return listRecharge;
    }

    public ObservableList<Recharge> findByClient(Integer primaryKey) {
        // TODO Auto-generated method stub
        final String query = "SELECT * FROM " + TABLE_NAME + " WHERE IdCliente = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, primaryKey);
            final ResultSet rs = statement.executeQuery();
            return readRechargeListFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public ObservableList<Recharge> findAll() {
        // TODO Auto-generated method stub
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet rs = statement.executeQuery("SELECT *  FROM " + TABLE_NAME);
            return readRechargeListFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean save(Recharge value) {
        // TODO Auto-generated method stub
        final String query = "INSERT INTO " + TABLE_NAME
                + " (IdRicarica,DataRicarica,PrezzoTotaleRicarica,NumeroOreTotali,IdDipendente,IdCliente) "
                + " VALUES (?,?,?,?,?,?)";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, value.getIdRecharge());
            statement.setDate(2, Utils.dateToSqlDate(value.getRechargeDay()));
            statement.setDouble(3, value.getRechargeTotalPrice());
            statement.setDouble(4, value.getTotalHours());
            statement.setInt(5, value.getIdEmployee());
            statement.setInt(6, value.getIdClient());
            statement.executeUpdate();
            return true;
        } catch (final SQLIntegrityConstraintViolationException e) {
            return false;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

}
