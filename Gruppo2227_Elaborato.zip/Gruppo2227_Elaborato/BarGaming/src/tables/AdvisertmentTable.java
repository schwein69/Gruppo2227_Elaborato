package tables;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.Objects;
import java.util.Optional;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import models.Advisement;

public class AdvisertmentTable {
    public static final String TABLE_NAME = "pubblicizzazione";
    private final Connection connection;

    public AdvisertmentTable(final Connection connection) {
        this.connection = Objects.requireNonNull(connection);
    }

    private ObservableList<Advisement> readAdvsFromResultSet(final ResultSet resultSet) {
        ObservableList<Advisement> listAdv = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {
                Advisement newAdv = new Advisement(resultSet.getInt("idGara"), resultSet.getInt("idSponsor"),
                        resultSet.getDouble("QuotaSponsorizzazione"));
                listAdv.add(newAdv);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return listAdv;
    }

    public Optional<Advisement> findByPrimaryKey(Integer primaryKey1, Integer primaryKey2) {
        // TODO Auto-generated method stub
        final String query = "SELECT * FROM " + TABLE_NAME + " WHERE idGara  = ? AND idSponsor = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, primaryKey1);
            statement.setInt(2, primaryKey2);
            final ResultSet rs = statement.executeQuery();
            return readAdvsFromResultSet(rs).stream().findFirst();
        } catch (final SQLException e) {
            return Optional.empty();
        }
    }

    public ObservableList<Advisement> findAll() {
        // TODO Auto-generated method stub
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet rs = statement.executeQuery("SELECT *  FROM " + TABLE_NAME);
            return readAdvsFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean isSponsorAlreadyPresent(int idMatch, int idSponsor) {
        // TODO Auto-generated method stub
        final String query = "SELECT *  FROM " + TABLE_NAME + " WHERE idGara  = ? AND idSponsor = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, idMatch);
            statement.setInt(2, idSponsor);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                return true;
            }
        } catch (final SQLException e) {
            e.getStackTrace();
        }
        return false;
    }

    public boolean insert(Advisement value) {
        final String query = "INSERT INTO " + TABLE_NAME + " (idGara,idSponsor,QuotaSponsorizzazione)  VALUES (?,?,?)";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, value.getIdMatch());
            statement.setInt(2, value.getIdSponsor());
            statement.setDouble(3, value.getSponsorization());
            statement.executeUpdate();
            return true;
        } catch (final SQLIntegrityConstraintViolationException e) {
            return false;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean updatePrize(Integer matchId, Integer SponsorId, Double newQuote) {
        // TODO Auto-generated method stub
        final String query = "UPDATE " + TABLE_NAME + " SET "
                + "QuotaSponsorizzazione = ? WHERE idGara = ? AND idSponsor = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setDouble(1, newQuote);
            statement.setInt(2, matchId);
            statement.setInt(3, SponsorId);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean delete(Integer matchId, Integer SponsorId) {
        final String query = "DELETE FROM " + TABLE_NAME + " WHERE idGara = ? AND idSponsor = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, matchId);
            statement.setInt(2, SponsorId);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }
}
