package tables;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.Objects;
import java.util.Optional;

import connection.Utils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import models.Order;

public class OrderTable {
    public static final String TABLE_NAME = "ordine";
    private final Connection connection;

    public OrderTable(final Connection connection) {
        this.connection = Objects.requireNonNull(connection);
    }

    private ObservableList<Order> readOrderFromResultSet(final ResultSet resultSet) {
        ObservableList<Order> listOrder = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {
                Order newOrder = new Order(resultSet.getInt("IdOrdine"),
                        Optional.ofNullable(resultSet.getInt("IdCliente")), resultSet.getInt("IdDipendente"),
                        Utils.sqlDateToDate(resultSet.getDate("DataAcquisto")), resultSet.getDouble("PrezzoTotale"),
                        Optional.ofNullable(resultSet.getInt("PuntiPremioTotale")));
                listOrder.add(newOrder);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return listOrder;
    }

    public ObservableList<Order> findByClient(Integer primaryKey) {
        // TODO Auto-generated method stub
        final String query = "SELECT * FROM " + TABLE_NAME + " WHERE IdCliente = ? ORDER BY IdOrdine";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, primaryKey);
            final ResultSet rs = statement.executeQuery();
            return readOrderFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public ObservableList<Order> findAll() {
        // TODO Auto-generated method stub
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet rs = statement.executeQuery("SELECT *  FROM " + TABLE_NAME);
            return readOrderFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean save(Order value) {
        // TODO Auto-generated method stub
        final String query = "INSERT INTO " + TABLE_NAME
                + " (IdOrdine,DataAcquisto,PrezzoTotale,PuntiPremioTotale,IdDipendente,IdCliente) " + " VALUES (?,?,?,?,?,?)";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, value.getIdOrder());
            statement.setDate(2, Utils.dateToSqlDate(value.getOrderDay()));
            statement.setDouble(3, value.getOrderTotalPrice());
            statement.setObject(4, value.getOrderGiftPoints().isPresent() ? value.getOrderGiftPoints().get() : null);
            statement.setInt(5, value.getIdEmployee());
            statement.setObject(6, value.getIdClient().isPresent() ? value.getIdClient().get() : null);
            statement.executeUpdate();
            return true;
        } catch (final SQLIntegrityConstraintViolationException e) {
            return false;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean delete(Integer primaryKey) {
        final String query = "DELETE FROM " + TABLE_NAME + " WHERE IdOrdine = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, primaryKey);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }
}
