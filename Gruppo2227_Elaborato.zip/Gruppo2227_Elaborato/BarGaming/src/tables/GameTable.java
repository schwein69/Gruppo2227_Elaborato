package tables;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.Objects;
import java.util.Optional;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import models.Game;

public class GameTable {
    public static final String TABLE_NAME = "gioco";

    private final Connection connection;

    public GameTable(final Connection connection) {
        this.connection = Objects.requireNonNull(connection);
    }

    public ObservableList<Game> readGamesFromResultSet(final ResultSet resultSet) {
        ObservableList<Game> listJoin = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {
                Game newObject = new Game(resultSet.getInt("idGioco"), resultSet.getInt("IdCategoria"),
                        resultSet.getString("NomeGioco"), resultSet.getInt("MemoriaOccupata"));
                listJoin.add(newObject);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return listJoin;
    }

    public Optional<Game> findByPrimaryKey(Integer primaryKey) {
        // TODO Auto-generated method stub
        final String query = "SELECT * FROM " + TABLE_NAME + " where idGioco = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, primaryKey);
            final ResultSet rs = statement.executeQuery();
            return readGamesFromResultSet(rs).stream().findFirst();
        } catch (final SQLException e) {
            return Optional.empty();
        }
    }

    public ObservableList<Game> findAll() {
        // TODO Auto-generated method stub
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet rs = statement.executeQuery("SELECT *  FROM gioco");
            return readGamesFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean save(Game value) {
        // TODO Auto-generated method stub
        final String query = "INSERT INTO " + TABLE_NAME + " (NomeGioco,MemoriaOccupata,IdCategoria) "
                + " VALUES (?,?,?)";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setString(1, value.getGameName());
            statement.setInt(2, value.getMemoryOccuped());
            statement.setInt(3, value.getIdCategory());
            statement.executeUpdate();
            return true;
        } catch (final SQLIntegrityConstraintViolationException e) {
            return false;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean updateGame(Integer gameId, String newName, Integer newMemory, Integer category) {
        // TODO Auto-generated method stub
        final String query = "Select * FROM " + TABLE_NAME + " WHERE idGioco = " + gameId;
        try (final Statement stmt = this.connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                ResultSet.CONCUR_UPDATABLE)) {
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                if (!newName.isEmpty()) {
                    rs.updateString("NomeGioco", newName);
                }
                if (newMemory != null) {
                    rs.updateInt("MemoriaOccupata", newMemory);
                }
                if (category != null) {
                    rs.updateInt("IdCategoria", category);
                }
                rs.updateRow();
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean delete(Integer primaryKey) {
        // TODO Auto-generated method stub
        return false;
    }
}
