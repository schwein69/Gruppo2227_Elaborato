package tables;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import models.Device;

public class DeviceTable {
    public static final String TABLE_NAME = "device";
    private final Connection connection;

    public DeviceTable(final Connection connection) {
        this.connection = Objects.requireNonNull(connection);
    }

    private ObservableList<Device> readDevicesFromResultSet(final ResultSet resultSet) {
        ObservableList<Device> listDevice = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {
                Device newDevice = new Device(resultSet.getInt("idDevice"), resultSet.getInt("idSala"),
                        resultSet.getInt("idModello"), resultSet.getString("NomeDevice"),
                        resultSet.getString("StatoDevice"), resultSet.getString("OccupatoDevice"),
                        resultSet.getInt("MemoriaDevice"));
                listDevice.add(newDevice);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return listDevice;
    }

    public Optional<Device> findByPrimaryKey(Integer primaryKey) {
        // TODO Auto-generated method stub
        final String query = "SELECT *  FROM " + TABLE_NAME + " where IdDevice  = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, primaryKey);
            final ResultSet rs = statement.executeQuery();
            return readDevicesFromResultSet(rs).stream().findFirst();
        } catch (final SQLException e) {
            return Optional.empty();
        }
    }

    public ObservableList<Device> findAll() {
        // TODO Auto-generated method stub
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet rs = statement.executeQuery("SELECT *  FROM " + TABLE_NAME);
            return readDevicesFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public List<Integer> findAllOccupedDeviceByModelAndGame(int idModel, int idGame) {
        // TODO Auto-generated method stub
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet rs = statement.executeQuery("SELECT *  FROM " + TABLE_NAME
                    + " d, associazione a WHERE d.IdModello = " + idModel
                    + " AND a.IdDevice = d.IdDevice AND a.IdGioco = " + idGame + " AND d.OccupatoDevice != 'Empty'");
            List<Integer> listIdDevice = new ArrayList<Integer>();
            while (rs.next()) {
                int idDevice = rs.getInt("IdDevice");
                listIdDevice.add(idDevice);
            }
            return listIdDevice;
        } catch (SQLException e1) {
            e1.printStackTrace();
        }
        return null;
    }


    public List<Integer> findAllDeviceByModelAndGame(int idModel, int idGame) {
        // TODO Auto-generated method stub
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet rs = statement
                    .executeQuery("SELECT *  FROM " + TABLE_NAME + " d, associazione a WHERE d.IdModello = " + idModel
                            + " AND a.IdDevice = d.IdDevice AND a.IdGioco = " + idGame);
            List<Integer> listIdDevice = new ArrayList<Integer>();
            while (rs.next()) {
                int idDevice = rs.getInt("IdDevice");
                listIdDevice.add(idDevice);
            }
            return listIdDevice;
        } catch (SQLException e1) {
            e1.printStackTrace();
        }
        return null;
    }

    public List<Integer> findAllDeviceByGame(int idGame) {
        // TODO Auto-generated method stub
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet rs = statement.executeQuery("SELECT *  FROM " + TABLE_NAME + " d, associazione a WHERE "
                    + " a.IdDevice = d.IdDevice AND a.IdGioco = " + idGame);
            List<Integer> listIdDevice = new ArrayList<Integer>();
            while (rs.next()) {
                int idDevice = rs.getInt("IdDevice");
                listIdDevice.add(idDevice);
            }
            return listIdDevice;
        } catch (SQLException e1) {
            e1.printStackTrace();
        }
        return null;
    }

    public boolean save(Device value) {
        // TODO Auto-generated method stub
        final String query = "INSERT INTO " + TABLE_NAME
                + " (NomeDevice,StatoDevice,OccupatoDevice,MemoriaDevice,IdSala,IdModello) " + " VALUES (?,?,?,?,?,?)";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setString(1, value.getDeviceName());
            statement.setString(2, "No Game");
            statement.setString(3, "Empty");
            statement.setInt(4, 0);
            statement.setInt(5, value.getIdRoom());
            statement.setInt(6, value.getIdModel());
            statement.executeUpdate();
            return true;
        } catch (final SQLIntegrityConstraintViolationException e) {
            return false;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean updateOccupation(int idDevice, String occupedState) {
        // TODO Auto-generated method stub
        final String query = "UPDATE " + TABLE_NAME + " SET " + "OccupatoDevice = ? WHERE IdDevice = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setString(1, occupedState);
            statement.setInt(2, idDevice);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean updateState(int idDevice, String newState) {
        // TODO Auto-generated method stub
        final String query = "UPDATE " + TABLE_NAME + " SET " + "StatoDevice = ? WHERE IdDevice = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setString(1, newState);
            statement.setInt(2, idDevice);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean updateMemory(int idDevice, int calcMemory, boolean add) {
        int oldMemory = this.findByPrimaryKey(idDevice).get().getMemoryDevice();
        final String query = "UPDATE " + TABLE_NAME + " SET " + "MemoriaDevice = ? WHERE IdDevice = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            if (add) {
                statement.setInt(1, oldMemory + calcMemory);
                statement.setInt(2, idDevice);
            } else {
                statement.setInt(1, oldMemory - calcMemory);
                statement.setInt(2, idDevice);
            }

            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean delete(Integer primaryKey) {
        final String query = "DELETE FROM " + TABLE_NAME + " WHERE IdDevice = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, primaryKey);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean isDeviceWorking(int idDevice) {
        // TODO Auto-generated method stub
        final String query = "SELECT *  FROM " + TABLE_NAME + " WHERE IdDevice = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, idDevice);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                String state = rs.getString("StatoDevice");
                return state.equals("Working");
            }
        } catch (final SQLException e) {
            e.getStackTrace();
        }
        return false;
    }

    public boolean updateDevice(Integer deviceId, Integer idRoom, Integer idModel, String newName) {
        final String query = "Select * FROM " + TABLE_NAME + " WHERE IdDevice  = " + deviceId;
        try (final Statement stmt = this.connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                ResultSet.CONCUR_UPDATABLE)) {
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                if (idRoom != null) {
                    rs.updateInt("IdSala", idRoom);
                }
                if (idModel != null) {
                    rs.updateInt("IdModello", idModel);
                    rs.updateInt("MemoriaDevice", 0);
                    rs.updateString("StatoDevice", "No Game");
                }
                if (!newName.isEmpty()) {
                    rs.updateString("NomeDevice", newName);
                }
                rs.updateRow();
                return true;
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return false;
    }

}
