package tables;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.Objects;
import java.util.Optional;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import models.PriceList;

public class PriceListTable {
    public static final String TABLE_NAME = "listinoprezzo";
    private final Connection connection;

    public PriceListTable(final Connection connection) {
        this.connection = Objects.requireNonNull(connection);
    }

    private ObservableList<PriceList> readPriceListsFromResultSet(final ResultSet resultSet) {
        ObservableList<PriceList> listPrice = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {
                PriceList newRoom = new PriceList(resultSet.getInt("IdListino"), resultSet.getInt("TempoListino"),
                        resultSet.getDouble("PrezzoListino"));
                listPrice.add(newRoom);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return listPrice;
    }

    public Optional<PriceList> findByPrimaryKey(Integer primaryKey) {
        // TODO Auto-generated method stub
        final String query = "SELECT * FROM " + TABLE_NAME + " where IdListino = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, primaryKey);
            final ResultSet rs = statement.executeQuery();
            return readPriceListsFromResultSet(rs).stream().findFirst();
        } catch (final SQLException e) {
            return Optional.empty();
        }
    }

    public ObservableList<PriceList> findAll() {
        // TODO Auto-generated method stub
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet rs = statement.executeQuery("SELECT *  FROM " + TABLE_NAME);
            return readPriceListsFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean save(PriceList value) {
        // TODO Auto-generated method stub
        final String query = "INSERT INTO " + TABLE_NAME + " (TempoListino,PrezzoListino) " + " VALUES (?,?)";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, value.getTime());
            statement.setDouble(2, value.getPrice());
            statement.executeUpdate();
            return true;
        } catch (final SQLIntegrityConstraintViolationException e) {
            return false;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean updateList(Integer listId, Integer newTime, Double newPrice) {
        final String query = "Select * FROM " + TABLE_NAME + " WHERE IdListino  = " + listId;
        try (final Statement stmt = this.connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                ResultSet.CONCUR_UPDATABLE)) {
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                if (newTime != null && newTime > 0) {
                    rs.updateInt("TempoListino", newTime);
                }
                if (newPrice != null && newPrice > 0) {
                    rs.updateDouble("PrezzoListino", newPrice);
                }
                rs.updateRow();
                return true;
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return false;
    }

    public boolean delete(Integer primaryKey) {
        final String query = "DELETE FROM " + TABLE_NAME + " WHERE IdListino  = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, primaryKey);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }
}
