package tables;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.Objects;
import java.util.Optional;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import models.Room;

public class RoomTable {
    public static final String TABLE_NAME = "sala";
    private final Connection connection;

    public RoomTable(final Connection connection) {
        this.connection = Objects.requireNonNull(connection);
    }

    private ObservableList<Room> readRoomsFromResultSet(final ResultSet resultSet) {
        ObservableList<Room> listRoom = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {
                Room newRoom = new Room(resultSet.getInt("idSala"), resultSet.getInt("CapienzaMassimaSala"),
                        resultSet.getInt("CapienzaAttuale"));
                listRoom.add(newRoom);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return listRoom;
    }

    public Optional<Room> findByPrimaryKey(Integer primaryKey) {
        // TODO Auto-generated method stub
        final String query = "SELECT * FROM " + TABLE_NAME + " where IdSala = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, primaryKey);
            final ResultSet rs = statement.executeQuery();
            return readRoomsFromResultSet(rs).stream().findFirst();
        } catch (final SQLException e) {
            return Optional.empty();
        }
    }

    public boolean canInsert(int idRoom) {
        // TODO Auto-generated method stub
        final String query = "SELECT * FROM " + TABLE_NAME + " WHERE IdSala  = ? ";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, idRoom);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                int max = rs.getInt("CapienzaMassimaSala");
                int act = rs.getInt("CapienzaAttuale");
                return max >= act + 1;
            }
        } catch (final SQLException e) {
            e.getStackTrace();
        }
        return false;
    }

    public ObservableList<Room> findAll() {
        // TODO Auto-generated method stub
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet rs = statement.executeQuery("SELECT *  FROM " + TABLE_NAME);
            return readRoomsFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean save(Room value) {
        // TODO Auto-generated method stub
        final String query = "INSERT INTO " + TABLE_NAME + " (CapienzaMassimaSala,CapienzaAttuale) " + " VALUES (?,?)";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, value.getRoomCapacity());
            statement.setInt(2, 0);
            statement.executeUpdate();
            return true;
        } catch (final SQLIntegrityConstraintViolationException e) {
            return false;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean updateRoom(int idRoom, int maxCapacity) {
        final String query = "UPDATE " + TABLE_NAME + " SET " + " CapienzaMassimaSala = ? WHERE IdSala   = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, maxCapacity);
            statement.setInt(2, idRoom);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean updateInsert(int idRoom) {
        int newVal = this.findByPrimaryKey(idRoom).get().getRoomActualCapacity() + 1;
        final String query = "UPDATE " + TABLE_NAME + " SET " + " CapienzaAttuale = ? WHERE IdSala  = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, newVal);
            statement.setInt(2, idRoom);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean updateDelete(int idRoom) {
        int newVal = this.findByPrimaryKey(idRoom).get().getRoomActualCapacity() - 1;
        final String query = "UPDATE " + TABLE_NAME + " SET " + " CapienzaAttuale = ? WHERE IdSala  = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, newVal);
            statement.setInt(2, idRoom);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean delete(Integer primaryKey) {
        final String query = "DELETE FROM " + TABLE_NAME + " WHERE IdSala  = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, primaryKey);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }
}
