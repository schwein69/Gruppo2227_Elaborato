package tables;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import models.Classification;

public class ClassificationTable {
    public static final String TABLE_NAME = "classificazione";
    private final Connection connection;

    public ClassificationTable(final Connection connection) {
        this.connection = Objects.requireNonNull(connection);
    }

    private ObservableList<Classification> readClassificationFromResultSet(final ResultSet resultSet) {
        ObservableList<Classification> listCla = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {
                Classification newClass = new Classification(resultSet.getInt("IdGara"), resultSet.getInt("IdCliente"),
                        resultSet.getInt("Posizione"), resultSet.getInt("PuntiPremioVinti"));
                listCla.add(newClass);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return listCla;
    }

    public Optional<Classification> findByPrimaryKey(int idMatch) {
        // TODO Auto-generated method stub
        final String query = "SELECT * FROM " + TABLE_NAME + " WHERE IdGara = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, idMatch);
            final ResultSet rs = statement.executeQuery();
            return readClassificationFromResultSet(rs).stream().findFirst();
        } catch (final SQLException e) {
            return Optional.empty();
        }
    }

    public List<Integer> findAllSignedClients(int matchId) {
        // TODO Auto-generated method stub
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet rs = statement.executeQuery("SELECT *  FROM " + TABLE_NAME + " WHERE IdGara = " + matchId);
            List<Integer> listIdClient = new ArrayList<Integer>();
            while (rs.next()) {
                int idClient = rs.getInt("IdCliente");
                listIdClient.add(idClient);
            }
            return listIdClient;
        } catch (SQLException e1) {
            e1.printStackTrace();
        }
        return null;
    }

    public ObservableList<Classification> findMatch(int matchId) {
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet rs = statement.executeQuery("SELECT * FROM " + TABLE_NAME + " WHERE IdGara = " + matchId);
            return readClassificationFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public ObservableList<Classification> findAll() {
        // TODO Auto-generated method stub
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet rs = statement.executeQuery(
                    "SELECT *  FROM " + TABLE_NAME + " C,gara A WHERE A.IdGara = C.IdGara AND A.StatoGara = 'On'");
            return readClassificationFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean save(Classification newClas) {
        // TODO Auto-generated method stub
        final String query = "INSERT INTO " + TABLE_NAME + " (IdGara,IdCliente,Posizione,PuntiPremioVinti) "
                + " VALUES (?,?,?,?)";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, newClas.getIdMatch());
            statement.setInt(2, newClas.getIdClient());
            statement.setInt(3, newClas.getPosition());
            statement.setInt(4, newClas.getGiftPointsWon());
            statement.executeUpdate();
            return true;
        } catch (final SQLIntegrityConstraintViolationException e) {
            return false;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean deleteClientFromMatch(int idMatch, int idClient) {
        // TODO Auto-generated method stub
        final String query = "DELETE FROM " + TABLE_NAME + " WHERE IdGara = ? AND IdCliente = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, idMatch);
            statement.setInt(2, idClient);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean isClientAlreadyPresentInMatch(int idMatch, int idClient) {
        // TODO Auto-generated method stub
        final String query = "SELECT *  FROM " + TABLE_NAME + " WHERE IdGara = ? AND IdCliente = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, idMatch);
            statement.setInt(2, idClient);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                return true;
            }
        } catch (final SQLException e) {
            return false;
        }
        return false;
    }

    public boolean updateClassification(int idMatch, int idClient, int position, int points) {
        // TODO Auto-generated method stub
        final String query = "UPDATE " + TABLE_NAME + " SET Posizione = ? , PuntiPremioVinti = ? "
                + " WHERE IdGara = ? AND IdCliente  = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, position);
            statement.setInt(2, points);
            statement.setInt(3, idMatch);
            statement.setInt(4, idClient);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean delete(int idMatch) {
        // TODO Auto-generated method stub
        final String query = "DELETE FROM " + TABLE_NAME + " WHERE IdGara  = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, idMatch);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

}
