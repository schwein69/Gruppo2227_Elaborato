package tables;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.Objects;
import java.util.Optional;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import models.Association;

public class AssociationTable {
    public static final String TABLE_NAME = "associazione";
    private final Connection connection;

    public AssociationTable(final Connection connection) {
        this.connection = Objects.requireNonNull(connection);
    }

    private ObservableList<Association> readAssociationFromResultSet(final ResultSet resultSet) {
        ObservableList<Association> listAssoc = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {
                Association newDevice = new Association(resultSet.getInt("IdDevice"), resultSet.getInt("IdGioco"));
                listAssoc.add(newDevice);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return listAssoc;
    }

    public Optional<Association> findByPrimaryKey(Integer primaryKey) {
        // TODO Auto-generated method stub
        return null;
    }

    public ObservableList<Association> findByDevice(int idDevice) {
        // TODO Auto-generated method stub
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet rs = statement
                    .executeQuery("SELECT *  FROM " + TABLE_NAME + " WHERE IdDevice = " + idDevice);
            return readAssociationFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public ObservableList<Association> findAll() {
        // TODO Auto-generated method stub
        try (final Statement statement = this.connection.createStatement()) {
            final ResultSet rs = statement.executeQuery("SELECT *  FROM " + TABLE_NAME);
            return readAssociationFromResultSet(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean save(Association newAssoci) {
        // TODO Auto-generated method stub
        final String query = "INSERT INTO " + TABLE_NAME + " (IdDevice ,IdGioco) " + " VALUES (?,?)";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, newAssoci.getIdDevice());
            statement.setInt(2, newAssoci.getIdGame());
            statement.executeUpdate();
            return true;
        } catch (final SQLIntegrityConstraintViolationException e) {
            return false;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean isGameAlreadyPresentInDevice(int idDevice, int idGame) {
        // TODO Auto-generated method stub
        final String query = "SELECT *  FROM " + TABLE_NAME + " WHERE IdDevice = ? AND IdGioco = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, idDevice);
            statement.setInt(2, idGame);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                return true;
            }
        } catch (final SQLException e) {
            return false;
        }
        return false;
    }

    public boolean formatDevice(int idDevice) {
        // TODO Auto-generated method stub
        final String query = "DELETE FROM " + TABLE_NAME + " WHERE IdDevice  = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, idDevice);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean delete(int idDevice, int idGame) {
        // TODO Auto-generated method stub
        final String query = "DELETE FROM " + TABLE_NAME + " WHERE IdDevice  = ? AND IdGioco = ?";
        try (final PreparedStatement statement = this.connection.prepareStatement(query)) {
            statement.setInt(1, idDevice);
            statement.setInt(2, idGame);
            return statement.executeUpdate() > 0;
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

}
