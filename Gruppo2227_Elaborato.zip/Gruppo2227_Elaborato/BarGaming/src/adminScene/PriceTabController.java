package adminScene;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import models.PriceList;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import connection.ConnectionProvider;
import connection.Utils;
import tables.PriceListTable;

public class PriceTabController implements Initializable {
    final static String username = "root";
    final static String password = "";
    final static String dbName = "databasegigi";

    final ConnectionProvider connectionProvider = new ConnectionProvider(username, password, dbName);
    final PriceListTable priceTable = new PriceListTable(connectionProvider.getMySQLConnection());
    @FXML
    private Button newListButton;

    @FXML
    private TextField removeIdLabel;

    @FXML
    private TextField updatePriceLabel;

    @FXML
    private TextField newTimeLabel;

    @FXML
    private TextField updateTimeLabel;

    @FXML
    private TableColumn<PriceList, Integer> timeColumn;

    @FXML
    private TextField newPriceLabel;

    @FXML
    private TableView<PriceList> priceListTableView;

    @FXML
    private TextField updateIdlabel;

    @FXML
    private Button removeButton;

    @FXML
    private Button updateButton;

    @FXML
    private TableColumn<PriceList, Double> priceColumn;

    @FXML
    private TableColumn<PriceList, Integer> idColumn;

    public void refresh() {
        ObservableList<PriceList> list1 = priceTable.findAll();
        priceListTableView.setItems(list1);
    }

    private void cleanLabels() {
        newTimeLabel.setText("");
        newPriceLabel.setText("");
        updateIdlabel.setText("");
        updateTimeLabel.setText("");
        updatePriceLabel.setText("");
        removeIdLabel.setText("");
    }

    private void initializeRoomTable() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("idList"));
        timeColumn.setCellValueFactory(new PropertyValueFactory<>("time"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        refresh();
    }

    @FXML
    void InsertNewPrice(ActionEvent event) {
        this.newListButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!newTimeLabel.getText().isEmpty() && !newPriceLabel.getText().isEmpty()) {
                        if (Utils.isNumeric(newTimeLabel.getText()) && Utils.isNumeric(newPriceLabel.getText())) {
                            if (Integer.valueOf(newTimeLabel.getText()) > 0
                                    && Double.valueOf(newPriceLabel.getText()) > 0.0) {
                                priceTable.save(new PriceList(0, Integer.valueOf(newTimeLabel.getText()),
                                        Double.valueOf(newPriceLabel.getText())));
                                cleanLabels();
                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("Time and price should be greater than 0!");
                                nullLabels.showAndWait();
                            }
                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("Labels should be numeric!");
                            nullLabels.showAndWait();
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }
        });
    }

    @FXML
    void udpatePriceList(ActionEvent event) {
        this.updateButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!updateIdlabel.getText().isEmpty()) {
                        if (Utils.isNumeric(updateIdlabel.getText())) {
                            if (priceTable.findByPrimaryKey(Integer.valueOf(updateIdlabel.getText())).isPresent()) {
                                if (priceTable.updateList(Integer.valueOf(updateIdlabel.getText()),
                                        updateTimeLabel.getText().isEmpty() ? null
                                                : Integer.valueOf(updateTimeLabel.getText()),
                                        updatePriceLabel.getText().isEmpty() ? null
                                                : Double.valueOf(updatePriceLabel.getText()))) {
                                    cleanLabels();
                                } else {
                                    Alert nullLabels = new Alert(AlertType.INFORMATION);
                                    nullLabels.setContentText("Time and price should be greater than 0!");
                                    nullLabels.showAndWait();
                                }
                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("List not exist!");
                                nullLabels.showAndWait();
                            }

                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("Labels should be numeric!");
                            nullLabels.showAndWait();
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }
        });
    }

    @FXML
    void removePriceList(ActionEvent event) {
        this.removeButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!removeIdLabel.getText().isEmpty()) {
                        if (Utils.isNumeric(removeIdLabel.getText())) {
                            if (priceTable.findByPrimaryKey(Integer.valueOf(removeIdLabel.getText())).isPresent()) {
                                priceTable.delete(Integer.valueOf(removeIdLabel.getText()));
                                cleanLabels();
                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("Not exist!");
                                nullLabels.showAndWait();
                            }
                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("Labels should be numeric!");
                            nullLabels.showAndWait();
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }
        });
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        // TODO Auto-generated method stub
        initializeRoomTable();
    }
}
