package adminScene;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import models.Room;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import connection.ConnectionProvider;
import connection.Utils;
import tables.RoomTable;

public class RoomTabController implements Initializable {
    final static String username = "root";
    final static String password = "";
    final static String dbName = "databasegigi";

    final ConnectionProvider connectionProvider = new ConnectionProvider(username, password, dbName);
    final RoomTable roomTable = new RoomTable(connectionProvider.getMySQLConnection());
    @FXML
    private TableView<Room> roomTableView;

    @FXML
    private TableColumn<Room, Integer> roomIdColumn;

    @FXML
    private TextField newCapacityLabel;

    @FXML
    private TextField updateCapacityLabel;

    @FXML
    private TextField updateIdRoomLabel;

    @FXML
    private TableColumn<Room, Integer> ActualCapacityColumn;

    @FXML
    private Button updateRoomButton;

    @FXML
    private Button addNewRoomButton;

    @FXML
    private TableColumn<Room, Integer> maxCapacityColumn;

    private void cleanLabels() {
        newCapacityLabel.setText("");
        updateIdRoomLabel.setText("");
        updateCapacityLabel.setText("");
    }

    public void refresh() {
        ObservableList<Room> list1 = roomTable.findAll();
        roomTableView.setItems(list1);
    }

    private void initializeRoomTable() {
        roomIdColumn.setCellValueFactory(new PropertyValueFactory<>("idRoom"));
        maxCapacityColumn.setCellValueFactory(new PropertyValueFactory<>("roomCapacity"));
        ActualCapacityColumn.setCellValueFactory(new PropertyValueFactory<>("roomActualCapacity"));
        refresh();
    }

    @FXML
    void InsertNewRoom(ActionEvent event) {
        this.addNewRoomButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!newCapacityLabel.getText().isEmpty()) {
                        if (Utils.isNumeric(newCapacityLabel.getText())) {
                            if (roomTable.save(new Room(0, Integer.valueOf(newCapacityLabel.getText()), 0))) {
                                cleanLabels();
                            }
                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("Capacity label should be numeric!");
                            nullLabels.showAndWait();
                            newCapacityLabel.setText("");
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }
        });
    }

    @FXML
    void updateRoom(ActionEvent event) {
        this.updateRoomButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!updateIdRoomLabel.getText().isEmpty() && !updateCapacityLabel.getText().isEmpty()) {
                        if (Utils.isNumeric(updateIdRoomLabel.getText())
                                && Utils.isNumeric(updateCapacityLabel.getText())) {
                            if (roomTable.findByPrimaryKey(Integer.valueOf(updateIdRoomLabel.getText())).isPresent()) {
                                int actualCapacity = roomTable
                                        .findByPrimaryKey(Integer.valueOf(updateIdRoomLabel.getText())).get()
                                        .getRoomActualCapacity();
                                if (Integer.valueOf(updateCapacityLabel.getText()) < actualCapacity) {
                                    Alert nullLabels = new Alert(AlertType.INFORMATION);
                                    nullLabels.setContentText("New capacity can be lower than actual capacity!");
                                    nullLabels.showAndWait();
                                    newCapacityLabel.setText("");
                                } else {
                                    roomTable.updateRoom(Integer.valueOf(updateIdRoomLabel.getText()),
                                            Integer.valueOf(updateCapacityLabel.getText()));
                                    cleanLabels();

                                }
                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("Room not exist!");
                                nullLabels.showAndWait();
                                newCapacityLabel.setText("");
                            }

                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("Labels should be numeric!");
                            nullLabels.showAndWait();
                            newCapacityLabel.setText("");
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }
        });
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        // TODO Auto-generated method stub
        initializeRoomTable();
    }
}
