package adminScene;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

import connection.ConnectionProvider;
import connection.Utils;
import tables.SponsorTable;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import models.Sponsor;

public class SponsorTabController implements Initializable {
    final static String username = "root";
    final static String password = "";
    final static String dbName = "databasegigi";

    final ConnectionProvider connectionProvider = new ConnectionProvider(username, password, dbName);
    final SponsorTable sponsorTable = new SponsorTable(connectionProvider.getMySQLConnection());
    @FXML
    private PasswordField updateEmailLabel;

    @FXML
    private TextField UpdateSponsorIdLabel;

    @FXML
    private Button InsertButton;

    @FXML
    private TableView<Sponsor> SponsorTableView;

    @FXML
    private TextField contactLabel;

    @FXML
    private TextField sponsorIdLabel;

    @FXML
    private Button UpdateSponsorButton;

    @FXML
    private TableColumn<Sponsor, String> sponsorNameColumn;

    @FXML
    private TextField UpdateContactLabel;

    @FXML
    private TextField updateNameLabel;

    @FXML
    private Button removeButton;

    @FXML
    private TableColumn<Sponsor, String> sponsorContactColumn;

    @FXML
    private PasswordField emailLabel;

    @FXML
    private TableColumn<Sponsor, String> sponsorEmailColumn;

    @FXML
    private TextField nameLabel;

    @FXML
    private TableColumn<Sponsor, Integer> sponsorIdColumn;

    private void cleanLabels() {
        nameLabel.setText("");
        emailLabel.setText("");
        contactLabel.setText("");
        sponsorIdLabel.setText("");
        UpdateSponsorIdLabel.setText("");
        updateNameLabel.setText("");
        updateEmailLabel.setText("");
        UpdateContactLabel.setText("");
    }

    public void refresh() {
        ObservableList<Sponsor> list1 = sponsorTable.findAll();
        SponsorTableView.setItems(list1);
    }

    private void initializeProductTable() {
        sponsorIdColumn.setCellValueFactory(new PropertyValueFactory<>("idSponsor"));
        sponsorNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        sponsorContactColumn.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
        sponsorEmailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
    }

    @FXML
    void InsertNewSponsor(ActionEvent event) {
        this.InsertButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!nameLabel.getText().isEmpty() && !emailLabel.getText().isEmpty()
                            && !contactLabel.getText().isEmpty()) {
                        if (sponsorTable.save(
                                new Sponsor(0, nameLabel.getText(), contactLabel.getText(), emailLabel.getText()))) {
                            cleanLabels();
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }
        });
    }

    @FXML
    void removeSponsor(ActionEvent event) {
        this.removeButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!sponsorIdLabel.getText().isEmpty()) {
                        if (Utils.isNumeric(sponsorIdLabel.getText())) {
                            if (sponsorTable.findByPrimaryKey(Integer.valueOf(sponsorIdLabel.getText())).isPresent()) {
                                if (sponsorTable.delete(Integer.valueOf(sponsorIdLabel.getText()))) {
                                    cleanLabels();
                                }
                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("Sponsor not exist!");
                                nullLabels.showAndWait();
                                sponsorIdLabel.setText("");
                            }
                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("id label should be numeric!");
                            nullLabels.showAndWait();
                            sponsorIdLabel.setText("");
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }
        });
    }

    @FXML
    void UpdateSponsor(ActionEvent event) {
        this.UpdateSponsorButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!UpdateSponsorIdLabel.getText().isEmpty()) {
                        if (Utils.isNumeric(UpdateSponsorIdLabel.getText())) {
                            if (sponsorTable.findByPrimaryKey(Integer.valueOf(UpdateSponsorIdLabel.getText()))
                                    .isPresent()) {
                                if (sponsorTable.update(Integer.valueOf(UpdateSponsorIdLabel.getText()),
                                        updateNameLabel.getText(), updateEmailLabel.getText(),
                                        UpdateContactLabel.getText())) {
                                    cleanLabels();
                                }
                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("Sponsor not exist!");
                                nullLabels.showAndWait();
                                UpdateSponsorIdLabel.setText("");
                            }

                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("id label should be numeric!");
                            nullLabels.showAndWait();
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }
        });
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        // TODO Auto-generated method stub
        initializeProductTable();
        refresh();
    }
}
