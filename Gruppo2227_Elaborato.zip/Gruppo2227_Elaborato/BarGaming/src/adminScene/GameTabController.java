package adminScene;

import java.net.URL;
import java.sql.Connection;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

import connection.ConnectionProvider;
import connection.Utils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import models.Category;
import models.Game;
import tables.AssociationTable;
import tables.CategoryTable;
import tables.DeviceTable;
import tables.GameTable;
import tables.ModelTable;

public class GameTabController implements Initializable {
    final static String username = "root";
    final static String password = "";
    final static String dbName = "databasegigi";

    final ConnectionProvider connectionProvider = new ConnectionProvider(username, password, dbName);

    final CategoryTable cateTable = new CategoryTable(connectionProvider.getMySQLConnection());
    final DeviceTable deviceTable = new DeviceTable(connectionProvider.getMySQLConnection());
    final ModelTable modelTable = new ModelTable(connectionProvider.getMySQLConnection());
    final GameTable gameTable = new GameTable(connectionProvider.getMySQLConnection());
    final AssociationTable assocTable = new AssociationTable(connectionProvider.getMySQLConnection());
    final Connection con = connectionProvider.getMySQLConnection();

    @FXML
    private ComboBox<Integer> updateGameCombo;

    @FXML
    private TableColumn<Game, Integer> gameMemoryColumn;

    @FXML
    private TextField insertCategoryLabel;

    @FXML
    private TableColumn<Category, String> categoryNameColumn;

    @FXML
    private Button insertGameButton;

    @FXML
    private ComboBox<Integer> insertCategoryColumn;

    @FXML
    private TableView<Game> gameTableView;

    @FXML
    private TextField memoryGame;

    @FXML
    private TableColumn<Game, Integer> gameIdColumn;

    @FXML
    private Button insertCategoryButton;

    @FXML
    private TableColumn<Game, String> gameNameColumn;

    @FXML
    private ComboBox<Integer> categoryCombo;

    @FXML
    private TableColumn<Category, Integer> categoryIdColumn;

    @FXML
    private TableColumn<Game, String> gameCategoryColumn;

    @FXML
    private TextField gameNameLabel;

    @FXML
    private TableView<Category> categoryTable;

    @FXML
    private Button updateGameButton;

    @FXML
    private Button updateCategoryButton;

    private void cleanLabels() {
        gameNameLabel.setText("");
        memoryGame.setText("");
        insertCategoryLabel.setText("");
        insertCategoryColumn.setValue(null);
        updateGameCombo.setValue(null);
        categoryCombo.setValue(null);

    }

    public void refresh() {
        insertCategoryColumn.setItems(cateTable.findAll().stream().map(e -> e.getIdCategory())
                .collect(Collectors.toCollection(FXCollections::observableArrayList)));
        updateGameCombo.setItems(gameTable.findAll().stream().map(e -> e.getIdGame())
                .collect(Collectors.toCollection(FXCollections::observableArrayList)));
        categoryCombo.setItems(cateTable.findAll().stream().map(e -> e.getIdCategory())
                .collect(Collectors.toCollection(FXCollections::observableArrayList)));
        ObservableList<Game> list3 = gameTable.findAll();
        gameTableView.setItems(list3);
        ObservableList<Category> list4 = cateTable.findAll();
        categoryTable.setItems(list4);
    }

    private void initializeGameTable() {
        gameIdColumn.setCellValueFactory(new PropertyValueFactory<>("idGame"));
        gameNameColumn.setCellValueFactory(new PropertyValueFactory<>("gameName"));
        gameMemoryColumn.setCellValueFactory(new PropertyValueFactory<>("memoryOccuped"));
        gameCategoryColumn.setCellValueFactory(new PropertyValueFactory<>("idCategory"));
    }

    private void initializeCategoryTable() {
        categoryIdColumn.setCellValueFactory(new PropertyValueFactory<>("idCategory"));
        categoryNameColumn.setCellValueFactory(new PropertyValueFactory<>("nameCategory"));
    }

    @FXML
    void insertGame(ActionEvent event) {
        this.insertGameButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) { // TODO Auto-generated
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!gameNameLabel.getText().isEmpty() && !memoryGame.getText().isEmpty()
                            && insertCategoryColumn.getValue() != null) {
                        if (Utils.isNumeric(memoryGame.getText())) {
                            if (Integer.valueOf(memoryGame.getText()) > 0) {
                                gameTable.save(new Game(0, insertCategoryColumn.getValue(), gameNameLabel.getText(),
                                        Integer.valueOf(memoryGame.getText())));
                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("Memory shoul be greater than 0!");
                                nullLabels.showAndWait();
                            }

                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("Memory label should be numeric!");
                            nullLabels.showAndWait();
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                    cleanLabels();
                    refresh();
                }
            }
        });
    }

    @FXML
    void insertCategory(ActionEvent event) {
        this.insertCategoryButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) { // TODO Auto-generated
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!insertCategoryLabel.getText().isEmpty()) {
                        if (!cateTable.findByName(insertCategoryLabel.getText()).isPresent()) {
                            cateTable.save(new Category(0, insertCategoryLabel.getText()));
                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("Already present a same name category");
                            nullLabels.showAndWait();
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                    cleanLabels();
                    refresh();
                }
            }
        });
    }

    @FXML
    void updateGame(ActionEvent event) {
        this.updateGameButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) { // TODO Auto-generated
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (updateGameCombo.getValue() != null) {
                        int oldGameMemory = gameTable.findByPrimaryKey(updateGameCombo.getValue()).get()
                                .getMemoryOccuped();
                        if (!memoryGame.getText().isEmpty()) {
                            if (Utils.isNumeric(memoryGame.getText())) {
                                if (Integer.valueOf(memoryGame.getText()) > 0) {
                                    if (!deviceTable.findAllDeviceByGame(updateGameCombo.getValue()).isEmpty()) {
                                        for (Integer idDeviceToUpdateMemory : deviceTable
                                                .findAllDeviceByGame(updateGameCombo.getValue())) {
                                            int modelMemory = modelTable.findById(deviceTable
                                                    .findByPrimaryKey(idDeviceToUpdateMemory).get().getIdModel()).get()
                                                    .getMemory();
                                            if (oldGameMemory - Integer.valueOf(memoryGame.getText()) > 0) {
                                                deviceTable.updateMemory(idDeviceToUpdateMemory,
                                                        Math.abs(oldGameMemory - Integer.valueOf(memoryGame.getText())),
                                                        false);
                                            } else if (oldGameMemory - Integer.valueOf(memoryGame.getText()) < 0) {
                                                int actualMemory = deviceTable.findByPrimaryKey(idDeviceToUpdateMemory)
                                                        .get().getMemoryDevice();
                                                if (actualMemory + Math.abs(oldGameMemory
                                                        - Integer.valueOf(memoryGame.getText())) <= modelMemory) {
                                                    deviceTable.updateMemory(idDeviceToUpdateMemory, Math
                                                            .abs(oldGameMemory - Integer.valueOf(memoryGame.getText())),
                                                            true);
                                                } else {
                                                    deviceTable.updateMemory(idDeviceToUpdateMemory, oldGameMemory,
                                                            false);
                                                    assocTable.delete(idDeviceToUpdateMemory,
                                                            updateGameCombo.getValue());
                                                }
                                            }

                                        }
                                    }
                                    gameTable.updateGame(updateGameCombo.getValue(), gameNameLabel.getText(),
                                            Integer.valueOf(memoryGame.getText()),
                                            insertCategoryColumn.getValue() != null ? insertCategoryColumn.getValue()
                                                    : null);
                                }
                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("Memory label should be numeric and greater than 0!");
                                nullLabels.showAndWait();
                                memoryGame.setText("null");
                            }

                        } else {
                            gameTable.updateGame(updateGameCombo.getValue(),
                                    gameNameLabel.getText().isEmpty() ? null : gameNameLabel.getText(), null,
                                    insertCategoryColumn.getValue() != null ? insertCategoryColumn.getValue() : null);
                        }
                    }
                } else {
                    Alert nullLabels = new Alert(AlertType.INFORMATION);
                    nullLabels.setContentText("Please fill labels");
                    nullLabels.showAndWait();
                }
                cleanLabels();
                refresh();
            }

        });

    }

    @FXML
    void updateCategory(ActionEvent event) {
        this.updateCategoryButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) { // TODO Auto-generated
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!insertCategoryLabel.getText().isEmpty() && categoryCombo.getValue() != null) {
                        if (!cateTable.findByName(insertCategoryLabel.getText()).isPresent()) {
                            cateTable.update(categoryCombo.getValue(), insertCategoryLabel.getText());
                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("Already present a same name category");
                            nullLabels.showAndWait();
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                    cleanLabels();
                    refresh();
                }
            }
        });
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        initializeGameTable();
        initializeCategoryTable();
        refresh();

    }

}
