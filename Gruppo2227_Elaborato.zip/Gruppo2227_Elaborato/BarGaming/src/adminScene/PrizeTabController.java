package adminScene;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

import connection.ConnectionProvider;
import connection.Utils;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import models.Prize;
import tables.PrizeTable;

public class PrizeTabController implements Initializable {
    final static String username = "root";
    final static String password = "";
    final static String dbName = "databasegigi";

    final ConnectionProvider connectionProvider = new ConnectionProvider(username, password, dbName);
    final PrizeTable prizeTable = new PrizeTable(connectionProvider.getMySQLConnection());
    @FXML
    private TableView<Prize> prizeTableView;

    @FXML
    private Button InsertButton;

    @FXML
    private TableColumn<Prize, String> NameColumn;

    @FXML
    private TextField ModifyPointsLabel;

    @FXML
    private TextField modifyNameLabel;

    @FXML
    private TextField modifyQuantityLabel;

    @FXML
    private TextField newPointsLabel;

    @FXML
    private TableColumn<Prize, Integer> quantityColumn;

    @FXML
    private Button modifyButton;

    @FXML
    private TextField newQuantityLabel;

    @FXML
    private TableColumn<Prize, Integer> PointsColumn;

    @FXML
    private TextField newNameLabel;

    @FXML
    private TableColumn<Prize, Integer> idColumn;

    @FXML
    private TextField modifyIdLabel;

    public void refresh() {
        ObservableList<Prize> list1 = prizeTable.findAll();
        prizeTableView.setItems(list1);
    }

    private void cleanLabels() {
        newNameLabel.setText("");
        newPointsLabel.setText("");
        newQuantityLabel.setText("");
        modifyIdLabel.setText("");
        modifyNameLabel.setText("");
        ModifyPointsLabel.setText("");
        modifyQuantityLabel.setText("");
    }

    private void initializeRoomTable() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("idPrize"));
        NameColumn.setCellValueFactory(new PropertyValueFactory<>("prizeName"));
        PointsColumn.setCellValueFactory(new PropertyValueFactory<>("prizePoints"));
        quantityColumn.setCellValueFactory(new PropertyValueFactory<>("prizeQuantity"));
        refresh();
    }

    @FXML
    void insertNewPrize(ActionEvent event) {
        this.InsertButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!newNameLabel.getText().isEmpty() && !newPointsLabel.getText().isEmpty()
                            && !newQuantityLabel.getText().isEmpty()) {
                        if (Utils.isNumeric(newPointsLabel.getText()) && Utils.isNumeric(newQuantityLabel.getText())) {
                            if (Integer.valueOf(newPointsLabel.getText()) > 0
                                    && Integer.valueOf(newQuantityLabel.getText()) > 0) {
                                prizeTable.save(
                                        new Prize(0, newNameLabel.getText(), Integer.valueOf(newPointsLabel.getText()),
                                                Integer.valueOf(newQuantityLabel.getText())));
                                cleanLabels();
                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("Points and quantity should be greater than 0!");
                                nullLabels.showAndWait();
                            }
                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("Labels should be numeric!");
                            nullLabels.showAndWait();
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }
        });
    }

    @FXML
    void modifyPrize(ActionEvent event) {
        this.modifyButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!modifyIdLabel.getText().isEmpty()) {
                        if (Utils.isNumeric(modifyIdLabel.getText())) {
                            if (prizeTable.findByPrimaryKey(Integer.valueOf(modifyIdLabel.getText())).isPresent()) {
                                if (prizeTable.updatePrize(Integer.valueOf(modifyIdLabel.getText()),
                                        modifyNameLabel.getText(),
                                        ModifyPointsLabel.getText().isEmpty() ? null
                                                : Integer.valueOf(ModifyPointsLabel.getText()),
                                        modifyQuantityLabel.getText().isEmpty() ? null
                                                : Integer.valueOf(modifyQuantityLabel.getText()))) {
                                    cleanLabels();
                                } else {
                                    Alert nullLabels = new Alert(AlertType.INFORMATION);
                                    nullLabels.setContentText("Points and quantity should be greater than 0!");
                                    nullLabels.showAndWait();
                                }
                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("Prize not exist!");
                                nullLabels.showAndWait();
                            }

                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("Labels should be numeric!");
                            nullLabels.showAndWait();
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }
        });
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        // TODO Auto-generated method stub
        initializeRoomTable();
    }

}
