package adminScene;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Optional;
import java.util.ResourceBundle;
import connection.ConnectionProvider;
import connection.Utils;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import models.Device;
import models.Model;
import models.Room;
import tables.AssociationTable;
import tables.DeviceTable;
import tables.ModelTable;
import tables.RoomTable;

class JoinRoomDevice {
    private Room room;
    private Device device;
    private Model model;

    public JoinRoomDevice(Room room, Device device, Model model) {
        this.room = room;
        this.device = device;
        this.model = model;
    }

    public Room getRoom() {
        return room;
    }

    public void setRoom(Room room) {
        this.room = room;
    }

    public Device getDevice() {
        return device;
    }

    public void setDevice(Device device) {
        this.device = device;
    }

    public Model getModel() {
        return model;
    }

}

public class DeviceTabController implements Initializable {
    final static String username = "root";
    final static String password = "";
    final static String dbName = "databasegigi";

    final ConnectionProvider connectionProvider = new ConnectionProvider(username, password, dbName);
    final Connection con = connectionProvider.getMySQLConnection();
    final ModelTable modelTable = new ModelTable(connectionProvider.getMySQLConnection());
    final RoomTable roomTable = new RoomTable(connectionProvider.getMySQLConnection());
    final DeviceTable deviceTable = new DeviceTable(connectionProvider.getMySQLConnection());
    final AssociationTable assoTable = new AssociationTable(connectionProvider.getMySQLConnection());
    @FXML
    private TextField modelNewModelNameLabel;

    @FXML
    private TextField updateIdDeviceLabel;

    @FXML
    private TextField updateDeviceNameLabel;

    @FXML
    private TableColumn<JoinRoomDevice, Integer> JoinIdModelColumn;

    @FXML
    private TableView<JoinRoomDevice> JoinTableView;

    @FXML
    private Button insertNewDeviceButton;

    @FXML
    private TextField removeDevice;

    @FXML
    private TableColumn<JoinRoomDevice, Integer> JoinIdDeviceColumn;

    @FXML
    private TableColumn<JoinRoomDevice, String> occupationColumn;

    @FXML
    private TextField newNameDeviceLabel;

    @FXML
    private TableColumn<JoinRoomDevice, Integer> joinIdRoomColumn;

    @FXML
    private TableColumn<Model, Integer> idModelColumn;

    @FXML
    private ComboBox<Integer> newIdModelCombo;

    @FXML
    private ComboBox<Integer> newIdRoomlCombo;

    @FXML
    private ComboBox<Integer> updateIdRoomCombo;

    @FXML
    private ComboBox<Integer> updateModelCombo;

    @FXML
    private Button removeDeviceButton;

    @FXML
    private Button insertNewModelButton;

    @FXML
    private TableView<Model> modelTableView;

    @FXML
    private Button modifyDeviceButton;

    @FXML
    private TableView<Room> tableRoomView;

    @FXML
    private TableColumn<Model, String> modelNamecolumn;

    @FXML
    private TableColumn<JoinRoomDevice, String> JoinDeviceNameColumn;

    @FXML
    private TextField modelNewMemoryLabel;

    @FXML
    private TableColumn<Room, Integer> roomCapacityColumn;

    @FXML
    private TableColumn<Room, Integer> roomActuallyCapacityColumn;

    @FXML
    private TableColumn<Model, Integer> memoryColumn;

    @FXML
    private TableColumn<Room, Integer> idRoomColumn;

    @FXML
    private TableColumn<JoinRoomDevice, String> JoinDeviceStateColumn;

    private void cleanLabels() {
        newIdModelCombo.setValue(null);
        newIdRoomlCombo.setValue(null);
        newNameDeviceLabel.setText("");
        updateIdDeviceLabel.setText("");
        updateIdRoomCombo.setValue(null);
        updateModelCombo.setValue(null);
        updateDeviceNameLabel.setText("");
        removeDevice.setText("");
        modelNewModelNameLabel.setText("");
        modelNewMemoryLabel.setText("");
    }

    public void refresh() {
        ObservableList<Room> list1 = roomTable.findAll();
        tableRoomView.setItems(list1);
        ObservableList<Model> list2 = modelTable.findAll();
        modelTableView.setItems(list2);
        ObservableList<JoinRoomDevice> list3 = this.findAllWithJoinInDeviceTable();
        JoinTableView.setItems(list3);
    }

    @FXML
    void InsertNewDevice(ActionEvent event) {
        this.insertNewDeviceButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (newIdRoomlCombo.getValue() != null && newIdModelCombo.getValue() != null
                            && !newNameDeviceLabel.getText().isEmpty()) {
                        int actual = roomTable.findByPrimaryKey(newIdRoomlCombo.getValue()).get()
                                .getRoomActualCapacity();
                        int max = roomTable.findByPrimaryKey(newIdRoomlCombo.getValue()).get().getRoomCapacity();
                        if (actual + 1 <= max) {
                            if (deviceTable.save(new Device(0, newIdRoomlCombo.getValue(), newIdModelCombo.getValue(),
                                    newNameDeviceLabel.getText(), "", "", 0))) {
                                roomTable.updateInsert(newIdRoomlCombo.getValue());
                                cleanLabels();
                            }
                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("Room selected is full!");
                            nullLabels.showAndWait();
                        }

                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }
        });
    }

    @FXML
    void updateDevice(ActionEvent event) {
        this.modifyDeviceButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!updateIdDeviceLabel.getText().isEmpty()) {
                        if (Utils.isNumeric(updateIdDeviceLabel.getText())) {
                            if (deviceTable.findByPrimaryKey(Integer.valueOf(updateIdDeviceLabel.getText()))
                                    .isPresent()) {
                                int roomIdToDecrease = deviceTable
                                        .findByPrimaryKey(Integer.valueOf(updateIdDeviceLabel.getText())).get()
                                        .getIdRoom();
                                if (deviceTable.updateDevice(Integer.valueOf(updateIdDeviceLabel.getText()),
                                        updateIdRoomCombo.getValue(), updateModelCombo.getValue(),
                                        updateDeviceNameLabel.getText())) {
                                    if (updateModelCombo.getValue() != null) {
                                        assoTable.formatDevice(Integer.valueOf(updateIdDeviceLabel.getText()));
                                    }
                                    if (updateIdRoomCombo.getValue() != null) {
                                        if (roomTable.findByPrimaryKey(updateIdRoomCombo.getValue()).isPresent()) {
                                            roomTable.updateDelete(roomIdToDecrease);
                                            roomTable.updateInsert(updateIdRoomCombo.getValue());
                                        }
                                    }
                                    cleanLabels();
                                }
                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("device not exist!");
                                nullLabels.showAndWait();
                            }
                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("device id label should be numeric!");
                            nullLabels.showAndWait();
                        }

                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }
        });
    }

    @FXML
    void removeDevice(ActionEvent event) {
        this.removeDeviceButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!removeDevice.getText().isEmpty()) {
                        if (Utils.isNumeric(removeDevice.getText())) {
                            if (deviceTable.findByPrimaryKey(Integer.valueOf(removeDevice.getText())).isPresent()) {
                                int roomId = deviceTable.findByPrimaryKey(Integer.valueOf(removeDevice.getText())).get()
                                        .getIdRoom();
                                System.out.println(roomId);
                                assoTable.formatDevice(Integer.valueOf(removeDevice.getText()));
                                deviceTable.delete(Integer.valueOf(removeDevice.getText()));
                                roomTable.updateDelete(roomId);
                                cleanLabels();

                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("device not exist!");
                                nullLabels.showAndWait();
                            }
                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("device id label should be numeric!");
                            nullLabels.showAndWait();
                        }

                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }
        });
    }

    @FXML
    void InsertNewModel(ActionEvent event) {
        this.insertNewModelButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!modelNewModelNameLabel.getText().isEmpty() && !modelNewMemoryLabel.getText().isEmpty()) {
                        if (Utils.isNumeric(modelNewMemoryLabel.getText())) {
                            if (!modelTable.findByModelNameAndMemory(modelNewModelNameLabel.getText(),
                                    Integer.valueOf(modelNewMemoryLabel.getText())).isPresent()) {
                                if (modelTable.save(new Model(0, modelNewModelNameLabel.getText(),
                                        Integer.valueOf(modelNewMemoryLabel.getText())))) {
                                    cleanLabels();
                                }
                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("device with same name and memory already exist!");
                                nullLabels.showAndWait();
                            }
                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("Memory label should be numeric!");
                            nullLabels.showAndWait();
                        }

                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }
        });
    }

    private ObservableList<JoinRoomDevice> readDeviceFromResultSetJoinRoomDevice(final ResultSet resultSet) {
        ObservableList<JoinRoomDevice> listJoin = FXCollections.observableArrayList();
        try {
            while (resultSet.next()) {
                JoinRoomDevice newObject = new JoinRoomDevice(
                        new Room(resultSet.getInt("idSala"), resultSet.getInt("CapienzaMassimaSala"),
                                resultSet.getInt("CapienzaAttuale")),
                        new Device(resultSet.getInt("idDevice"), resultSet.getInt("idSala"),
                                resultSet.getInt("idModello"), resultSet.getString("NomeDevice"),
                                resultSet.getString("StatoDevice"), resultSet.getString("OccupatoDevice"),
                                resultSet.getInt("MemoriaDevice")),
                        new Model(resultSet.getInt("idModello"), resultSet.getString("NomeModello"),
                                resultSet.getInt("MemoriaDisponibile")));
                listJoin.add(newObject);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listJoin;
    }

    private ObservableList<JoinRoomDevice> findAllWithJoinInDeviceTable() {
        try (final Statement statement = this.con.createStatement()) {
            final ResultSet rs = statement
                    .executeQuery("SELECT *  FROM device dev" + " JOIN sala ON dev.IdSala = sala.IdSala "
                            + " JOIN modello ON dev.idModello = modello.idModello ORDER BY dev.IdSala");
            return readDeviceFromResultSetJoinRoomDevice(rs);
        } catch (final SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        // TODO Auto-generated method stub
        modelTable.findAll().forEach((e) -> {
            newIdModelCombo.getItems().add(e.getIdModel());
            updateModelCombo.getItems().add(e.getIdModel());
        });
        roomTable.findAll().forEach((e) -> {
            newIdRoomlCombo.getItems().add(e.getIdRoom());
            updateIdRoomCombo.getItems().add(e.getIdRoom());
        });
        initializeRoomTable();
        initializeModelTable();
        initializeDeviceTable();
    }

    private void initializeDeviceTable() {
        this.joinIdRoomColumn
                .setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getRoom().getIdRoom()).asObject());
        this.JoinIdDeviceColumn
                .setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getDevice().getIdDevice()).asObject());
        this.JoinDeviceNameColumn
                .setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getDevice().getDeviceName()));
        this.JoinDeviceStateColumn
                .setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getDevice().getStateDevice()));
        this.occupationColumn.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getDevice().getOccuped()));
        this.JoinIdModelColumn
                .setCellValueFactory(e -> new SimpleIntegerProperty(e.getValue().getModel().getIdModel()).asObject());
        ObservableList<JoinRoomDevice> list = this.findAllWithJoinInDeviceTable();
        JoinTableView.setItems(list);
    }

    private void initializeRoomTable() {
        idRoomColumn.setCellValueFactory(new PropertyValueFactory<>("idRoom"));
        roomCapacityColumn.setCellValueFactory(new PropertyValueFactory<>("roomCapacity"));
        roomActuallyCapacityColumn.setCellValueFactory(new PropertyValueFactory<>("roomActualCapacity"));
        ObservableList<Room> list = roomTable.findAll();
        tableRoomView.setItems(list);
    }

    private void initializeModelTable() {
        idModelColumn.setCellValueFactory(new PropertyValueFactory<>("idModel"));
        modelNamecolumn.setCellValueFactory(new PropertyValueFactory<>("modelName"));
        memoryColumn.setCellValueFactory(new PropertyValueFactory<>("memory"));
        ObservableList<Model> list = modelTable.findAll();
        modelTableView.setItems(list);
    }
}
