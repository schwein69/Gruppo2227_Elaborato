package adminScene;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.AnchorPane;

public class AdminSceneController implements Initializable {

    private EmployeeTabController empController;
    private ProductTabController proController;
    private DeviceTabController deviceController;
    private RoomTabController roomController;
    private PriceTabController priceController;
    private PrizeTabController prizeController;
    private SponsorTabController sponsorController;
    private GameTabController gameController;

    @FXML
    private TabPane tabs;

    @FXML
    private Tab tab1;

    @FXML
    private Tab tab2;

    @FXML
    private Tab tab3;

    @FXML
    private Tab tab4;

    @FXML
    private Tab tab5;

    @FXML
    private Tab tab6;

    @FXML
    private Tab tab7;
    
    @FXML
    private Tab tab8;

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        // TODO Auto-generated method stub
        FXMLLoader loader = new FXMLLoader(getClass().getResource("EmployeeTab.fxml"));
        try {
            AnchorPane anch1 = loader.load();
            empController = loader.getController();
            tab1.setContent(anch1);
        } catch (Exception e) {
            System.out.println("unable to load tab1");
            e.printStackTrace();
        }
        loader = new FXMLLoader(getClass().getResource("ProductTab.fxml"));
        try {
            AnchorPane anch1 = loader.load();
            proController = loader.getController();
            tab2.setContent(anch1);
        } catch (Exception e) {
            System.out.println("unable to load tab2");
            e.printStackTrace();
        }
        loader = new FXMLLoader(getClass().getResource("DeviceTab.fxml"));
        try {
            AnchorPane anch1 = loader.load();
            deviceController = loader.getController();
            tab3.setContent(anch1);
        } catch (Exception e) {
            System.out.println("unable to load tab3");
            e.printStackTrace();
        }
        loader = new FXMLLoader(getClass().getResource("RoomTab.fxml"));
        try {
            AnchorPane anch1 = loader.load();
            roomController = loader.getController();
            tab4.setContent(anch1);
        } catch (Exception e) {
            System.out.println("unable to load tab4");
            e.printStackTrace();
        }
        loader = new FXMLLoader(getClass().getResource("PriceTab.fxml"));
        try {
            AnchorPane anch1 = loader.load();
            priceController = loader.getController();
            tab5.setContent(anch1);
        } catch (Exception e) {
            System.out.println("unable to load tab5");
            e.printStackTrace();
        }
        loader = new FXMLLoader(getClass().getResource("PrizeTab.fxml"));
        try {
            AnchorPane anch1 = loader.load();
            prizeController = loader.getController();
            tab6.setContent(anch1);
        } catch (Exception e) {
            System.out.println("unable to load tab6");
            e.printStackTrace();
        }
        loader = new FXMLLoader(getClass().getResource("SponsorTab.fxml"));
        try {
            AnchorPane anch1 = loader.load();
            sponsorController = loader.getController();
            tab7.setContent(anch1);
        } catch (Exception e) {
            System.out.println("unable to load tab7");
            e.printStackTrace();
        }
        loader = new FXMLLoader(getClass().getResource("GameTab.fxml"));
        try {
            AnchorPane anch1 = loader.load();
            gameController = loader.getController();
            tab8.setContent(anch1);
        } catch (Exception e) {
            System.out.println("unable to load tab8");
            e.printStackTrace();
        }
        tabs.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Tab>() {
            @Override
            public void changed(ObservableValue<? extends Tab> ov, Tab t, Tab t1) {
                empController.refresh();
                proController.refresh();
                deviceController.refresh();
                roomController.refresh();
                priceController.refresh();
                prizeController.refresh();
                sponsorController.refresh();
                gameController.refresh();
            }

        });
    }

}
