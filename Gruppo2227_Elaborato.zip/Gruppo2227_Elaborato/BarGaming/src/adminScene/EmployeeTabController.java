package adminScene;

import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Optional;
import java.util.ResourceBundle;

import connection.ConnectionProvider;
import connection.Utils;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import models.Account;
import models.Contract;
import models.Employee;
import tables.AccountTable;
import tables.ContractTable;
import tables.EmployeeTable;

public class EmployeeTabController implements Initializable {

    final static String username = "root";
    final static String password = "";
    final static String dbName = "databasegigi";

    final ConnectionProvider connectionProvider = new ConnectionProvider(username, password, dbName);
    final EmployeeTable employeeTable = new EmployeeTable(connectionProvider.getMySQLConnection());
    final AccountTable accountTable = new AccountTable(connectionProvider.getMySQLConnection());
    final ContractTable contTable = new ContractTable(connectionProvider.getMySQLConnection());

    @FXML
    private Button updateContractButton;

    @FXML
    private TextField updateIdContract;

    @FXML
    private ComboBox<String> updateTypeLabel;

    @FXML
    private TextField updateStipendioLabel;

    @FXML
    private Button insertAccountButton;

    @FXML
    private TextField usernameLabel;

    @FXML
    private PasswordField passwordLabel;

    @FXML
    private Button updateAccountButton;

    @FXML
    private TextField updateIdAccountLabel;

    @FXML
    private PasswordField updatePasswordLabel;

    @FXML
    private Button insertContractButton;

    @FXML
    private ComboBox<String> typeLabel;

    @FXML
    private TextField newStipendioLabel;

    @FXML
    private Button cancelEmployeeButton;

    @FXML
    private TextField CanceldEmployeeLabel;

    @FXML
    private TableView<Contract> contractTable;

    @FXML
    private TableColumn<Contract, Integer> idContractColumnContractTable;

    @FXML
    private TableColumn<Contract, String> typeColumn;

    @FXML
    private TableColumn<Contract, String> stipendioColumn;

    @FXML
    private TableColumn<Contract, String> endDateColumn;

    @FXML
    private TableColumn<Contract, String> startDateColumn;

    @FXML
    private TableView<Employee> employeeTabView;

    @FXML
    private TableColumn<Employee, Integer> idDipColumn;

    @FXML
    private TableColumn<Employee, String> genderColumn;

    @FXML
    private TableColumn<Employee, String> birthdayColumn;

    @FXML
    private TableColumn<Employee, String> nameColumn;

    @FXML
    private TableColumn<Employee, String> lastNameColumn;

    @FXML
    private TableColumn<Employee, String> cityColumn;

    @FXML
    private TableColumn<Employee, String> emailColumn;

    @FXML
    private TableColumn<Employee, String> addressColumn;

    @FXML
    private TableColumn<Employee, String> codeColumn;

    @FXML
    private TableColumn<Employee, String> phoneColumn;

    @FXML
    private TableColumn<Employee, String> roleColumnEmployee;

    @FXML
    private TableColumn<Employee, Integer> idContractColumn;

    @FXML
    private TableColumn<Employee, Integer> idAccountColumn;

    @FXML
    private TableView<Account> AccountTableView;

    @FXML
    private TableColumn<Account, Integer> idAccountColumnAccountTable;

    @FXML
    private TableColumn<Account, String> usernameColumn;

    @FXML
    private TableColumn<Account, String> passwordColumn;

    @FXML
    private TableColumn<Account, String> roleColumn;

    @FXML
    private Button insertDipButton;

    @FXML
    private TextField idContractLabel;

    @FXML
    private TextField addressLabel;

    @FXML
    private DatePicker birthdayLabel;

    @FXML
    private TextField phoneLabel;

    @FXML
    private ComboBox<String> genderLabel;

    @FXML
    private TextField idAccoutnLabel;

    @FXML
    private TextField nameLabel;

    @FXML
    private ComboBox<String> roleLabel;

    @FXML
    private TextField LastNameLabel;

    @FXML
    private TextField cityLabel;

    @FXML
    private TextField codeLabel;

    @FXML
    private TextField emailLabel;

    private void cleanLabels() {
        updateIdContract.setText("");
        updateStipendioLabel.setText("");
        updateIdAccountLabel.setText("");
        updatePasswordLabel.setText("");
        newStipendioLabel.setText("");
        usernameLabel.setText("");
        passwordLabel.setText("");
        CanceldEmployeeLabel.setText("");
        idContractLabel.setText("");
        updateIdContract.setText("");
        addressLabel.setText("");
        phoneLabel.setText("");
        idAccoutnLabel.setText("");
        nameLabel.setText("");
        LastNameLabel.setText("");
        cityLabel.setText("");
        codeLabel.setText("");
        emailLabel.setText("");
        typeLabel.setValue(null);
        roleLabel.setValue(null);
        updateTypeLabel.setValue(null);
        birthdayLabel.setValue(null);
        genderLabel.setValue(null);
    }

    private boolean notNullLabelsInEmployeeRegistration() {
        return nameLabel.getText().isEmpty() || cityLabel.getText().isEmpty() || LastNameLabel.getText().isEmpty()
                || phoneLabel.getText().isEmpty() || emailLabel.getText().isEmpty()
                || idContractLabel.getText().isEmpty() || codeLabel.getText().isEmpty()
                || addressLabel.getText().isEmpty() || idAccoutnLabel.getText().isEmpty()
                || roleLabel.getValue() == null || birthdayLabel.getValue() == null || genderLabel.getValue() == null;
    }

    @FXML
    void employeeRegistration(ActionEvent event) {
        this.insertDipButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");

                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!notNullLabelsInEmployeeRegistration()) {
                        if (!idContractLabel.getText().isEmpty() && Utils.isNumeric(idContractLabel.getText())
                                && !idAccoutnLabel.getText().isEmpty() && Utils.isNumeric(idAccoutnLabel.getText())) {
                            if (accountTable.isUsedCheck(Integer.valueOf(idAccoutnLabel.getText()))) {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("IdAccount is already used!");
                                nullLabels.showAndWait();
                                idAccoutnLabel.setText("");
                                return;
                            }
                            if (contTable.isUsedCheckByClient(Integer.valueOf(idContractLabel.getText()))
                                    || contTable.isCompletedContract(Integer.valueOf(idContractLabel.getText()))) {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("IdContract is already used or is a completed contract!");
                                nullLabels.showAndWait();
                                idContractLabel.setText("");
                                return;
                            }
                            Employee newEployee = new Employee(0, Integer.valueOf(idContractLabel.getText()),
                                    Integer.valueOf(idAccoutnLabel.getText()), nameLabel.getText(),
                                    LastNameLabel.getText(), genderLabel.getValue(),
                                    java.sql.Date.valueOf(birthdayLabel.getValue()), phoneLabel.getText(),
                                    emailLabel.getText(), cityLabel.getText(), addressLabel.getText(),
                                    codeLabel.getText(), roleLabel.getValue());
                            if (employeeTable.save(newEployee)) {
                                cleanLabels();
                            }
                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("Not numeric in IdAccount or IdContract labels");
                            nullLabels.showAndWait();
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }
        });
    }

    @FXML
    void insertNewAccount(ActionEvent event) {
        this.insertAccountButton.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");

                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!usernameLabel.getText().isEmpty() && !passwordLabel.getText().isEmpty()) {
                        if (accountTable.isUsernameExist(usernameLabel.getText())) {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("UserName already exist");
                            nullLabels.showAndWait();
                            cleanLabels();
                        } else {
                            if (accountTable.save(
                                    new Account(0, usernameLabel.getText(), passwordLabel.getText(), "Dipendente"))) {
                                cleanLabels();
                            }
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }

        });

    }

    @FXML
    void insertNewContract(ActionEvent event) {
        this.insertContractButton.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");

                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (typeLabel.getValue() != null && !newStipendioLabel.getText().isEmpty()) {
                        if (Utils.isNumeric(newStipendioLabel.getText())) {
                            if (contTable.save(
                                    new Contract(0, typeLabel.getValue(), Double.valueOf(newStipendioLabel.getText()),
                                            java.sql.Date.valueOf(LocalDate.now()), null))) {
                                cleanLabels();
                            }
                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("Salary label should be numeric!");
                            nullLabels.showAndWait();
                            newStipendioLabel.setText("");
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }
        });
    }

    @FXML
    void removeEmployee(ActionEvent event) {
        this.cancelEmployeeButton.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");

                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!CanceldEmployeeLabel.getText().isEmpty()) {
                        if (Utils.isNumeric(CanceldEmployeeLabel.getText())) {
                            if (employeeTable.findByPrimaryKey(Integer.valueOf(CanceldEmployeeLabel.getText()))
                                    .isPresent()) {
                                int accountId = employeeTable
                                        .getAccountId(Integer.valueOf(CanceldEmployeeLabel.getText()));
                                int contractId = employeeTable
                                        .getContractId(Integer.valueOf(CanceldEmployeeLabel.getText()));
                                accountTable.delete(accountId);
                                contTable.update(contractId);
                                employeeTable.delete(Integer.valueOf(CanceldEmployeeLabel.getText()));
                                CanceldEmployeeLabel.setText("");
                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("Id not exist!");
                                nullLabels.showAndWait();
                                CanceldEmployeeLabel.setText("");
                            }
                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("Id label should be numeric!");
                            nullLabels.showAndWait();
                            CanceldEmployeeLabel.setText("");
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }

        });
    }

    @FXML
    void updateAccount(ActionEvent event) {
        this.updateAccountButton.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!updateIdAccountLabel.getText().isEmpty() && !updatePasswordLabel.getText().isEmpty()) {
                        if (Utils.isNumeric(updateIdAccountLabel.getText())) {
                            if (accountTable.isIdAccountExist(Integer.valueOf(updateIdAccountLabel.getText()))) {
                                if (accountTable.updateAccount(Integer.valueOf(updateIdAccountLabel.getText()),
                                        updatePasswordLabel.getText())) {
                                    cleanLabels();
                                }
                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("id account not exist!");
                                nullLabels.showAndWait();
                            }
                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("id account should be numeric");
                            nullLabels.showAndWait();
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }
        });
    }

    @FXML
    void updateContract(ActionEvent event) {
        this.updateContractButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!updateIdContract.getText().isEmpty() && !updateStipendioLabel.getText().isEmpty()
                            && updateTypeLabel.getValue() != null) {
                        if (Utils.isNumeric(updateIdContract.getText())
                                && Utils.isNumeric(updateStipendioLabel.getText())) {
                            if (contTable.findByPrimaryKey(Integer.valueOf(updateIdContract.getText())).isPresent()) {
                                if (!contTable.isCompletedContract(Integer.valueOf(updateIdContract.getText()))) {
                                    if (contTable.updateContract(Integer.valueOf(updateStipendioLabel.getText()),
                                            updateTypeLabel.getValue(), Integer.valueOf(updateIdContract.getText()))) {
                                        cleanLabels();
                                    }
                                } else {
                                    Alert nullLabels = new Alert(AlertType.INFORMATION);
                                    nullLabels.setContentText("Can't modify completed contract!");
                                    nullLabels.showAndWait();
                                }

                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("id contract not exist!");
                                nullLabels.showAndWait();
                            }
                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("id contract and salary should be numeric");
                            nullLabels.showAndWait();
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }
        });
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        // TODO Auto-generated method stub
        initializeEmployeeTable();
        initializeAccountTable();
        initializeContractTable();
    }

    public void refresh() {
        ObservableList<Employee> list1 = employeeTable.findAll();
        employeeTabView.setItems(list1);
        ObservableList<Account> list2 = accountTable.findAll();
        AccountTableView.setItems(list2);
        ObservableList<Contract> list3 = contTable.findAll();
        contractTable.setItems(list3);
    }

    private void setComboBox() {
        this.genderLabel.getItems().add("Male");
        this.genderLabel.getItems().add("Female");
        this.roleLabel.getItems().add("Staff");
        this.roleLabel.getItems().add("Barista");
        this.roleLabel.getItems().add("Tecnico");
        this.typeLabel.getItems().add("Determinato");
        this.typeLabel.getItems().add("Indeterminato");
        this.typeLabel.getItems().add("Tirocinio");
        this.updateTypeLabel.getItems().add("Determinato");
        this.updateTypeLabel.getItems().add("Indeterminato");
        this.updateTypeLabel.getItems().add("Tirocinio");

    }

    private void initializeEmployeeTable() {
        idDipColumn.setCellValueFactory(new PropertyValueFactory<>("idEmployee"));
        lastNameColumn.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        genderColumn.setCellValueFactory(new PropertyValueFactory<>("gender"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
        phoneColumn.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
        birthdayColumn.setCellValueFactory(e -> {
            SimpleStringProperty property = new SimpleStringProperty();
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            property.setValue(dateFormat.format(e.getValue().getBirthday()));
            return property;
        });
        addressColumn.setCellValueFactory(new PropertyValueFactory<>("address"));
        codeColumn.setCellValueFactory(new PropertyValueFactory<>("postalCode"));
        cityColumn.setCellValueFactory(new PropertyValueFactory<>("city"));
        idContractColumn.setCellValueFactory(new PropertyValueFactory<>("idContract"));
        idAccountColumn.setCellValueFactory(new PropertyValueFactory<>("idAccount"));
        roleColumnEmployee.setCellValueFactory(new PropertyValueFactory<>("role"));
        ObservableList<Employee> list = employeeTable.findAll();
        employeeTabView.setItems(list);
        setComboBox();
    }

    private void initializeAccountTable() {
        idAccountColumnAccountTable.setCellValueFactory(new PropertyValueFactory<>("idAccount"));
        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("userName"));
        passwordColumn.setCellValueFactory(e -> new SimpleStringProperty((Utils.encrypt(e.getValue().getPassWord()))));
        roleColumn.setCellValueFactory(new PropertyValueFactory<>("role"));
        ObservableList<Account> list = accountTable.findAll();
        AccountTableView.setItems(list);
    }

    private void initializeContractTable() {
        idContractColumnContractTable.setCellValueFactory(new PropertyValueFactory<>("idContract"));
        typeColumn.setCellValueFactory(new PropertyValueFactory<>("type"));
        stipendioColumn.setCellValueFactory(new PropertyValueFactory<>("salary"));
        startDateColumn.setCellValueFactory(e -> {
            SimpleStringProperty property = new SimpleStringProperty();
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            property.setValue(dateFormat.format(e.getValue().getStartDate()));
            return property;
        });
        endDateColumn.setCellValueFactory(e -> {
            SimpleStringProperty property = new SimpleStringProperty();
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            if (e.getValue().getFinishDate().isPresent()) {
                property.setValue(dateFormat.format(e.getValue().getFinishDate().get()));
                return property;
            }
            property.set("NULL");
            return property;
        });
        ObservableList<Contract> list = contTable.findAll();
        contractTable.setItems(list);
    }
}
