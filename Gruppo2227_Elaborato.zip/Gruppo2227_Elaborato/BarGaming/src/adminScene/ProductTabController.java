package adminScene;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

import connection.ConnectionProvider;
import connection.Utils;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import models.Product;

import tables.ProductTable;

public class ProductTabController implements Initializable {
    final static String username = "root";
    final static String password = "";
    final static String dbName = "databasegigi";

    final ConnectionProvider connectionProvider = new ConnectionProvider(username, password, dbName);
    final ProductTable productTable = new ProductTable(connectionProvider.getMySQLConnection());

    @FXML
    private TextField modifyProductIdLabel;

    @FXML
    private TableView<Product> productTableview;

    @FXML
    private TextField modifyNewProductLabel;

    @FXML
    private TextField newProductNameLabel;

    @FXML
    private TextField modifyPointsLabel;

    @FXML
    private TextField modifyNameLabel;

    @FXML
    private TableColumn<Product, Integer> idProductColumn;

    @FXML
    private TextField newPointsLabel;

    @FXML
    private TextField newPriceLabel;

    @FXML
    private TableColumn<Product, String> nameColumn;

    @FXML
    private TableColumn<Product, Integer> pointsColumn;

    @FXML
    private TextField removeIdProdoctLabel;

    @FXML
    private Button removeProductButton;

    @FXML
    private TableColumn<Product, Double> priceColumn;

    @FXML
    private Button insertNewProductButton;

    @FXML
    private Button modifyProductButton;

    private void cleanLabels() {
        newProductNameLabel.setText("");
        newPriceLabel.setText("");
        newPointsLabel.setText("");
        modifyNameLabel.setText("");
        modifyProductIdLabel.setText("");
        modifyNewProductLabel.setText("");
        modifyPointsLabel.setText("");
        removeIdProdoctLabel.setText("");
    }

    public void refresh() {
        ObservableList<Product> list1 = productTable.findAll();
        productTableview.setItems(list1);
    }

    private void initializeProductTable() {
        idProductColumn.setCellValueFactory(new PropertyValueFactory<>("idProduct"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("productName"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("productPrice"));
        pointsColumn.setCellValueFactory(new PropertyValueFactory<>("productGiftPo"));
        refresh();
    }

    @FXML
    void insertProduct(ActionEvent event) {
        this.insertNewProductButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!newProductNameLabel.getText().isEmpty() && !newPriceLabel.getText().isEmpty()
                            && !newPointsLabel.getText().isEmpty()) {
                        if (Utils.isNumeric(newPriceLabel.getText()) && Utils.isNumeric(newPointsLabel.getText())) {
                            if (productTable.save(new Product(0, newProductNameLabel.getText(),
                                    Double.valueOf(newPriceLabel.getText()),
                                    Integer.valueOf(newPointsLabel.getText())))) {
                                cleanLabels();
                            }
                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("price and points labels should be numeric!");
                            nullLabels.showAndWait();
                            newPointsLabel.setText("");
                            newPriceLabel.setText("");
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }
        });
    }

    @FXML
    void removeProduct(ActionEvent event) {
        this.removeProductButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!removeIdProdoctLabel.getText().isEmpty()) {
                        if (Utils.isNumeric(removeIdProdoctLabel.getText())) {
                            if (productTable.findByPrimaryKey(Integer.valueOf(removeIdProdoctLabel.getText()))
                                    .isPresent()) {
                                if (productTable.delete(Integer.valueOf(removeIdProdoctLabel.getText()))) {
                                    cleanLabels();
                                }
                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("id product not exist!");
                                nullLabels.showAndWait();
                                removeIdProdoctLabel.setText("");
                            }
                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("id label should be numeric!");
                            nullLabels.showAndWait();
                            removeIdProdoctLabel.setText("");
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill all labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }
        });
    }

    @FXML
    void modifyProduct(ActionEvent event) {
        this.modifyProductButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Select okay to proceed or cancel this action.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    if (!modifyProductIdLabel.getText().isEmpty()) {
                        if (Utils.isNumeric(modifyProductIdLabel.getText())) {
                            if (productTable.findByPrimaryKey(Integer.valueOf(modifyProductIdLabel.getText()))
                                    .isPresent()) {
                                if (productTable.update(Integer.valueOf(modifyProductIdLabel.getText()),
                                        modifyNameLabel.getText(),
                                        modifyNewProductLabel.getText().isEmpty() ? null
                                                : Double.valueOf(modifyNewProductLabel.getText()),
                                        modifyPointsLabel.getText().isEmpty() ? null
                                                : Integer.valueOf(modifyPointsLabel.getText()))) {
                                    cleanLabels();
                                }
                            } else {
                                Alert nullLabels = new Alert(AlertType.INFORMATION);
                                nullLabels.setContentText("id product not exist!");
                                nullLabels.showAndWait();
                                modifyProductIdLabel.setText("");
                            }

                        } else {
                            Alert nullLabels = new Alert(AlertType.INFORMATION);
                            nullLabels.setContentText("price, points and id labels should be numeric!");
                            nullLabels.showAndWait();
                        }
                    } else {
                        Alert nullLabels = new Alert(AlertType.INFORMATION);
                        nullLabels.setContentText("Please fill labels");
                        nullLabels.showAndWait();
                    }
                }
                refresh();
            }
        });
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        // TODO Auto-generated method stub
        initializeProductTable();
    }
}
