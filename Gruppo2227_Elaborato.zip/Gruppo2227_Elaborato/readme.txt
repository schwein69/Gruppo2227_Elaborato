Il codice sorgente è nella cartella BarGaming, apribile in eclipse. Però non è runnabile perchè necessita diverse configurazioni.

Esecuzione :

1: avviare apache e mysql in xmapp

2: nella barra di google inserire http://localhost/phpmyadmin/

3: creare nuovo database di nome databasegigi

4: cliccare su databasegigi, importa da e selezionare il file databasegigi3.sql

5: Scaricare javafx-sdk-18.0.2 da https://gluonhq.com/products/javafx/
Versione 18.0.2, sistema operativo windows , architettura x64 e tipo SDK
Una volta scaricata decomprimerla  nella cartella "Cartella_progetto"

La cartella app contiene l'eseguibile.
Il comando va configurato in :

java --module-path "Directory di javafx-sdk-18.0.2 fino a lib incluso" --add-modules javafx.controls,javafx.fxml -jar .\BarGaming.jar


Esempio
 java --module-path "C:\Users\11858\Desktop\Consenga\Cartella_Progetto\javafx-sdk-18.0.2\lib" --add-modules javafx.controls,javafx.fxml -jar .\BarGaming.jar

L'esecuzione in cmd all'interno della cartella app con il comando sopra configurato